# Text Classification Pipeline Forensics

A reproducible, CPU-only forensic audit of a disaster-tweet classifier. The project investigates not only whether a pipeline change improves F1, but also why predictions change, whether the mechanism matches the hypothesis, and whether the result remains credible under fixed-split and leakage-control constraints.

The final frozen pipeline uses URL canonicalization, word-level TF-IDF, unweighted Logistic Regression, no shallow metadata features, and a decision threshold of `0.44`. It achieves **0.761755 held-out F1**.

## Data and Fixed Split

The labeled data come from the [Kaggle NLP with Disaster Tweets competition](https://www.kaggle.com/c/nlp-getting-started) through the public [UCB RISE mirror](https://github.com/ucbrise/kaggle-nlp-disasters/tree/master/data). 

Required files are included in `starter/`:

- `starter/data/train.csv`: the complete labeled dataset;
- `starter/data/split_indices.json`: fixed train, dev, and held-out IDs;
- `starter/configs/project_contract.json`: reference metric and tolerance;
- `starter/data/README_DATA.md`: data provenance and field notes.

| Split | Rows | Positive rows |
|---|---:|---:|
| Train | 4,567 | 1,962 |
| Dev | 1,523 | 655 |
| Held-out | 1,523 | 654 |
| Total | 7,613 | 3,271 |

The supplied IDs are used exactly as provided. The pipeline checks ID uniqueness, ordering, complete coverage, and pairwise disjointness. IDs are never moved between splits, and held-out rows or labels are never removed or modified.

The contract reference held-out F1 is `0.757422`, with tolerance `0.001`.

## Experimental Protocol

All learned transformations, TF-IDF vocabularies, IDF values, and classifiers are fitted using training rows only. Dev evidence selects preprocessing, features, model variants, thresholds, and any proposed training-label intervention. Held-out metrics are evaluated only after the corresponding decision is frozen and cannot reopen selection.

Ticket 1 is the single stated exception: the frozen baseline's held-out F1 is compared with the course reference for discrepancy diagnosis. A diagnostic configuration is not promoted downstream merely because its score is close to the reference.

```text
Ticket 1: reproduce and diagnose the controlled baseline
+-- Ticket 2: audit text normalization
`-- Ticket 3: audit shallow features and shortcuts

Ticket 2 URL decision + Ticket 3 feature decision
`-- Ticket 4: jointly select class weighting and threshold on dev

Ticket 4 frozen model and threshold
`-- Ticket 5: audit duplicates, label consistency, and errors
```

## Results Summary

| Ticket | Question | Frozen decision | Dev F1 | Held-out F1 |
|---|---|---|---:|---:|
| 1 | Why does the controlled baseline differ from the reference? | Split and within-environment seed/order are ruled out; TF-IDF preprocessing is the strongest tested explanation, while reference-version influence remains unresolved. | 0.731255 | 0.747253 |
| 2 | Which text-normalization change is supported? | Adopt URL canonicalization; leave mentions and hashtags unchanged. | 0.736134 | 0.748727 |
| 3 | Do keyword or shallow features add reliable information? | Reject keyword and all other shallow additions. | 0.731255 | 0.747253 |
| 4 | Do class weighting or threshold tuning improve the operating point? | Reject balanced weighting; adopt unweighted Logistic Regression at threshold `0.44`. | 0.749614 | 0.761755 |
| 5 | Should duplicate-supported training-label corrections be used? | Reject the nine-row correction candidate; retain the Ticket 4 pipeline. | 0.749614 | 0.761755 |

The final held-out precision, recall, F1, and accuracy are `0.781350`, `0.743119`, `0.761755`, and `0.800394`, respectively.

For hypotheses, controlled comparisons, uncertainty estimates, prediction changes, examples, and limitations, see:

- [`tickets/ticket-1-baseline.md`](tickets/ticket-1-baseline.md)
- [`tickets/ticket-2-normalization.md`](tickets/ticket-2-normalization.md)
- [`tickets/ticket-3-shortcuts.md`](tickets/ticket-3-shortcuts.md)
- [`tickets/ticket-4-decision-rule.md`](tickets/ticket-4-decision-rule.md)
- [`tickets/ticket-5-data-quality.md`](tickets/ticket-5-data-quality.md)

## Final Pipeline

| Component | Frozen setting |
|---|---|
| Input | Tweet `text` only |
| Normalization | Lowercase text and replace every complete URL with `url` |
| TF-IDF | Word unigrams, 5,000 features, English stop words, sublinear TF |
| Shallow features | None |
| Classifier | Logistic Regression, `C=1`, `class_weight=None`, `max_iter=1000` |
| Random state | `3102` |
| Decision threshold | `0.44` |

## Environment Setup

The canonical clean-room environment is **CPython 3.9.6**. Exact direct and transitive dependencies are pinned in `requirements-lock.txt`; `requirements.txt` provides wider ranges for compatibility checks. No GPU or notebook server is required.

macOS or Linux:

```bash
python3.9 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip==26.0.1
python -m pip install -r requirements-lock.txt
python --version
```

Windows PowerShell:

```powershell
py -3.9 -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip==26.0.1
python -m pip install -r requirements-lock.txt
python --version
```

For the canonical reproduction, `python --version` must report `Python 3.9.6`. Runs under other Python 3.9+ environments are compatibility checks and should generate their own `results/run_manifest.json`.

## Reproducing the Main Results

Run all experiments in dependency order and execute the test suite:

```bash
python run_project.py all
```

Run only the experiments:

```bash
python run_project.py experiments
```

Run one stage or the tests:

```bash
python run_project.py ticket1
python run_project.py ticket2
python run_project.py ticket3
python run_project.py ticket4
python run_project.py ticket5
python run_project.py test
```

Commands for Tickets 2-5 rebuild all upstream dependencies before running the requested stage. This prevents downstream artifacts from being evaluated against stale upstream predictions. `python run_project.py all` regenerates experiments and Markdown ticket reports but does not compile the paper PDF.

## Machine-Checkable Outputs

The project implements the starter artifact interface with stable IDs:

```text
predictions/heldout_predictions.csv:
id,y_true,y_pred,score,model_name,ticket

results/summary.csv:
ticket,model_name,dev_f1_target_1,heldout_f1_target_1,heldout_accuracy,fixed_fp,fixed_fn,new_fp,new_fn,decision,decision_reason

results/threshold_sweep.csv:
ticket,threshold,precision_target_1,recall_target_1,f1_target_1

results/data_quality_audit.csv:
id,issue_type,evidence,disposition,confidence
```

Valid data-quality dispositions are `fix`, `keep_but_flag`, `ambiguous`, and `reject_false_positive`. Original and proposed labels are retained in the detailed Ticket 5 audit, together with whether a proposal was actually used for training.

Important entry points include:

- `results/run_manifest.json`: environment, hashes, protocol versions, and final parameters;
- `results/summary.csv`: headline metrics and decisions for all tickets;
- `predictions/heldout_predictions.csv`: final frozen held-out predictions;
- `results/threshold_sweep.csv`: canonical dev threshold curve;
- `results/data_quality_audit.csv`: canonical data-quality audit;
- `results/ticket*_*.csv` and `results/ticket*_*.json`: detailed ticket evidence.

## Repository Structure

```text
starter/                 Data, fixed split, reference contract, and starter instructions
pipeline/                Shared loading, validation, normalization, modeling, and metrics
configs/                 Frozen protocols for Tickets 1-5
experiments/             Dependency-ordered experiment entry points
tickets/                 Detailed evidence narratives for all five tickets
predictions/             Stage and final stable-ID predictions
results/                 Metrics, statistical analyses, audits, and run manifest
tests/                   Split, protocol, leakage, dependency, and schema tests
logs/chat.md             AI-assisted interaction record
report.pdf               Final self-contained project report
run_project.py           Unified reproduction command
requirements-lock.txt    Exact clean-room dependencies
requirements.txt         Wider compatibility ranges
```
