# AI Usage and Interaction Log

We used OpenAI GPT as an interactive assistant for code review, comparison with the assignment handout, identification of missing controls, targeted code revisions, documentation organization, and wording checks. The interaction was iterative: we raised a specific question, considered the suggestion against the assignment and existing results, and requested further investigation when the initial explanation was incomplete.

The following are representative examples rather than a complete transcript.

## Baseline and Ticket Dependencies

We asked GPT to check whether Tickets 1–5 inherited the correct upstream pipeline. During this review, we questioned whether `class_weight="balanced"` should be treated as part of the Ticket 1 baseline reproduction.

After comparing this idea with the Ticket boundaries, we decided that Ticket 1 should retain one unweighted controlled baseline and that class weighting should be studied as a Ticket 4 model-side variable. GPT assisted with tracing the relevant configurations and saved predictions so that:

- Tickets 2 and 3 start from the same unweighted controlled baseline;
- Ticket 4 inherits Ticket 2’s URL normalization and Ticket 3’s no-shallow-feature decision;
- Ticket 5 inherits the final Ticket 4 model and threshold.

Score-level dependency checks were retained to detect accidental use of an outdated upstream model.

## Ticket 1 Gap Diagnosis

We asked whether Ticket 1 genuinely explained whether the reference-score gap came from the split, seed, software version, or preprocessing. We were not satisfied with simply trying a default model or selecting a configuration because it was numerically close to the reference.

GPT suggested several diagnostic checks, including exact split verification, repeated fits, different random states, changed fitting order, and a complete \(2^3\) TF–IDF comparison over feature cap, English stop-word filtering, and sublinear TF.

We reviewed what these checks could establish and requested more cautious wording where necessary. In particular, one preprocessing cell entered the supplied reference tolerance, but we did not treat this as proof that the unpublished reference pipeline had been reproduced. The final interpretation was limited to stating that preprocessing—especially English stop-word filtering—was the strongest tested explanation, while reference-version influence remained unresolved.

## Normalization and Shortcut Examples

For Ticket 2, we asked whether testing only URL normalization was sufficient. GPT helped compare the prevalence and possible mechanisms of URLs, mentions, hashtags, punctuation, case, and emoji. We selected URLs, mentions, and hashtags for focused analysis rather than testing every possible transformation.

We also noted that mention and hashtag processing should not mechanically copy the URL methodology. The resulting checks therefore used factor-specific interventions:

- equivalent URL rewriting for URL canonicalization;
- handle rewriting and removal for mentions;
- generic replacement and separator rewriting for hashtags.

After reviewing the results, we retained URL canonicalization because it removed a clear sensitivity to arbitrary URL spelling. Mention and hashtag alternatives were not adopted because their estimated improvements were uncertain or weakly localized.

For Ticket 3, we noticed that several feature-only models had development F1 equal to zero and asked whether this indicated a code failure. GPT helped trace the predictions and showed that the models produced all-negative decisions at threshold `0.50`; the fits themselves had not failed.

We also questioned why `url_presence_only` produced a comparatively high F1 and why `keyword` received more detailed analysis. These questions led to additional checks of subgroup label rates, incremental value beyond text, keyword masking, seeded permutations, and negative controls. Keyword remained useful as audit evidence but was rejected as a final feature because it was largely redundant beyond text and created strong counterfactual reliance.

## Model Selection and Error Auditing

For Ticket 4, we asked how the proposed threshold was selected and whether class weighting and threshold tuning were compared fairly. This led to a revised comparison in which unweighted and balanced Logistic Regression were evaluated over the same threshold grid and the full model-by-threshold choice was repeated inside development bootstrap samples.

GPT assisted with reviewing the resulting model-selection frequencies, OOB F1 differences, and precision/recall trade-offs. A strict-content grouped analysis was retained as a non-selecting sensitivity rather than used to retroactively change the decision. The final selected pipeline was unweighted Logistic Regression with `C=1` and threshold `0.44`.

For Ticket 5, we asked whether the audit clearly distinguished duplicates, suspected mislabels, ambiguous examples, hard negatives, and unsupported model-only findings. During review, ordinary false positives were found to be mixed with hard negatives. This was corrected so that `error_type` records false positives or false negatives, while `hard_error` separately records whether an error lies far beyond the decision boundary.

The duplicate-supported training-label candidates remained visible for review, but they were not used in the selected training labels because they did not satisfy the development adoption criteria.

## Verification

GPT-generated suggestions were treated as proposals rather than experimental evidence. Numerical claims were checked against regenerated CSV and JSON artifacts; stable-ID examples were compared with prediction or audit records; upstream dependencies and the development/freeze/held-out boundary were inspected in code; and final claims were checked for consistency across the manifest, predictions, summaries, and report.

Suggestions based only on favorable point estimates, reference-score proximity, model disagreement, or held-out fluctuations were revised or rejected. The complete project was rerun after the final review, and all 11 automated tests passed.
