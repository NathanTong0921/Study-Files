"""Run the frozen Ticket 3 feature-signal and shortcut audit."""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import binomtest, spearmanr
from sklearn.compose import ColumnTransformer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import average_precision_score, f1_score, roc_auc_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from pipeline.core import (  # noqa: E402
    binary_metrics,
    load_project_data,
    make_text_pipeline,
    predict_scores,
    prediction_frame,
)


PROTOCOL_PATH = PROJECT_ROOT / "configs" / "ticket3_protocol.json"
RESULTS_DIR = PROJECT_ROOT / "results"
PREDICTIONS_DIR = PROJECT_ROOT / "predictions"
TICKET_PATH = PROJECT_ROOT / "tickets" / "ticket-3-shortcuts.md"

URL_RE = re.compile(r"(?:https?://|www\.)\S+", flags=re.IGNORECASE)
MENTION_RE = re.compile(r"(?<!\w)@[A-Za-z0-9_]+")
HASHTAG_RE = re.compile(r"(?<!\w)#[A-Za-z0-9_]+")
SPACE_RE = re.compile(r"\s+")


def load_protocol() -> dict:
    with PROTOCOL_PATH.open(encoding="utf-8") as handle:
        protocol = json.load(handle)
    registry = protocol["dev_registry"]
    names = [entry["name"] for entry in registry]
    if len(names) != len(set(names)):
        raise ValueError("Ticket 3 model names must be unique.")
    required = {protocol["baseline_model"], protocol["primary_candidate"]}
    if not required.issubset(names):
        raise ValueError("Ticket 3 baseline or candidate is absent from the registry.")
    eligible = [entry["name"] for entry in registry if entry["eligible_for_adoption"]]
    if eligible != [protocol["primary_candidate"]]:
        raise ValueError("Only the protocol-designated Ticket 3 candidate may be eligible for adoption.")
    heldout = {entry["name"] for entry in registry if entry["heldout_after_freeze"]}
    if heldout != required:
        raise ValueError("Only baseline and primary candidate may receive held-out scores.")
    numeric_groups = set(protocol["numeric_feature_map"])
    unknown_groups = {
        group
        for entry in registry
        for group in entry["feature_groups"]
        if group not in numeric_groups | {"text", "keyword", "location"}
    }
    if unknown_groups:
        raise ValueError(f"Unknown Ticket 3 feature groups: {sorted(unknown_groups)}")
    paired_names = {
        name
        for pair in protocol["feature_pairs"]
        for name in (pair["isolated_model"], pair["incremental_model"])
    }
    if not paired_names.issubset(names):
        raise ValueError("Ticket 3 feature-pair registry references unknown models.")
    return protocol


def url_only_preprocess(text: str) -> str:
    value = str(text).lower()
    value = URL_RE.sub(" url ", value)
    return SPACE_RE.sub(" ", value).strip()


def clean_keyword(series: pd.Series) -> pd.Series:
    return (
        series.fillna("__missing__")
        .astype(str)
        .str.replace("%20", " ", regex=False)
        .str.lower()
        .str.replace(r"\s+", " ", regex=True)
        .str.strip()
    )


def clean_location(series: pd.Series) -> pd.Series:
    return (
        series.fillna("__missing__")
        .astype(str)
        .str.lower()
        .str.replace(r"\s+", " ", regex=True)
        .str.strip()
    )


def keyword_occurs_in_text(keyword: str, text: str) -> bool:
    if keyword == "__missing__" or not keyword:
        return False
    pattern = r"(?<!\w)" + re.escape(keyword) + r"(?!\w)"
    return re.search(pattern, str(text).lower()) is not None


def prepare_frame(frame: pd.DataFrame, protocol: dict) -> pd.DataFrame:
    output = frame.copy()
    text = output["text"].fillna("").astype(str)
    output["keyword_clean"] = clean_keyword(output["keyword"])
    output["location_clean"] = clean_location(output["location"])
    output["keyword_present"] = output["keyword"].notna().astype(float)
    output["location_present"] = output["location"].notna().astype(float)
    output["char_len"] = text.str.len().astype(float)
    output["word_len"] = text.str.split().str.len().astype(float)
    output["exclamation_count"] = text.str.count("!").astype(float)
    output["question_count"] = text.str.count(r"\?").astype(float)
    letters = text.str.count(r"[A-Za-z]").clip(lower=1).astype(float)
    output["uppercase_ratio"] = text.str.count(r"[A-Z]").astype(float) / letters
    output["url_count"] = text.str.count(r"(?i)https?://|www\.").astype(float)
    output["mention_count"] = text.str.count(MENTION_RE).astype(float)
    output["hashtag_count"] = text.str.count(HASHTAG_RE).astype(float)
    output["url_present"] = (output["url_count"] > 0).astype(float)
    output["mention_present"] = (output["mention_count"] > 0).astype(float)
    output["hashtag_present"] = (output["hashtag_count"] > 0).astype(float)
    output["keyword_in_text"] = [
        keyword_occurs_in_text(keyword, value)
        for keyword, value in zip(output["keyword_clean"], text)
    ]
    missing_columns = set(protocol["numeric_feature_map"].values()) - set(output.columns)
    if missing_columns:
        raise ValueError(f"Ticket 3 failed to construct columns: {sorted(missing_columns)}")
    return output


def make_model(
    feature_groups: list[str], protocol: dict, text_preprocessor: str = "identity"
) -> Pipeline:
    params = protocol["shared_pipeline_params"]
    random_state = int(protocol["random_state"])
    max_features = params.get("max_features")
    if text_preprocessor == "identity":
        preprocessor = None
        lowercase = True
    elif text_preprocessor == "url":
        preprocessor = url_only_preprocess
        lowercase = False
    else:
        raise ValueError(f"Unknown Ticket 3 text preprocessor: {text_preprocessor}")
    if feature_groups == ["text"]:
        return make_text_pipeline(
            preprocessor=preprocessor,
            lowercase=lowercase,
            max_features=max_features,
            stop_words=params["stop_words"],
            sublinear_tf=bool(params["sublinear_tf"]),
            class_weight=params["class_weight"],
            c=float(params["c"]),
            random_state=random_state,
        )

    transformers = []
    if "text" in feature_groups:
        transformers.append(
            (
                "text",
                TfidfVectorizer(
                    preprocessor=preprocessor,
                    lowercase=lowercase,
                    max_features=max_features,
                    stop_words=params["stop_words"],
                    sublinear_tf=bool(params["sublinear_tf"]),
                ),
                "text",
            )
        )
    if "keyword" in feature_groups:
        transformers.append(
            (
                "keyword",
                OneHotEncoder(handle_unknown="ignore"),
                ["keyword_clean"],
            )
        )
    for feature_group, column_name in protocol["numeric_feature_map"].items():
        if feature_group in feature_groups:
            transformers.append(
                (
                    feature_group,
                    StandardScaler(),
                    [column_name],
                )
            )
    if "location" in feature_groups:
        transformers.append(
            (
                "location",
                OneHotEncoder(handle_unknown="ignore"),
                ["location_clean"],
            )
        )
    if not transformers:
        raise ValueError("A Ticket 3 model cannot have zero feature groups.")

    return Pipeline(
        [
            ("features", ColumnTransformer(transformers)),
            (
                "classifier",
                LogisticRegression(
                    class_weight=params["class_weight"],
                    C=float(params["c"]),
                    max_iter=1000,
                    random_state=random_state,
                ),
            ),
        ]
    )


def score_model(model: Pipeline, frame: pd.DataFrame, feature_groups: list[str]) -> np.ndarray:
    if feature_groups == ["text"]:
        return predict_scores(model, frame)
    return np.asarray(model.predict_proba(frame)[:, 1], dtype=float)


def metric_columns(prefix: str, metrics: dict) -> dict:
    return {
        f"{prefix}_precision_target_1": metrics["precision_target_1"],
        f"{prefix}_recall_target_1": metrics["recall_target_1"],
        f"{prefix}_f1_target_1": metrics["f1_target_1"],
        f"{prefix}_accuracy": metrics["accuracy"],
        f"{prefix}_tn": metrics["tn"],
        f"{prefix}_fp": metrics["fp"],
        f"{prefix}_fn": metrics["fn"],
        f"{prefix}_tp": metrics["tp"],
    }


def binary_f1_from_predictions(
    y_true: np.ndarray, prediction: np.ndarray
) -> float:
    y = np.asarray(y_true, dtype=bool)
    predicted = np.asarray(prediction, dtype=bool)
    true_positive = int(np.sum(y & predicted))
    false_positive = int(np.sum(~y & predicted))
    false_negative = int(np.sum(y & ~predicted))
    denominator = 2 * true_positive + false_positive + false_negative
    return 0.0 if denominator == 0 else (2.0 * true_positive) / denominator


def paired_bootstrap_delta(
    y_true: np.ndarray,
    baseline_score: np.ndarray,
    candidate_score: np.ndarray,
    *,
    threshold: float,
    resamples: int,
    seed: int,
    family_size: int = 1,
) -> dict:
    rng = np.random.default_rng(seed)
    size = len(y_true)
    values = np.empty(resamples, dtype=float)
    baseline_prediction = np.asarray(baseline_score) >= threshold
    candidate_prediction = np.asarray(candidate_score) >= threshold
    for index in range(resamples):
        sample = rng.integers(0, size, size=size)
        baseline_f1 = binary_f1_from_predictions(
            y_true[sample], baseline_prediction[sample]
        )
        candidate_f1 = binary_f1_from_predictions(
            y_true[sample], candidate_prediction[sample]
        )
        values[index] = candidate_f1 - baseline_f1
    lower, median, upper = np.quantile(values, [0.025, 0.5, 0.975])
    corrected_alpha = 0.05 / max(1, family_size)
    corrected_lower, corrected_upper = np.quantile(
        values, [corrected_alpha / 2, 1 - corrected_alpha / 2]
    )
    return {
        "bootstrap_resamples": resamples,
        "comparison_family_size": family_size,
        "ci_2_5": float(lower),
        "median_delta": float(median),
        "ci_97_5": float(upper),
        "bonferroni_ci_lower": float(corrected_lower),
        "bonferroni_ci_upper": float(corrected_upper),
        "probability_delta_gt_zero": float(np.mean(values > 0)),
    }


def exact_correctness_test(
    y_true: np.ndarray,
    baseline_score: np.ndarray,
    candidate_score: np.ndarray,
    threshold: float,
) -> dict:
    baseline_correct = (baseline_score >= threshold) == y_true
    candidate_correct = (candidate_score >= threshold) == y_true
    baseline_only = int(np.sum(baseline_correct & ~candidate_correct))
    candidate_only = int(np.sum(~baseline_correct & candidate_correct))
    discordant = baseline_only + candidate_only
    p_value = 1.0 if discordant == 0 else float(
        binomtest(candidate_only, discordant, p=0.5, alternative="two-sided").pvalue
    )
    return {
        "baseline_correct_candidate_wrong": baseline_only,
        "baseline_wrong_candidate_correct": candidate_only,
        "discordant_correctness_pairs": discordant,
        "exact_mcnemar_p_value": p_value,
    }


def total_variation(reference: pd.Series, comparison: pd.Series) -> float:
    left = reference.value_counts(normalize=True)
    right = comparison.value_counts(normalize=True)
    categories = left.index.union(right.index)
    return float(0.5 * np.abs(left.reindex(categories, fill_value=0) - right.reindex(categories, fill_value=0)).sum())


def build_shift_audit(
    train: pd.DataFrame, dev: pd.DataFrame, heldout: pd.DataFrame
) -> pd.DataFrame:
    rows = []
    split_frames = {"train": train, "dev": dev, "heldout": heldout}
    for field, clean_column, present_column in (
        ("keyword", "keyword_clean", "keyword_present"),
        ("location", "location_clean", "location_present"),
    ):
        known = set(train.loc[train[present_column] == 1, clean_column])
        reference = train[clean_column]
        for split_name, frame in split_frames.items():
            present = frame[present_column] == 1
            present_values = frame.loc[present, clean_column]
            unseen = ~present_values.isin(known)
            rows.append(
                {
                    "field": field,
                    "split": split_name,
                    "rows": len(frame),
                    "coverage": float(present.mean()),
                    "unique_present_values": int(present_values.nunique()),
                    "unseen_present_rows_vs_train": int(unseen.sum()),
                    "unseen_rate_among_present_vs_train": float(unseen.mean()) if len(unseen) else 0.0,
                    "total_variation_vs_train": 0.0
                    if split_name == "train"
                    else total_variation(reference, frame[clean_column]),
                }
            )
    return pd.DataFrame(rows)


def extract_categorical_coefficients(
    model: Pipeline, transformer_name: str, column_name: str
) -> dict[str, float]:
    feature_names = model.named_steps["features"].get_feature_names_out()
    coefficients = model.named_steps["classifier"].coef_[0]
    prefix = f"{transformer_name}__{column_name}_"
    output = {}
    for feature, coefficient in zip(feature_names, coefficients):
        if feature.startswith(prefix):
            output[feature[len(prefix) :]] = float(coefficient)
    return output


def build_keyword_audit(
    train: pd.DataFrame,
    dev: pd.DataFrame,
    heldout: pd.DataFrame,
    keyword_only_model: Pipeline,
    candidate_model: Pipeline,
) -> pd.DataFrame:
    isolated_coefficients = extract_categorical_coefficients(
        keyword_only_model, "keyword", "keyword_clean"
    )
    candidate_coefficients = extract_categorical_coefficients(
        candidate_model, "keyword", "keyword_clean"
    )
    categories = sorted(
        set(train["keyword_clean"]) | set(dev["keyword_clean"]) | set(heldout["keyword_clean"])
    )
    rows = []
    for keyword in categories:
        train_group = train.loc[train["keyword_clean"] == keyword]
        dev_group = dev.loc[dev["keyword_clean"] == keyword]
        heldout_group = heldout.loc[heldout["keyword_clean"] == keyword]
        rows.append(
            {
                "keyword": keyword,
                "train_count": len(train_group),
                "dev_count": len(dev_group),
                "heldout_count": len(heldout_group),
                "train_positive_rate": float(train_group["target"].mean()) if len(train_group) else np.nan,
                "dev_positive_rate": float(dev_group["target"].mean()) if len(dev_group) else np.nan,
                "train_text_overlap_rate": float(train_group["keyword_in_text"].mean()) if len(train_group) else np.nan,
                "dev_text_overlap_rate": float(dev_group["keyword_in_text"].mean()) if len(dev_group) else np.nan,
                "keyword_only_coefficient": isolated_coefficients.get(keyword, np.nan),
                "text_plus_keyword_coefficient": candidate_coefficients.get(keyword, np.nan),
            }
        )
    return pd.DataFrame(rows)


def prediction_changes(
    frame: pd.DataFrame,
    baseline_score: np.ndarray,
    candidate_score: np.ndarray,
    threshold: float,
) -> pd.DataFrame:
    y_true = frame["target"].to_numpy(dtype=int)
    baseline_prediction = (baseline_score >= threshold).astype(int)
    candidate_prediction = (candidate_score >= threshold).astype(int)
    changed = baseline_prediction != candidate_prediction
    change_type = np.select(
        [
            changed & (y_true == 0) & (baseline_prediction == 1),
            changed & (y_true == 1) & (baseline_prediction == 0),
            changed & (y_true == 0) & (candidate_prediction == 1),
            changed & (y_true == 1) & (candidate_prediction == 0),
        ],
        ["fixed_fp", "fixed_fn", "new_fp", "new_fn"],
        default="unchanged",
    )
    output = pd.DataFrame(
        {
            "id": frame["id"].astype(int),
            "y_true": y_true,
            "baseline_pred": baseline_prediction,
            "candidate_pred": candidate_prediction,
            "baseline_score": baseline_score,
            "candidate_score": candidate_score,
            "change_type": change_type,
            "score_delta": candidate_score - baseline_score,
            "keyword": frame["keyword_clean"],
            "keyword_present": frame["keyword_present"].astype(bool),
            "keyword_in_text": frame["keyword_in_text"].astype(bool),
            "location_present": frame["location_present"].astype(bool),
            "text": frame["text"].fillna("").astype(str),
        }
    )
    return output.loc[changed].sort_values(["change_type", "id"]).reset_index(drop=True)


def build_subgroup_metrics(
    split_name: str,
    frame: pd.DataFrame,
    scores: dict[str, np.ndarray],
    threshold: float,
) -> list[dict]:
    masks = {
        "all": np.ones(len(frame), dtype=bool),
        "keyword_present": frame["keyword_present"].to_numpy(dtype=bool),
        "keyword_missing": ~frame["keyword_present"].to_numpy(dtype=bool),
        "keyword_in_text": frame["keyword_in_text"].to_numpy(dtype=bool),
        "keyword_not_in_text": ~frame["keyword_in_text"].to_numpy(dtype=bool),
        "location_present": frame["location_present"].to_numpy(dtype=bool),
        "location_missing": ~frame["location_present"].to_numpy(dtype=bool),
    }
    rows = []
    for model_name, score in scores.items():
        for subgroup, mask in masks.items():
            if not mask.any():
                continue
            metrics = binary_metrics(frame.loc[mask, "target"], score[mask], threshold)
            rows.append(
                {
                    "split": split_name,
                    "model_name": model_name,
                    "subgroup": subgroup,
                    "rows": int(mask.sum()),
                    "positive_rate": float(frame.loc[mask, "target"].mean()),
                    "precision_target_1": metrics["precision_target_1"],
                    "recall_target_1": metrics["recall_target_1"],
                    "f1_target_1": metrics["f1_target_1"],
                    "accuracy": metrics["accuracy"],
                }
            )
    return rows


def make_counter_association_mapping(train: pd.DataFrame, minimum_count: int) -> dict[str, str]:
    association = train.groupby("keyword_clean")["target"].agg(["size", "mean"])
    association = association.loc[
        (association.index != "__missing__") & (association["size"] >= minimum_count)
    ].sort_values(["mean", "size"], ascending=[True, False])
    values = association.index.tolist()
    return {left: right for left, right in zip(values, reversed(values))}


def stress_result(
    model_name: str,
    stress_name: str,
    replicate: int,
    seed: int,
    intervention_rows: int,
    y_true: np.ndarray,
    identity_score: np.ndarray,
    score: np.ndarray,
    threshold: float,
) -> dict:
    return {
        "model_name": model_name,
        "stress_test": stress_name,
        "replicate": replicate,
        "seed": seed,
        "intervention_rows": intervention_rows,
        "dev_f1_target_1": float(
            f1_score(y_true, score >= threshold, zero_division=0)
        ),
        "prediction_changes_vs_identity": int(
            np.sum((score >= threshold) != (identity_score >= threshold))
        ),
        "mean_absolute_score_delta": float(np.mean(np.abs(score - identity_score))),
        "max_absolute_score_delta": float(np.max(np.abs(score - identity_score))),
    }


def summarize_stress(replicates: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for (model_name, stress_name), group in replicates.groupby(
        ["model_name", "stress_test"], sort=False
    ):
        rows.append(
            {
                "model_name": model_name,
                "stress_test": stress_name,
                "replicates": len(group),
                "intervention_rows_mean": float(group["intervention_rows"].mean()),
                "dev_f1_mean": float(group["dev_f1_target_1"].mean()),
                "dev_f1_std": float(group["dev_f1_target_1"].std(ddof=0)),
                "dev_f1_2_5": float(group["dev_f1_target_1"].quantile(0.025)),
                "dev_f1_median": float(group["dev_f1_target_1"].median()),
                "dev_f1_97_5": float(group["dev_f1_target_1"].quantile(0.975)),
                "prediction_changes_mean": float(group["prediction_changes_vs_identity"].mean()),
                "prediction_changes_2_5": float(group["prediction_changes_vs_identity"].quantile(0.025)),
                "prediction_changes_median": float(group["prediction_changes_vs_identity"].median()),
                "prediction_changes_97_5": float(group["prediction_changes_vs_identity"].quantile(0.975)),
                "mean_absolute_score_delta": float(group["mean_absolute_score_delta"].mean()),
                "max_absolute_score_delta": float(group["max_absolute_score_delta"].max()),
            }
        )
    return pd.DataFrame(rows)


def verify_ticket_dependencies(
    dev_frame: pd.DataFrame,
    heldout_frame: pd.DataFrame,
    controlled_dev_score: np.ndarray,
    controlled_heldout_score: np.ndarray,
    url_sensitivity_dev_score: np.ndarray,
) -> dict:
    ticket1_dev_path = PREDICTIONS_DIR / "ticket_1_dev_predictions.csv"
    ticket1_heldout_path = PREDICTIONS_DIR / "ticket_1_controlled_baseline_heldout.csv"
    ticket2_dev_path = PREDICTIONS_DIR / "ticket_2_dev_predictions.csv"
    if not all(
        path.exists()
        for path in (ticket1_dev_path, ticket1_heldout_path, ticket2_dev_path)
    ):
        raise FileNotFoundError("Run Tickets 1 and 2 before Ticket 3.")

    ticket1_dev = pd.read_csv(ticket1_dev_path)
    ticket1_dev = ticket1_dev.loc[
        ticket1_dev["model_name"] == "unweighted_controlled_baseline",
        ["id", "score"],
    ]
    ticket1_heldout = pd.read_csv(ticket1_heldout_path)[["id", "score"]]
    ticket2_dev = pd.read_csv(ticket2_dev_path)
    ticket2_dev = ticket2_dev.loc[
        ticket2_dev["model_name"] == "url_only_normalization", ["id", "score"]
    ]

    def reference_scores(frame: pd.DataFrame, reference: pd.DataFrame) -> np.ndarray:
        lookup = reference.set_index("id")["score"]
        values = frame["id"].map(lookup).to_numpy(dtype=float)
        if np.isnan(values).any():
            raise ValueError("Dependency prediction IDs do not cover the Ticket 3 split.")
        return values

    controlled_dev_reference = reference_scores(dev_frame, ticket1_dev)
    controlled_heldout_reference = reference_scores(heldout_frame, ticket1_heldout)
    url_dev_reference = reference_scores(dev_frame, ticket2_dev)
    audit = {
        "main_anchor": "unweighted_controlled_baseline",
        "ticket2_sensitivity_anchor": "url_only_normalization",
        "dev_rows_compared": len(controlled_dev_score),
        "heldout_rows_compared": len(controlled_heldout_score),
        "controlled_dev_max_absolute_score_difference": float(
            np.max(np.abs(controlled_dev_score - controlled_dev_reference))
        ),
        "controlled_heldout_max_absolute_score_difference": float(
            np.max(np.abs(controlled_heldout_score - controlled_heldout_reference))
        ),
        "url_sensitivity_dev_max_absolute_score_difference": float(
            np.max(np.abs(url_sensitivity_dev_score - url_dev_reference))
        ),
        "tolerance": 1e-12,
    }
    audit["within_tolerance"] = bool(
        audit["controlled_dev_max_absolute_score_difference"] <= audit["tolerance"]
        and audit["controlled_heldout_max_absolute_score_difference"]
        <= audit["tolerance"]
        and audit["url_sensitivity_dev_max_absolute_score_difference"]
        <= audit["tolerance"]
    )
    if not audit["within_tolerance"]:
        raise AssertionError("Ticket 3 did not reproduce its frozen dependency anchors.")
    return audit


def clean_markdown(value: object, limit: int = 118) -> str:
    text = re.sub(r"\s+", " ", str(value)).strip().replace("|", "\\|")
    return text if len(text) <= limit else text[: limit - 1] + "…"


def markdown_table(frame: pd.DataFrame, columns: list[str]) -> str:
    lines = [
        "| " + " | ".join(columns) + " |",
        "| " + " | ".join(["---"] * len(columns)) + " |",
    ]
    for row in frame.loc[:, columns].itertuples(index=False, name=None):
        lines.append("| " + " | ".join(clean_markdown(value) for value in row) + " |")
    return "\n".join(lines)


def balanced_examples(changes: pd.DataFrame, per_type: int = 2) -> pd.DataFrame:
    parts = []
    for category in ("fixed_fp", "fixed_fn", "new_fp", "new_fn"):
        group = changes.loc[changes["change_type"] == category].copy()
        if group.empty:
            continue
        group["boundary_distance"] = np.minimum(
            np.abs(group["baseline_score"] - 0.5),
            np.abs(group["candidate_score"] - 0.5),
        )
        parts.append(
            group.sort_values(
                ["keyword_in_text", "boundary_distance"], ascending=[True, True]
            ).head(per_type)
        )
    return pd.concat(parts, ignore_index=True) if parts else changes.head(0)


def write_ticket_document(
    protocol: dict,
    ablation: pd.DataFrame,
    statistics: pd.DataFrame,
    stress: pd.DataFrame,
    shift: pd.DataFrame,
    keyword_audit: pd.DataFrame,
    subgroup: pd.DataFrame,
    changes: pd.DataFrame,
    mechanism: dict,
    decision: str,
) -> None:
    baseline = ablation.loc[ablation["model_name"] == protocol["baseline_model"]].iloc[0]
    candidate = ablation.loc[ablation["model_name"] == protocol["primary_candidate"]].iloc[0]
    dev_stats = statistics.loc[statistics["analysis"] == "candidate_minus_baseline_dev"].iloc[0]
    heldout_stats = statistics.loc[
        statistics["analysis"] == "candidate_minus_baseline_heldout"
    ].iloc[0]
    candidate_permutation = stress.loc[
        (stress["model_name"] == protocol["primary_candidate"])
        & (stress["stress_test"] == "keyword_permuted")
    ].iloc[0]
    candidate_mask = stress.loc[
        (stress["model_name"] == protocol["primary_candidate"])
        & (stress["stress_test"] == "keyword_masked")
    ].iloc[0]
    baseline_permutation = stress.loc[
        (stress["model_name"] == protocol["baseline_model"])
        & (stress["stress_test"] == "keyword_permuted")
    ].iloc[0]
    keyword_shift_dev = shift.loc[
        (shift["field"] == "keyword") & (shift["split"] == "dev")
    ].iloc[0]
    location_shift_dev = shift.loc[
        (shift["field"] == "location") & (shift["split"] == "dev")
    ].iloc[0]
    location_shift_heldout = shift.loc[
        (shift["field"] == "location") & (shift["split"] == "heldout")
    ].iloc[0]
    counts = changes["change_type"].value_counts().to_dict()

    exploratory_statistics = statistics.loc[
        statistics["analysis"].str.endswith("_minus_baseline_dev_exploratory"),
        [
            "analysis",
            "observed_delta",
            "comparison_family_size",
            "bonferroni_ci_lower",
            "bonferroni_ci_upper",
            "probability_delta_gt_zero",
        ],
    ].copy()
    exploratory_statistics["analysis"] = (
        exploratory_statistics["analysis"]
        .str.replace("_minus_baseline_dev_exploratory", "", regex=False)
        .str.replace("_", " ", regex=False)
    )
    for column in (
        "observed_delta",
        "bonferroni_ci_lower",
        "bonferroni_ci_upper",
    ):
        exploratory_statistics[column] = exploratory_statistics[column].map(
            lambda value: f"{value:+.6f}"
        )
    exploratory_statistics = exploratory_statistics.rename(
        columns={"probability_delta_gt_zero": "positive_bootstrap_fraction"}
    )
    exploratory_statistics["positive_bootstrap_fraction"] = exploratory_statistics[
        "positive_bootstrap_fraction"
    ].map(lambda value: f"{value:.3f}")

    display = ablation.loc[
        :,
        [
            "model_name",
            "feature_groups",
            "role",
            "dev_f1_target_1",
            "heldout_f1_target_1",
            "heldout_evaluated_after_freeze",
        ],
    ].copy()
    display["dev_f1_target_1"] = display["dev_f1_target_1"].map(lambda value: f"{value:.6f}")
    display["heldout_f1_target_1"] = display["heldout_f1_target_1"].map(
        lambda value: "" if pd.isna(value) else f"{value:.6f}"
    )

    stress_display = stress.loc[
        stress["model_name"].isin([protocol["baseline_model"], protocol["primary_candidate"]]),
        [
            "model_name",
            "stress_test",
            "replicates",
            "dev_f1_median",
            "dev_f1_2_5",
            "dev_f1_97_5",
            "prediction_changes_median",
        ],
    ].copy()
    for column in ("dev_f1_median", "dev_f1_2_5", "dev_f1_97_5"):
        stress_display[column] = stress_display[column].map(lambda value: f"{value:.6f}")

    example_display = balanced_examples(changes).loc[
        :,
        [
            "id",
            "y_true",
            "change_type",
            "keyword",
            "keyword_in_text",
            "baseline_score",
            "candidate_score",
            "text",
        ],
    ].copy()
    for column in ("baseline_score", "candidate_score"):
        example_display[column] = example_display[column].map(lambda value: f"{value:.4f}")

    top_positive = keyword_audit.loc[
        keyword_audit["train_count"] >= 10
    ].nlargest(5, "text_plus_keyword_coefficient")
    top_negative = keyword_audit.loc[
        keyword_audit["train_count"] >= 10
    ].nsmallest(5, "text_plus_keyword_coefficient")
    coefficient_display = pd.concat([top_positive, top_negative]).loc[
        :,
        [
            "keyword",
            "train_count",
            "train_positive_rate",
            "dev_positive_rate",
            "train_text_overlap_rate",
            "text_plus_keyword_coefficient",
        ],
    ]
    for column in (
        "train_positive_rate",
        "dev_positive_rate",
        "train_text_overlap_rate",
        "text_plus_keyword_coefficient",
    ):
        coefficient_display[column] = coefficient_display[column].map(
            lambda value: f"{value:.4f}"
        )

    dev_subgroup = subgroup.loc[
        (subgroup["split"] == "dev")
        & subgroup["subgroup"].isin(["keyword_in_text", "keyword_not_in_text"]),
        ["model_name", "subgroup", "rows", "f1_target_1"],
    ].copy()
    dev_subgroup["f1_target_1"] = dev_subgroup["f1_target_1"].map(
        lambda value: f"{value:.6f}"
    )

    content = f"""# Ticket 3 — Feature and shortcut audit

## Answer in one sentence

The `keyword` field contains substantial but mixed signal—{mechanism['keyword_text_overlap_dev']:.1%} of dev rows repeat it in the tweet text, yet counterfactual permutation changes a median {candidate_permutation.prediction_changes_median:.0f} candidate decisions. Adding it to the common unweighted controlled text anchor changes dev F1 from {baseline.dev_f1_target_1:.6f} to {candidate.dev_f1_target_1:.6f}; because the paired interval required by the frozen decision rule [{dev_stats.ci_2_5:+.6f}, {dev_stats.ci_97_5:+.6f}] does not establish a positive gain, the feature decision is **{decision.upper()}** and keyword remains an audit signal.

## Frozen protocol and leakage control

The ticket hypothesis is that `keyword` can contain legitimate event semantics while also potentially encoding dataset construction, and that other shallow fields may predict labels without adding stable information beyond the same text anchor.

`configs/ticket3_protocol.json` fixes the controlled representation, unweighted classifier, individual model registry, threshold, seeds, intervention count, and decision rule. Only `text_plus_keyword` is eligible: it must beat `controlled_text` on dev **and** have a paired-bootstrap lower bound above zero. All other isolated and one-feature incremental probes are dev-only and therefore have blank held-out cells. After that decision is frozen, only baseline and candidate are scored on held-out; those scores cannot reverse the decision. Class weighting remains `None` throughout Ticket 3 and is deferred to Ticket 4.

The independently refitted main baseline matches Ticket 1's controlled prediction artifacts with maximum score differences {mechanism['controlled_anchor_dev_max_abs_diff']:.3g} on dev and {mechanism['controlled_anchor_heldout_max_abs_diff']:.3g} on held-out. The separate URL-normalized sensitivity anchor matches Ticket 2 on dev within {mechanism['ticket2_url_sensitivity_dev_max_abs_diff']:.3g}.

## Component-separated dev audit

{markdown_table(display, list(display.columns))}

Keyword alone quantifies association, while `text_plus_keyword` tests incremental information beyond the tweet. Character length, word length, URL/mention/hashtag presence, punctuation counts, uppercase ratio, field missingness, and exact location each receive their own isolated and incremental row. No bundled result is used for causal attribution.

Every incremental exploratory control is compared with the same controlled baseline using paired dev resampling and a familywise interval:

{markdown_table(exploratory_statistics, list(exploratory_statistics.columns))}

These comparisons are not eligible to replace the confirmatory candidate. They distinguish how much a shallow feature predicts alone from how much, if anything, it adds after TF-IDF.

## Paired uncertainty and frozen held-out evidence

The dev F1 difference is {dev_stats.observed_delta:+.6f}, with 5,000-resample paired 95% interval [{dev_stats.ci_2_5:+.6f}, {dev_stats.ci_97_5:+.6f}], positive-bootstrap fraction={dev_stats.probability_delta_gt_zero:.3f}, and exact paired-correctness p={dev_stats.exact_mcnemar_p_value:.4f}. This fails the protocol-specified adoption rule.

After freezing the decision, candidate held-out precision/recall/F1 are {candidate.heldout_precision_target_1:.6f}/{candidate.heldout_recall_target_1:.6f}/{candidate.heldout_f1_target_1:.6f}, versus baseline {baseline.heldout_precision_target_1:.6f}/{baseline.heldout_recall_target_1:.6f}/{baseline.heldout_f1_target_1:.6f}. The held-out F1 difference is {heldout_stats.observed_delta:+.6f}, paired interval [{heldout_stats.ci_2_5:+.6f}, {heldout_stats.ci_97_5:+.6f}], and exact p={heldout_stats.exact_mcnemar_p_value:.4f}; this is final held-out benchmark evidence and cannot reopen selection. Under Ticket 2 URL normalization, the development keyword increment is {mechanism['url_sensitivity_keyword_delta_f1']:+.6f} with interval [{mechanism['url_sensitivity_keyword_ci_2_5']:+.6f}, {mechanism['url_sensitivity_keyword_ci_97_5']:+.6f}], so representation sensitivity is reported without changing the main decision rule.

## Counterfactual reliance tests

{markdown_table(stress_display, list(stress_display.columns))}

Keyword masking and permutation leave the controlled text-only model exactly unchanged, an internal negative control. For `text_plus_keyword`, masking produces F1 {candidate_mask.dev_f1_median:.6f}; 200 seeded permutations preserve keyword prevalence and its marginal category distribution but break alignment with each tweet, yielding median F1 {candidate_permutation.dev_f1_median:.6f} and interval [{candidate_permutation.dev_f1_2_5:.6f}, {candidate_permutation.dev_f1_97_5:.6f}]. These interventions establish model reliance, not real-world causal effects. The baseline's permutation median is {baseline_permutation.dev_f1_median:.6f} with zero changed decisions.

## Is the signal task information, artifact, or mixed?

- **Keyword: mixed.** Coverage is {keyword_shift_dev.coverage:.1%}, no present dev keyword is unseen from train, and {mechanism['keyword_text_overlap_dev']:.1%} of rows literally contain the decoded keyword in the tweet. For {int(mechanism['stable_keyword_categories'])} sufficiently represented categories, train-versus-dev positive-rate Spearman correlation is {mechanism['keyword_rate_spearman']:.3f}. These support real event-type semantics. However, the field is supplied separately by the benchmark, strongly predictive by itself, redundant beyond text, and counterfactually influential, so it is also a benchmark-construction shortcut.
- **Exact location: artifact-prone.** Among non-missing locations, {location_shift_dev.unseen_rate_among_present_vs_train:.1%} of dev and {location_shift_heldout.unseen_rate_among_present_vs_train:.1%} of held-out values are unseen in train. Exact strings behave like sparse identities rather than a portable geographic representation and are ineligible for adoption.
- **Surface form: mixed but weak.** Length, punctuation, casing, URL, mention, and hashtag counts come from the tweet itself, so they can reflect legitimate reporting style; they are also sensitive to platform and formatting changes. Their isolated and incremental rows quantify signal without treating it as stable semantics.
- **Missingness: collection-process evidence.** Keyword/location presence can describe how records were assembled. It is audited separately and not interpreted as disaster content.

Top train-supported keyword coefficients illustrate semantic association while the train/dev rates prevent a coefficient-only story:

{markdown_table(coefficient_display, list(coefficient_display.columns))}

## Redundancy subgroup check

{markdown_table(dev_subgroup, list(dev_subgroup.columns))}

The lexical-overlap split is a protocol-specified, non-selecting subgroup diagnostic. It distinguishes rows where keyword repeats visible text from the minority where it contributes metadata not literally present. Subgroup differences remain descriptive because the groups are not randomized and some are much smaller.

## All held-out prediction movements

Relative to the frozen text baseline, the rejected candidate fixes {counts.get('fixed_fp', 0)} false positives and {counts.get('fixed_fn', 0)} false negatives while creating {counts.get('new_fp', 0)} false positives and {counts.get('new_fn', 0)} false negatives. {mechanism['changed_keyword_not_in_text_share']:.1%} of changed predictions occur where the keyword is not literally in text, compared with {1.0 - mechanism['keyword_text_overlap_heldout']:.1%} of all held-out rows; this enrichment is consistent with incremental metadata reliance.

{markdown_table(example_display, list(example_display.columns))}

Examples are balanced by movement type where available and keyed by stable IDs. They illustrate mechanisms; the complete CSV, not these examples, supports the aggregate counts.

## Decision

**{decision.upper()} `text_plus_keyword` on the controlled main audit.** Keyword remains useful for auditing dataset construction and error slices. The downstream Ticket 4 pipeline combines Ticket 2's frozen URL normalization with only the features accepted here; when keyword is rejected, that means URL-normalized text without shallow additions.

## Limitations

Permutation and rank-reversal are artificial interventions and do not identify the performance of a particular deployment population. Lexical overlap is a conservative exact-phrase measure and misses paraphrases. Label-rate correlations do not prove causality. Location could become legitimate with a separately designed geographic normalization, but exact user strings cannot support that claim here. Results remain conditional on one fixed benchmark split.

Artifacts: `configs/ticket3_protocol.json`, `results/ticket3_ablation.csv`, `results/ticket3_feature_audit.csv`, `results/ticket3_statistics.csv`, `results/ticket3_stress_summary.csv`, `results/ticket3_stress_replicates.csv`, `results/ticket3_shift_audit.csv`, `results/ticket3_keyword_audit.csv`, `results/ticket3_subgroup_metrics.csv`, `results/ticket3_prediction_changes.csv`, `results/ticket3_mechanism_summary.json`, and `predictions/ticket_3_selected_heldout.csv`.
"""
    TICKET_PATH.write_text(content.strip() + "\n", encoding="utf-8")


def update_interfaces(
    protocol: dict,
    ablation: pd.DataFrame,
    changes: pd.DataFrame,
    decision: str,
    mechanism: dict,
) -> None:
    baseline = ablation.loc[ablation["model_name"] == protocol["baseline_model"]].iloc[0]
    candidate = ablation.loc[ablation["model_name"] == protocol["primary_candidate"]].iloc[0]
    selected = candidate if decision == "adopt" else baseline
    selected_name = (
        protocol["primary_candidate"] if decision == "adopt" else protocol["baseline_model"]
    )
    counts = changes["change_type"].value_counts().to_dict()

    summary_path = RESULTS_DIR / "summary.csv"
    if summary_path.exists():
        summary = pd.read_csv(summary_path)
        row = {
            "ticket": "ticket_3",
            "model_name": selected_name,
            "dev_f1_target_1": selected["dev_f1_target_1"],
            "heldout_f1_target_1": selected["heldout_f1_target_1"],
            "heldout_accuracy": selected["heldout_accuracy"],
            "fixed_fp": int(counts.get("fixed_fp", 0)),
            "fixed_fn": int(counts.get("fixed_fn", 0)),
            "new_fp": int(counts.get("new_fp", 0)),
            "new_fn": int(counts.get("new_fn", 0)),
            "decision": decision,
            "decision_reason": (
                "paired dev F1 interval is strictly positive"
                if decision == "adopt"
                else "keyword addition fails the protocol-specified paired dev improvement rule"
            ),
        }
        summary = pd.concat(
            [summary.loc[summary["ticket"] != "ticket_3"], pd.DataFrame([row])],
            ignore_index=True,
        ).sort_values("ticket")
        summary.to_csv(summary_path, index=False)

    manifest_path = RESULTS_DIR / "run_manifest.json"
    if manifest_path.exists():
        with manifest_path.open(encoding="utf-8") as handle:
            manifest = json.load(handle)
        manifest["ticket_3_protocol"] = {
            "protocol_version": protocol["protocol_version"],
            "upstream_representation": protocol["upstream_representation"],
            "ticket2_sensitivity_representation": protocol[
                "ticket2_sensitivity_representation"
            ],
            "primary_candidate": protocol["primary_candidate"],
            "decision": decision,
            "selected_features": ["keyword"] if decision == "adopt" else [],
            "selected_main_model": selected_name,
            "dev_f1": float(candidate["dev_f1_target_1"]),
            "heldout_f1": float(candidate["heldout_f1_target_1"]),
            **mechanism,
        }
        manifest["ticket_3_main_anchor_is_ticket1_controlled"] = True
        manifest["ticket_3_ticket2_sensitivity_checked"] = True
        manifest["dependency_status"] = {
            "ticket_1_complete": True,
            "ticket_2_complete": True,
            "ticket_3_complete": True,
            "ticket_4_complete": False,
            "ticket_5_complete": False,
        }
        manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True), encoding="utf-8")


def main() -> None:
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    PREDICTIONS_DIR.mkdir(parents=True, exist_ok=True)
    protocol = load_protocol()
    data = load_project_data()
    threshold = float(protocol["threshold"])
    random_state = int(protocol["random_state"])
    train = prepare_frame(data.train, protocol)
    dev = prepare_frame(data.dev, protocol)
    heldout = prepare_frame(data.heldout, protocol)

    models: dict[str, Pipeline] = {}
    feature_groups: dict[str, list[str]] = {}
    dev_scores: dict[str, np.ndarray] = {}
    ablation_rows = []

    # Phase 1: every registered model is trained on train and scored on dev only.
    for specification in protocol["dev_registry"]:
        groups = specification["feature_groups"]
        model = make_model(
            groups,
            protocol,
            text_preprocessor=specification.get("text_preprocessor", "identity"),
        )
        if groups == ["text"]:
            model.fit(train["text"].fillna(""), train["target"])
        else:
            model.fit(train, train["target"])
        score = score_model(model, dev, groups)
        metrics = binary_metrics(dev["target"], score, threshold)
        models[specification["name"]] = model
        feature_groups[specification["name"]] = groups
        dev_scores[specification["name"]] = score
        ablation_rows.append(
            {
                "model_name": specification["name"],
                "feature_groups": "+".join(groups),
                "role": specification["role"],
                "eligible_for_adoption": specification["eligible_for_adoption"],
                **metric_columns("dev", metrics),
                "dev_average_precision": float(
                    average_precision_score(dev["target"], score)
                ),
                "dev_roc_auc": float(roc_auc_score(dev["target"], score)),
                "heldout_precision_target_1": np.nan,
                "heldout_recall_target_1": np.nan,
                "heldout_f1_target_1": np.nan,
                "heldout_accuracy": np.nan,
                "heldout_tn": np.nan,
                "heldout_fp": np.nan,
                "heldout_fn": np.nan,
                "heldout_tp": np.nan,
                "heldout_average_precision": np.nan,
                "heldout_roc_auc": np.nan,
                "heldout_evaluated_after_freeze": False,
            }
        )

    baseline_name = protocol["baseline_model"]
    candidate_name = protocol["primary_candidate"]
    baseline_dev_score = dev_scores[baseline_name]
    candidate_dev_score = dev_scores[candidate_name]
    y_dev = dev["target"].to_numpy(dtype=int)
    dev_stat = {
        "analysis": "candidate_minus_baseline_dev",
        "observed_delta": float(
            f1_score(y_dev, candidate_dev_score >= threshold)
            - f1_score(y_dev, baseline_dev_score >= threshold)
        ),
        **paired_bootstrap_delta(
            y_dev,
            baseline_dev_score,
            candidate_dev_score,
            threshold=threshold,
            resamples=int(protocol["bootstrap_resamples"]),
            seed=random_state,
        ),
        **exact_correctness_test(
            y_dev, baseline_dev_score, candidate_dev_score, threshold
        ),
    }
    adopted = bool(dev_stat["observed_delta"] > 0 and dev_stat["ci_2_5"] > 0)
    decision = "adopt" if adopted else "reject"

    # Phase 2: held-out begins only after the dev decision is frozen.
    heldout_scores: dict[str, np.ndarray] = {}
    for model_name in (baseline_name, candidate_name):
        score = score_model(models[model_name], heldout, feature_groups[model_name])
        heldout_scores[model_name] = score
        metrics = binary_metrics(heldout["target"], score, threshold)
        for row in ablation_rows:
            if row["model_name"] == model_name:
                row.update(metric_columns("heldout", metrics))
                row["heldout_average_precision"] = float(
                    average_precision_score(heldout["target"], score)
                )
                row["heldout_roc_auc"] = float(
                    roc_auc_score(heldout["target"], score)
                )
                row["heldout_evaluated_after_freeze"] = True
    ablation = pd.DataFrame(ablation_rows)
    ablation.to_csv(RESULTS_DIR / "ticket3_ablation.csv", index=False)

    upstream_audit = verify_ticket_dependencies(
        dev,
        heldout,
        baseline_dev_score,
        heldout_scores[baseline_name],
        dev_scores["url_sensitivity_text"],
    )
    (RESULTS_DIR / "ticket3_upstream_audit.json").write_text(
        json.dumps(upstream_audit, indent=2, sort_keys=True), encoding="utf-8"
    )

    y_heldout = heldout["target"].to_numpy(dtype=int)
    heldout_stat = {
        "analysis": "candidate_minus_baseline_heldout",
        "observed_delta": float(
            f1_score(y_heldout, heldout_scores[candidate_name] >= threshold)
            - f1_score(y_heldout, heldout_scores[baseline_name] >= threshold)
        ),
        **paired_bootstrap_delta(
            y_heldout,
            heldout_scores[baseline_name],
            heldout_scores[candidate_name],
            threshold=threshold,
            resamples=int(protocol["bootstrap_resamples"]),
            seed=random_state + 1,
        ),
        **exact_correctness_test(
            y_heldout,
            heldout_scores[baseline_name],
            heldout_scores[candidate_name],
            threshold,
        ),
    }
    statistics_rows = [dev_stat, heldout_stat]
    exploratory_names = [
        entry["name"]
        for entry in protocol["dev_registry"]
        if entry["name"].startswith("text_plus_")
        and entry["name"] != candidate_name
        and entry.get("text_preprocessor", "identity") == "identity"
    ]
    for offset, model_name in enumerate(exploratory_names):
        control_score = dev_scores[model_name]
        statistics_rows.append(
            {
                "analysis": f"{model_name}_minus_baseline_dev_exploratory",
                "observed_delta": float(
                    f1_score(y_dev, control_score >= threshold)
                    - f1_score(y_dev, baseline_dev_score >= threshold)
                ),
                **paired_bootstrap_delta(
                    y_dev,
                    baseline_dev_score,
                    control_score,
                    threshold=threshold,
                    resamples=int(protocol["bootstrap_resamples"]),
                    seed=random_state + 20 + offset,
                    family_size=len(exploratory_names),
                ),
                **exact_correctness_test(
                    y_dev, baseline_dev_score, control_score, threshold
                ),
            }
        )
    url_sensitivity_stat = {
        "analysis": "url_sensitivity_keyword_increment_dev",
        "observed_delta": float(
            f1_score(
                y_dev,
                dev_scores["url_sensitivity_text_plus_keyword"] >= threshold,
            )
            - f1_score(y_dev, dev_scores["url_sensitivity_text"] >= threshold)
        ),
        **paired_bootstrap_delta(
            y_dev,
            dev_scores["url_sensitivity_text"],
            dev_scores["url_sensitivity_text_plus_keyword"],
            threshold=threshold,
            resamples=int(protocol["bootstrap_resamples"]),
            seed=random_state + 100,
        ),
        **exact_correctness_test(
            y_dev,
            dev_scores["url_sensitivity_text"],
            dev_scores["url_sensitivity_text_plus_keyword"],
            threshold,
        ),
    }
    statistics_rows.append(url_sensitivity_stat)
    statistics = pd.DataFrame(statistics_rows)
    statistics.to_csv(RESULTS_DIR / "ticket3_statistics.csv", index=False)

    ablation_index = ablation.set_index("model_name")
    statistics_index = statistics.set_index("analysis")
    baseline_row = ablation_index.loc[baseline_name]
    feature_audit_rows = []
    for pair in protocol["feature_pairs"]:
        isolated = ablation_index.loc[pair["isolated_model"]]
        incremental = ablation_index.loc[pair["incremental_model"]]
        analysis_name = (
            "candidate_minus_baseline_dev"
            if pair["incremental_model"] == candidate_name
            else f"{pair['incremental_model']}_minus_baseline_dev_exploratory"
        )
        interval = statistics_index.loc[analysis_name]
        feature_audit_rows.append(
            {
                "feature": pair["feature"],
                "interpretation": pair["interpretation"],
                "isolated_model": pair["isolated_model"],
                "isolated_dev_f1": isolated["dev_f1_target_1"],
                "isolated_dev_average_precision": isolated["dev_average_precision"],
                "isolated_dev_roc_auc": isolated["dev_roc_auc"],
                "isolated_predicted_positive_count": int(
                    isolated["dev_fp"] + isolated["dev_tp"]
                ),
                "incremental_model": pair["incremental_model"],
                "incremental_dev_f1": incremental["dev_f1_target_1"],
                "incremental_dev_average_precision": incremental[
                    "dev_average_precision"
                ],
                "incremental_dev_roc_auc": incremental["dev_roc_auc"],
                "incremental_predicted_positive_count": int(
                    incremental["dev_fp"] + incremental["dev_tp"]
                ),
                "incremental_f1_delta_vs_controlled_text": interval[
                    "observed_delta"
                ],
                "incremental_f1_ci_2_5": interval["ci_2_5"],
                "incremental_f1_ci_97_5": interval["ci_97_5"],
                "incremental_f1_bonferroni_lower": interval[
                    "bonferroni_ci_lower"
                ],
                "incremental_f1_bonferroni_upper": interval[
                    "bonferroni_ci_upper"
                ],
                "incremental_average_precision_delta_vs_controlled_text": (
                    incremental["dev_average_precision"]
                    - baseline_row["dev_average_precision"]
                ),
            }
        )
    feature_audit = pd.DataFrame(feature_audit_rows)
    feature_audit.to_csv(RESULTS_DIR / "ticket3_feature_audit.csv", index=False)

    changes = prediction_changes(
        heldout,
        heldout_scores[baseline_name],
        heldout_scores[candidate_name],
        threshold,
    )
    changes.to_csv(RESULTS_DIR / "ticket3_prediction_changes.csv", index=False)

    selected_name = candidate_name if adopted else baseline_name
    selected_predictions = prediction_frame(
        data.heldout,
        heldout_scores[selected_name],
        model_name=selected_name,
        ticket="ticket_3",
    )
    selected_predictions.to_csv(
        PREDICTIONS_DIR / "ticket_3_selected_heldout.csv", index=False
    )

    # Repeated and deterministic counterfactual reliance tests use dev only.
    counter_mapping = make_counter_association_mapping(
        train, int(protocol["keyword_stability_min_count_per_split"])
    )
    stress_rows = []
    for model_name in (baseline_name, candidate_name):
        identity = dev_scores[model_name]
        groups = feature_groups[model_name]
        stress_rows.append(
            stress_result(
                model_name,
                "identity",
                0,
                random_state,
                0,
                y_dev,
                identity,
                identity,
                threshold,
            )
        )

        masked = dev.copy()
        masked_rows = int((masked["keyword_clean"] != "__missing__").sum())
        masked["keyword_clean"] = "__missing__"
        score = score_model(models[model_name], masked, groups)
        stress_rows.append(
            stress_result(
                model_name,
                "keyword_masked",
                0,
                random_state,
                masked_rows,
                y_dev,
                identity,
                score,
                threshold,
            )
        )

        reversed_frame = dev.copy()
        reversed_values = reversed_frame["keyword_clean"].map(counter_mapping)
        mapped = reversed_values.notna()
        reversed_frame.loc[mapped, "keyword_clean"] = reversed_values.loc[mapped]
        score = score_model(models[model_name], reversed_frame, groups)
        stress_rows.append(
            stress_result(
                model_name,
                "keyword_counter_association",
                0,
                random_state,
                int(mapped.sum()),
                y_dev,
                identity,
                score,
                threshold,
            )
        )

        location_masked = dev.copy()
        location_rows = int((location_masked["location_clean"] != "__missing__").sum())
        location_masked["location_clean"] = "__missing__"
        score = score_model(models[model_name], location_masked, groups)
        stress_rows.append(
            stress_result(
                model_name,
                "location_masked_negative_control",
                0,
                random_state,
                location_rows,
                y_dev,
                identity,
                score,
                threshold,
            )
        )

        for replicate in range(int(protocol["permutation_repeats"])):
            seed = random_state + 1000 + replicate
            rng = np.random.default_rng(seed)
            permuted = dev.copy()
            original = permuted["keyword_clean"].to_numpy(copy=True)
            permuted_values = rng.permutation(original)
            permuted["keyword_clean"] = permuted_values
            score = score_model(models[model_name], permuted, groups)
            stress_rows.append(
                stress_result(
                    model_name,
                    "keyword_permuted",
                    replicate,
                    seed,
                    int(np.sum(original != permuted_values)),
                    y_dev,
                    identity,
                    score,
                    threshold,
                )
            )
    stress_replicates = pd.DataFrame(stress_rows)
    stress_replicates.to_csv(
        RESULTS_DIR / "ticket3_stress_replicates.csv", index=False
    )
    stress_summary = summarize_stress(stress_replicates)
    stress_summary.to_csv(RESULTS_DIR / "ticket3_stress_summary.csv", index=False)

    shift = build_shift_audit(train, dev, heldout)
    shift.to_csv(RESULTS_DIR / "ticket3_shift_audit.csv", index=False)
    keyword_audit = build_keyword_audit(
        train,
        dev,
        heldout,
        models["keyword_only"],
        models[candidate_name],
    )
    keyword_audit.to_csv(RESULTS_DIR / "ticket3_keyword_audit.csv", index=False)

    stable_keyword = keyword_audit.loc[
        (keyword_audit["train_count"] >= int(protocol["keyword_stability_min_count_per_split"]))
        & (keyword_audit["dev_count"] >= int(protocol["keyword_stability_min_count_per_split"]))
        & keyword_audit["train_positive_rate"].notna()
        & keyword_audit["dev_positive_rate"].notna()
    ]
    keyword_spearman = spearmanr(
        stable_keyword["train_positive_rate"], stable_keyword["dev_positive_rate"]
    )

    subgroup_rows = []
    subgroup_rows.extend(
        build_subgroup_metrics(
            "dev",
            dev,
            {
                baseline_name: baseline_dev_score,
                candidate_name: candidate_dev_score,
            },
            threshold,
        )
    )
    subgroup_rows.extend(
        build_subgroup_metrics(
            "heldout",
            heldout,
            {
                baseline_name: heldout_scores[baseline_name],
                candidate_name: heldout_scores[candidate_name],
            },
            threshold,
        )
    )
    subgroup = pd.DataFrame(subgroup_rows)
    subgroup.to_csv(RESULTS_DIR / "ticket3_subgroup_metrics.csv", index=False)

    location_heldout = shift.loc[
        (shift["field"] == "location") & (shift["split"] == "heldout")
    ].iloc[0]
    candidate_permutation = stress_summary.loc[
        (stress_summary["model_name"] == candidate_name)
        & (stress_summary["stress_test"] == "keyword_permuted")
    ].iloc[0]
    mechanism = {
        "controlled_anchor_dev_max_abs_diff": upstream_audit[
            "controlled_dev_max_absolute_score_difference"
        ],
        "controlled_anchor_heldout_max_abs_diff": upstream_audit[
            "controlled_heldout_max_absolute_score_difference"
        ],
        "ticket2_url_sensitivity_dev_max_abs_diff": upstream_audit[
            "url_sensitivity_dev_max_absolute_score_difference"
        ],
        "keyword_coverage_train": float(train["keyword_present"].mean()),
        "keyword_coverage_dev": float(dev["keyword_present"].mean()),
        "keyword_coverage_heldout": float(heldout["keyword_present"].mean()),
        "keyword_text_overlap_train": float(train["keyword_in_text"].mean()),
        "keyword_text_overlap_dev": float(dev["keyword_in_text"].mean()),
        "keyword_text_overlap_heldout": float(heldout["keyword_in_text"].mean()),
        "stable_keyword_categories": int(len(stable_keyword)),
        "keyword_rate_spearman": float(keyword_spearman.statistic),
        "keyword_rate_spearman_p_value": float(keyword_spearman.pvalue),
        "location_unseen_present_rate_heldout": float(
            location_heldout["unseen_rate_among_present_vs_train"]
        ),
        "permuted_candidate_median_f1": float(candidate_permutation["dev_f1_median"]),
        "permuted_candidate_median_prediction_changes": float(
            candidate_permutation["prediction_changes_median"]
        ),
        "url_sensitivity_keyword_delta_f1": float(
            url_sensitivity_stat["observed_delta"]
        ),
        "url_sensitivity_keyword_ci_2_5": float(url_sensitivity_stat["ci_2_5"]),
        "url_sensitivity_keyword_ci_97_5": float(url_sensitivity_stat["ci_97_5"]),
        "isolated_dev_f1": {
            entry["name"]: float(
                ablation.loc[
                    ablation["model_name"] == entry["name"], "dev_f1_target_1"
                ].iloc[0]
            )
            for entry in protocol["dev_registry"]
            if entry["name"].endswith("_only")
        },
        "incremental_dev_f1": {
            entry["name"]: float(
                ablation.loc[
                    ablation["model_name"] == entry["name"], "dev_f1_target_1"
                ].iloc[0]
            )
            for entry in protocol["dev_registry"]
            if entry["name"].startswith("text_plus_")
        },
        "changed_predictions": len(changes),
        "changed_keyword_not_in_text_share": float((~changes["keyword_in_text"]).mean())
        if len(changes)
        else 0.0,
    }
    (RESULTS_DIR / "ticket3_mechanism_summary.json").write_text(
        json.dumps(mechanism, indent=2, sort_keys=True), encoding="utf-8"
    )

    write_ticket_document(
        protocol,
        ablation,
        statistics,
        stress_summary,
        shift,
        keyword_audit,
        subgroup,
        changes,
        mechanism,
        decision,
    )
    update_interfaces(protocol, ablation, changes, decision, mechanism)

    print(
        f"Ticket 3 decision={decision}; baseline dev F1="
        f"{ablation.loc[ablation.model_name == baseline_name, 'dev_f1_target_1'].iloc[0]:.6f}; "
        f"candidate dev F1="
        f"{ablation.loc[ablation.model_name == candidate_name, 'dev_f1_target_1'].iloc[0]:.6f}"
    )
    print(
        f"Held-out candidate F1="
        f"{ablation.loc[ablation.model_name == candidate_name, 'heldout_f1_target_1'].iloc[0]:.6f}; "
        f"changed predictions={len(changes)}; upstream_match={upstream_audit['within_tolerance']}"
    )


if __name__ == "__main__":
    main()
