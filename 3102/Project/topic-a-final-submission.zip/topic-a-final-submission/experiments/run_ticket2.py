"""Run the Ticket 2 multi-factor text-normalization forensic protocol."""

from __future__ import annotations

import json
import re
import sys
from collections import Counter
from pathlib import Path
from typing import Callable

import numpy as np
import pandas as pd
from scipy.stats import binomtest
from sklearn.metrics import f1_score

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from pipeline.core import (  # noqa: E402
    binary_metrics,
    load_project_data,
    make_text_pipeline,
    predict_scores,
    prediction_frame,
)


PROTOCOL_PATH = PROJECT_ROOT / "configs" / "ticket2_protocol.json"
RESULTS_DIR = PROJECT_ROOT / "results"
PREDICTIONS_DIR = PROJECT_ROOT / "predictions"
TICKET_PATH = PROJECT_ROOT / "tickets" / "ticket-2-normalization.md"

URL_RE = re.compile(r"(?:https?://|www\.)\S+", flags=re.IGNORECASE)
MENTION_RE = re.compile(r"(?<!\w)@[A-Za-z0-9_]+")
HASHTAG_RE = re.compile(r"(?<!\w)#([A-Za-z0-9_]+)")
HASHTAG_PRESENCE_RE = re.compile(r"(?<!\w)#[A-Za-z0-9_]+")
CAMEL_BOUNDARY_RE = re.compile(r"(?<=[a-z0-9])(?=[A-Z])")
EMOJI_RE = re.compile(r"[\u2600-\u27BF\U0001F300-\U0001FAFF]")
SPACE_RE = re.compile(r"\s+")


def load_protocol() -> dict:
    with PROTOCOL_PATH.open(encoding="utf-8") as handle:
        protocol = json.load(handle)
    names = [entry["name"] for entry in protocol["dev_only_ablation_registry"]]
    required = {
        protocol["baseline_model"],
        protocol["candidate_model"],
        *(entry["model_name"] for entry in protocol["factor_registry"]),
        *(entry["model_name"] for entry in protocol["strategy_registry"]),
    }
    if len(names) != len(set(names)) or not required.issubset(names):
        raise ValueError("Ticket 2 protocol registry is invalid.")
    factor_names = [entry["factor"] for entry in protocol["factor_registry"]]
    if len(factor_names) != len(set(factor_names)):
        raise ValueError("Ticket 2 factor names must be unique.")
    strategy_names = [entry["model_name"] for entry in protocol["strategy_registry"]]
    if len(strategy_names) != len(set(strategy_names)):
        raise ValueError("Ticket 2 strategy model names must be unique.")
    for factor in ("url", "mention", "hashtag"):
        selected = [
            entry
            for entry in protocol["strategy_registry"]
            if entry["factor"] == factor and entry["selected_within_factor"]
        ]
        if len(selected) != 1:
            raise ValueError(f"Ticket 2 factor {factor!r} must select exactly one strategy.")
    return protocol


def verify_ticket1_controlled_baseline(
    protocol: dict,
    data: object,
    dev_score: np.ndarray,
    heldout_score: np.ndarray,
    *,
    tolerance: float = 1e-12,
) -> dict:
    """Prove that Ticket 2's unchanged arm is the Ticket 1 controlled anchor."""
    expected_name = "unweighted_controlled_baseline"
    if protocol["baseline_model"] != expected_name:
        raise ValueError("Ticket 2 must anchor on the unweighted controlled baseline.")

    dev_reference_path = PREDICTIONS_DIR / "ticket_1_dev_predictions.csv"
    heldout_reference_path = PREDICTIONS_DIR / "ticket_1_controlled_baseline_heldout.csv"
    if not dev_reference_path.exists() or not heldout_reference_path.exists():
        raise FileNotFoundError("Run Ticket 1 before Ticket 2.")

    dev_reference = pd.read_csv(dev_reference_path)
    dev_reference = dev_reference.loc[
        dev_reference["model_name"] == expected_name, ["id", "score"]
    ]
    heldout_reference = pd.read_csv(heldout_reference_path)[["id", "score"]]

    def aligned_difference(
        frame: pd.DataFrame, reference: pd.DataFrame, score: np.ndarray
    ) -> float:
        observed = pd.DataFrame(
            {"id": frame["id"].astype(int).to_numpy(), "score_observed": score}
        )
        aligned = observed.merge(
            reference.rename(columns={"score": "score_reference"}),
            on="id",
            how="inner",
            validate="one_to_one",
        )
        if len(aligned) != len(frame):
            raise ValueError("Upstream prediction IDs do not match the frozen split.")
        return float(
            np.max(np.abs(aligned["score_observed"] - aligned["score_reference"]))
        )

    dev_difference = aligned_difference(data.dev, dev_reference, dev_score)
    heldout_difference = aligned_difference(
        data.heldout, heldout_reference, heldout_score
    )
    audit = {
        "expected_anchor": expected_name,
        "ticket2_baseline": protocol["baseline_model"],
        "tolerance": tolerance,
        "dev_max_absolute_score_difference": dev_difference,
        "heldout_max_absolute_score_difference": heldout_difference,
        "within_tolerance": bool(
            dev_difference <= tolerance and heldout_difference <= tolerance
        ),
    }
    if not audit["within_tolerance"]:
        raise ValueError("Ticket 2 does not reproduce the Ticket 1 controlled anchor.")
    return audit


def hashtag_components(raw: str) -> list[str]:
    """Conservatively split only explicit underscores and CamelCase boundaries."""
    with_boundaries = CAMEL_BOUNDARY_RE.sub(" ", str(raw).replace("_", " "))
    return [part for part in SPACE_RE.split(with_boundaries) if part]


def normalize_hashtag_match(match: re.Match[str]) -> str:
    return " " + " ".join(hashtag_components(match.group(1))) + " "


def rewrite_hashtag_separator_match(match: re.Match[str]) -> str:
    components = hashtag_components(match.group(1))
    if len(components) < 2:
        return match.group(0)
    return "#" + "_".join(components)


def make_preprocessor(operations: list[str]) -> Callable[[str], str] | None:
    if not operations:
        return None
    operation_set = set(operations)

    def preprocess(text: str) -> str:
        value = str(text)
        if "url" in operation_set:
            value = URL_RE.sub(" url ", value)
        if "mention" in operation_set:
            value = MENTION_RE.sub(" user ", value)
        if "mention_remove" in operation_set:
            value = MENTION_RE.sub(" ", value)
        if "hashtag_marker" in operation_set:
            value = HASHTAG_RE.sub(r" \1 ", value)
        if "hashtag_generic" in operation_set:
            value = HASHTAG_RE.sub(" hashtag ", value)
        if "hashtag_decompose" in operation_set:
            value = HASHTAG_RE.sub(normalize_hashtag_match, value)
        return SPACE_RE.sub(" ", value.lower()).strip()

    return preprocess


def metric_columns(prefix: str, metrics: dict) -> dict:
    return {
        f"{prefix}_precision_target_1": metrics["precision_target_1"],
        f"{prefix}_recall_target_1": metrics["recall_target_1"],
        f"{prefix}_f1_target_1": metrics["f1_target_1"],
        f"{prefix}_accuracy": metrics["accuracy"],
        f"{prefix}_tn": metrics["tn"],
        f"{prefix}_fp": metrics["fp"],
        f"{prefix}_fn": metrics["fn"],
        f"{prefix}_tp": metrics["tp"],
    }


def binary_f1_from_predictions(y_true: np.ndarray, prediction: np.ndarray) -> float:
    """Compute positive-class F1 without sklearn estimator-validation overhead."""
    y = np.asarray(y_true, dtype=bool)
    predicted = np.asarray(prediction, dtype=bool)
    true_positive = int(np.sum(y & predicted))
    false_positive = int(np.sum(~y & predicted))
    false_negative = int(np.sum(y & ~predicted))
    denominator = 2 * true_positive + false_positive + false_negative
    return 0.0 if denominator == 0 else 2.0 * true_positive / denominator


def stress_text(text: pd.Series, name: str) -> pd.Series:
    value = text.fillna("").astype(str)
    if name == "identity":
        return value
    if name == "case_swapped":
        return value.str.swapcase()
    if name == "url_rewritten":
        return value.str.replace(
            r"(?i)(?:https?://|www\.)\S+",
            "https://changed.example/item",
            regex=True,
        )
    if name == "url_removed":
        return value.str.replace(r"(?i)(?:https?://|www\.)\S+", " ", regex=True)
    if name == "mention_rewritten":
        return value.str.replace(r"(?<!\w)@[A-Za-z0-9_]+", "@changeduser", regex=True)
    if name == "mention_removed":
        return value.str.replace(r"(?<!\w)@[A-Za-z0-9_]+", " ", regex=True)
    if name == "hashtag_separator_rewritten":
        return value.map(lambda item: HASHTAG_RE.sub(rewrite_hashtag_separator_match, item))
    if name == "hashtag_marker_removed":
        return value.str.replace(r"(?<!\w)#([A-Za-z0-9_]+)", r"\1", regex=True)
    if name == "emoji_appended":
        return value + " 🔥 🚨"
    if name == "combined_surface":
        value = value.str.swapcase()
        value = value.str.replace(
            r"(?i)(?:https?://|www\.)\S+",
            "https://changed.example/item",
            regex=True,
        )
        value = value.str.replace(r"(?<!\w)@[A-Za-z0-9_]+", "@changeduser", regex=True)
        value = value.str.replace(r"(?<!\w)#([A-Za-z0-9_]+)", r"\1", regex=True)
        return value + " 🔥 🚨"
    raise ValueError(f"Unknown stress variant: {name}")


def paired_bootstrap_delta(
    y_true: np.ndarray,
    old_score: np.ndarray,
    new_score: np.ndarray,
    *,
    threshold: float,
    resamples: int,
    seed: int,
    family_size: int = 1,
) -> dict:
    rng = np.random.default_rng(seed)
    size = len(y_true)
    deltas = np.empty(resamples, dtype=float)
    old_prediction = np.asarray(old_score) >= threshold
    new_prediction = np.asarray(new_score) >= threshold
    for index in range(resamples):
        sample = rng.integers(0, size, size=size)
        old_f1 = binary_f1_from_predictions(y_true[sample], old_prediction[sample])
        new_f1 = binary_f1_from_predictions(y_true[sample], new_prediction[sample])
        deltas[index] = new_f1 - old_f1
    lower, median, upper = np.quantile(deltas, [0.025, 0.5, 0.975])
    family_tail = 0.05 / max(int(family_size), 1) / 2.0
    family_lower, family_upper = np.quantile(deltas, [family_tail, 1.0 - family_tail])
    return {
        "bootstrap_resamples": resamples,
        "ci_2_5": float(lower),
        "median_delta": float(median),
        "ci_97_5": float(upper),
        "comparison_family_size": int(family_size),
        "bonferroni_ci_lower": float(family_lower),
        "bonferroni_ci_upper": float(family_upper),
        "probability_delta_gt_zero": float(np.mean(deltas > 0)),
    }


def bootstrap_robustness_advantage(
    y_true: np.ndarray,
    baseline_original: np.ndarray,
    baseline_stressed: np.ndarray,
    candidate_original: np.ndarray,
    candidate_stressed: np.ndarray,
    *,
    threshold: float,
    resamples: int,
    seed: int,
    family_size: int = 1,
) -> dict:
    rng = np.random.default_rng(seed)
    size = len(y_true)
    values = np.empty(resamples, dtype=float)
    baseline_original_prediction = np.asarray(baseline_original) >= threshold
    baseline_stressed_prediction = np.asarray(baseline_stressed) >= threshold
    candidate_original_prediction = np.asarray(candidate_original) >= threshold
    candidate_stressed_prediction = np.asarray(candidate_stressed) >= threshold
    for index in range(resamples):
        sample = rng.integers(0, size, size=size)
        sampled_y = y_true[sample]
        base_loss = binary_f1_from_predictions(
            sampled_y, baseline_original_prediction[sample]
        ) - binary_f1_from_predictions(
            sampled_y, baseline_stressed_prediction[sample]
        )
        candidate_loss = binary_f1_from_predictions(
            sampled_y, candidate_original_prediction[sample]
        ) - binary_f1_from_predictions(
            sampled_y, candidate_stressed_prediction[sample]
        )
        values[index] = base_loss - candidate_loss
    lower, median, upper = np.quantile(values, [0.025, 0.5, 0.975])
    family_tail = 0.05 / max(int(family_size), 1) / 2.0
    family_lower, family_upper = np.quantile(values, [family_tail, 1.0 - family_tail])
    return {
        "bootstrap_resamples": resamples,
        "ci_2_5": float(lower),
        "median_delta": float(median),
        "ci_97_5": float(upper),
        "comparison_family_size": int(family_size),
        "bonferroni_ci_lower": float(family_lower),
        "bonferroni_ci_upper": float(family_upper),
        "probability_delta_gt_zero": float(np.mean(values > 0)),
    }


def exact_correctness_test(
    y_true: np.ndarray,
    old_score: np.ndarray,
    new_score: np.ndarray,
    threshold: float,
) -> dict:
    old_correct = (old_score >= threshold) == y_true
    new_correct = (new_score >= threshold) == y_true
    old_only = int(np.sum(old_correct & ~new_correct))
    new_only = int(np.sum(~old_correct & new_correct))
    discordant = old_only + new_only
    p_value = 1.0 if discordant == 0 else float(
        binomtest(new_only, discordant, p=0.5, alternative="two-sided").pvalue
    )
    return {
        "baseline_correct_candidate_wrong": old_only,
        "baseline_wrong_candidate_correct": new_only,
        "discordant_correctness_pairs": discordant,
        "exact_mcnemar_p_value": p_value,
    }


def text_factor_masks(text: pd.Series) -> pd.DataFrame:
    clean = text.fillna("").astype(str)
    decomposable = clean.map(
        lambda item: any(
            len(hashtag_components(match.group(1))) >= 2 for match in HASHTAG_RE.finditer(item)
        )
    )
    return pd.DataFrame(
        {
            "has_url": clean.str.contains(URL_RE),
            "has_mention": clean.str.contains(MENTION_RE),
            "has_hashtag": clean.str.contains(HASHTAG_PRESENCE_RE),
            "has_decomposable_hashtag": decomposable,
            "has_uppercase": clean.map(lambda item: any(character.isupper() for character in item)),
            "has_emoji": clean.str.contains(EMOJI_RE),
        },
        index=text.index,
    )


def prediction_changes(
    frame: pd.DataFrame,
    baseline_score: np.ndarray,
    candidate_score: np.ndarray,
    threshold: float,
) -> pd.DataFrame:
    y_true = frame["target"].to_numpy(dtype=int)
    old_prediction = (baseline_score >= threshold).astype(int)
    new_prediction = (candidate_score >= threshold).astype(int)
    changed = old_prediction != new_prediction
    change_type = np.select(
        [
            changed & (y_true == 0) & (old_prediction == 1),
            changed & (y_true == 1) & (old_prediction == 0),
            changed & (y_true == 0) & (new_prediction == 1),
            changed & (y_true == 1) & (new_prediction == 0),
        ],
        ["fixed_fp", "fixed_fn", "new_fp", "new_fn"],
        default="unchanged",
    )
    text = frame["text"].fillna("").astype(str)
    masks = text_factor_masks(text)
    output = pd.DataFrame(
        {
            "id": frame["id"].astype(int),
            "y_true": y_true,
            "baseline_pred": old_prediction,
            "candidate_pred": new_prediction,
            "baseline_score": baseline_score,
            "candidate_score": candidate_score,
            "change_type": change_type,
            "score_delta": candidate_score - baseline_score,
            "has_url": masks["has_url"].to_numpy(),
            "has_mention": masks["has_mention"].to_numpy(),
            "has_hashtag": masks["has_hashtag"].to_numpy(),
            "has_decomposable_hashtag": masks["has_decomposable_hashtag"].to_numpy(),
            "text": text,
        }
    )
    return output.loc[changed].sort_values(["change_type", "id"]).reset_index(drop=True)


def clean_markdown(value: object, limit: int = 116) -> str:
    text = re.sub(r"\s+", " ", str(value)).strip().replace("|", "\\|")
    return text if len(text) <= limit else text[: limit - 1] + "…"


def markdown_table(frame: pd.DataFrame, columns: list[str]) -> str:
    lines = [
        "| " + " | ".join(columns) + " |",
        "| " + " | ".join(["---"] * len(columns)) + " |",
    ]
    for row in frame.loc[:, columns].itertuples(index=False, name=None):
        lines.append("| " + " | ".join(clean_markdown(value) for value in row) + " |")
    return "\n".join(lines)


def balanced_examples(changes: pd.DataFrame, per_type: int = 2) -> pd.DataFrame:
    parts = []
    for category in ("fixed_fp", "fixed_fn", "new_fp", "new_fn"):
        group = changes.loc[changes["change_type"] == category].copy()
        if group.empty:
            continue
        group["boundary_distance"] = np.minimum(
            np.abs(group["baseline_score"] - 0.5),
            np.abs(group["candidate_score"] - 0.5),
        )
        parts.append(group.sort_values(["has_url", "boundary_distance"], ascending=[False, True]).head(per_type))
    return pd.concat(parts, ignore_index=True) if parts else changes.head(0)


def balanced_examples_by_treatment(
    changes: pd.DataFrame,
    treatment_column: str,
    per_type: int = 1,
) -> pd.DataFrame:
    parts: list[pd.DataFrame] = []
    for category in ("fixed_fp", "fixed_fn", "new_fp", "new_fn"):
        group = changes.loc[changes["change_type"] == category].copy()
        if group.empty:
            continue
        group["boundary_distance"] = np.minimum(
            np.abs(group["baseline_score"] - 0.5),
            np.abs(group["candidate_score"] - 0.5),
        )
        parts.append(
            group.sort_values(
                [treatment_column, "boundary_distance"],
                ascending=[False, True],
            ).head(per_type)
        )
    return pd.concat(parts, ignore_index=True) if parts else changes.head(0)


def build_factor_coverage(data: object) -> pd.DataFrame:
    rows: list[dict] = []
    factor_columns = (
        ("url", "has_url"),
        ("mention", "has_mention"),
        ("hashtag_any", "has_hashtag"),
        ("hashtag_decomposable", "has_decomposable_hashtag"),
        ("uppercase", "has_uppercase"),
        ("emoji", "has_emoji"),
    )
    for split_name in ("train", "dev", "heldout"):
        frame = getattr(data, split_name)
        masks = text_factor_masks(frame["text"])
        for factor, column in factor_columns:
            affected = int(masks[column].sum())
            rows.append(
                {
                    "split": split_name,
                    "factor": factor,
                    "rows": len(frame),
                    "affected_rows": affected,
                    "prevalence": affected / len(frame),
                }
            )
    return pd.DataFrame(rows)


def build_mention_identity_audit(data: object) -> pd.DataFrame:
    train_handles = [
        match.group(0)[1:].lower()
        for text in data.train["text"].fillna("").astype(str)
        for match in MENTION_RE.finditer(text)
    ]
    train_vocabulary = set(train_handles)
    rows: list[dict] = []
    for split_name in ("train", "dev", "heldout"):
        frame = getattr(data, split_name)
        per_row = [
            [match.group(0)[1:].lower() for match in MENTION_RE.finditer(str(text))]
            for text in frame["text"].fillna("")
        ]
        handles = [handle for row_handles in per_row for handle in row_handles]
        counts = Counter(handles)
        unseen = [handle for handle in handles if handle not in train_vocabulary]
        rows.append(
            {
                "split": split_name,
                "rows": len(frame),
                "mention_rows": int(sum(bool(row_handles) for row_handles in per_row)),
                "mention_occurrences": len(handles),
                "unique_handles": len(counts),
                "singleton_handles": int(sum(count == 1 for count in counts.values())),
                "singleton_share_of_unique": float(
                    np.mean([count == 1 for count in counts.values()])
                )
                if counts
                else np.nan,
                "unseen_occurrences_vs_train": 0 if split_name == "train" else len(unseen),
                "unseen_occurrence_rate_vs_train": 0.0
                if split_name == "train" or not handles
                else len(unseen) / len(handles),
                "unseen_unique_handles_vs_train": 0
                if split_name == "train"
                else len(set(handles) - train_vocabulary),
            }
        )
    return pd.DataFrame(rows)


def build_factor_prediction_changes(
    protocol: dict,
    frame: pd.DataFrame,
    dev_scores: dict[str, np.ndarray],
    threshold: float,
) -> pd.DataFrame:
    baseline_score = dev_scores[protocol["baseline_model"]]
    parts: list[pd.DataFrame] = []
    for entry in protocol["factor_registry"]:
        changed = prediction_changes(
            frame,
            baseline_score,
            dev_scores[entry["model_name"]],
            threshold,
        )
        changed.insert(0, "split", "dev")
        changed.insert(1, "factor", entry["factor"])
        changed.insert(2, "model_name", entry["model_name"])
        parts.append(changed)
    if not parts:
        return pd.DataFrame()
    return pd.concat(parts, ignore_index=True)


def build_factor_change_summary(
    protocol: dict,
    frame: pd.DataFrame,
    factor_changes: pd.DataFrame,
) -> pd.DataFrame:
    masks = text_factor_masks(frame["text"])
    rows: list[dict] = []
    for entry in protocol["factor_registry"]:
        factor = entry["factor"]
        treatment_column = entry["treatment_mask"]
        treated = masks[treatment_column].to_numpy(dtype=bool)
        factor_part = factor_changes.loc[factor_changes["factor"] == factor]
        changed_ids = set(factor_part["id"].astype(int))
        changed = frame["id"].astype(int).isin(changed_ids).to_numpy()
        counts = factor_part["change_type"].value_counts().to_dict()
        treated_rate = float(np.mean(changed[treated])) if treated.any() else np.nan
        untreated_rate = float(np.mean(changed[~treated])) if (~treated).any() else np.nan
        rows.append(
            {
                "factor": factor,
                "model_name": entry["model_name"],
                "treatment_mask": treatment_column,
                "rows": len(frame),
                "treated_rows": int(treated.sum()),
                "treatment_prevalence": float(treated.mean()),
                "changed_predictions": int(changed.sum()),
                "changed_rows_treated": int(np.sum(changed & treated)),
                "changed_share_treated": float(np.mean(treated[changed]))
                if changed.any()
                else np.nan,
                "treated_change_rate": treated_rate,
                "untreated_change_rate": untreated_rate,
                "change_rate_ratio": treated_rate / untreated_rate
                if np.isfinite(untreated_rate) and untreated_rate > 0
                else np.inf if np.isfinite(treated_rate) and treated_rate > 0 else np.nan,
                "fixed_fp": int(counts.get("fixed_fp", 0)),
                "fixed_fn": int(counts.get("fixed_fn", 0)),
                "new_fp": int(counts.get("new_fp", 0)),
                "new_fn": int(counts.get("new_fn", 0)),
            }
        )
    return pd.DataFrame(rows)


def build_hashtag_component_audit(
    train_text: pd.Series,
    baseline_model: object,
    hashtag_model: object,
    limit: int = 20,
) -> pd.DataFrame:
    counts: Counter[str] = Counter()
    for text in train_text.fillna("").astype(str):
        for match in HASHTAG_RE.finditer(text):
            components = hashtag_components(match.group(1))
            if len(components) >= 2:
                counts.update(component.lower() for component in components if len(component) >= 2)

    rows: list[dict] = []
    baseline_vectorizer = baseline_model.named_steps["tfidf"]
    baseline_classifier = baseline_model.named_steps["classifier"]
    hashtag_vectorizer = hashtag_model.named_steps["tfidf"]
    hashtag_classifier = hashtag_model.named_steps["classifier"]
    for token, occurrences in counts.most_common(limit):
        baseline_index = baseline_vectorizer.vocabulary_.get(token)
        hashtag_index = hashtag_vectorizer.vocabulary_.get(token)
        rows.append(
            {
                "component": token,
                "train_decomposed_occurrences": occurrences,
                "baseline_in_vocabulary": baseline_index is not None,
                "baseline_coefficient": np.nan
                if baseline_index is None
                else float(baseline_classifier.coef_[0, baseline_index]),
                "hashtag_model_in_vocabulary": hashtag_index is not None,
                "hashtag_model_coefficient": np.nan
                if hashtag_index is None
                else float(hashtag_classifier.coef_[0, hashtag_index]),
            }
        )
    return pd.DataFrame(rows)


def update_interfaces(
    protocol: dict,
    ablation: pd.DataFrame,
    changes: pd.DataFrame,
    decision: str,
    selected_name: str,
    mechanism_summary: dict,
) -> None:
    selected = ablation.loc[ablation["model_name"] == selected_name].iloc[0]
    counts = changes["change_type"].value_counts().to_dict()
    summary_path = RESULTS_DIR / "summary.csv"
    summary = pd.read_csv(summary_path) if summary_path.exists() else pd.DataFrame()
    row = {
        "ticket": "ticket_2",
        "model_name": selected_name,
        "dev_f1_target_1": selected["dev_f1_target_1"],
        "heldout_f1_target_1": selected["heldout_f1_target_1"],
        "heldout_accuracy": selected["heldout_accuracy"],
        **{
            column: int(counts.get(column, 0))
            for column in ("fixed_fp", "fixed_fn", "new_fp", "new_fn")
        },
        "decision": decision,
        "decision_reason": (
            "URL-only normalization satisfies its protocol-specified dev and exact URL-rewrite "
            "invariance rule. Mention canonicalization has a promising exploratory point "
            "estimate but an interval crossing zero and weak treatment localization; "
            "mention and hashtag therefore remain unchanged downstream."
            if decision == "adopt"
            else "protocol-specified dev and robustness rule not satisfied"
        ),
    }
    if not summary.empty and "ticket" in summary.columns:
        summary = summary.loc[summary["ticket"] != "ticket_2"]
    pd.concat([summary, pd.DataFrame([row])], ignore_index=True).sort_values(
        "ticket"
    ).to_csv(summary_path, index=False)

    manifest_path = RESULTS_DIR / "run_manifest.json"
    if manifest_path.exists():
        with manifest_path.open(encoding="utf-8") as handle:
            manifest = json.load(handle)
        manifest["ticket_2_protocol"] = {
            "protocol_version": protocol["protocol_version"],
            "intended_lever": protocol["intended_lever"],
            "baseline_model": protocol["baseline_model"],
            "candidate_model": protocol["candidate_model"],
            "selected_model": selected_name,
            "selected_operations": next(
                entry["operations"]
                for entry in protocol["dev_only_ablation_registry"]
                if entry["name"] == selected_name
            ),
            "decision": decision,
            "dev_f1": float(selected["dev_f1_target_1"]),
            "heldout_f1": float(selected["heldout_f1_target_1"]),
            **mechanism_summary,
        }
        manifest["dependency_status"] = {
            "ticket_1_complete": True,
            "ticket_2_complete": True,
            "ticket_3_complete": False,
            "ticket_4_complete": False,
            "ticket_5_complete": False,
        }
        manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True), encoding="utf-8")


def write_ticket_document(
    protocol: dict,
    ablation: pd.DataFrame,
    stress: pd.DataFrame,
    statistics: pd.DataFrame,
    changes: pd.DataFrame,
    change_summary: pd.DataFrame,
    vocabulary: pd.DataFrame,
    decision: str,
    selected_name: str,
) -> None:
    baseline = ablation.loc[ablation["model_name"] == protocol["baseline_model"]].iloc[0]
    selected = ablation.loc[ablation["model_name"] == selected_name].iloc[0]
    dev_stats = statistics.loc[statistics["analysis"] == "candidate_minus_baseline_dev"].iloc[0]
    held_stats = statistics.loc[statistics["analysis"] == "candidate_minus_baseline_heldout"].iloc[0]
    robustness = statistics.loc[statistics["analysis"] == "url_rewrite_robustness_advantage_dev"].iloc[0]
    counts = changes["change_type"].value_counts().to_dict()
    examples = balanced_examples(changes)

    ablation_display = ablation.loc[
        :,
        [
            "model_name",
            "operations",
            "dev_precision_target_1",
            "dev_recall_target_1",
            "dev_f1_target_1",
            "heldout_f1_target_1",
            "heldout_evaluated_after_freeze",
        ],
    ].copy()
    for column in ("dev_precision_target_1", "dev_recall_target_1", "dev_f1_target_1"):
        ablation_display[column] = ablation_display[column].map(lambda value: f"{value:.6f}")
    ablation_display["heldout_f1_target_1"] = ablation_display["heldout_f1_target_1"].map(
        lambda value: "" if pd.isna(value) else f"{value:.6f}"
    )

    stress_display = stress.loc[
        stress["stress_test"].isin(
            [
                "identity",
                "case_swapped",
                "url_rewritten",
                "url_removed",
                "mention_rewritten",
                "hashtag_marker_removed",
                "emoji_appended",
                "combined_surface",
            ]
        ),
        ["model_name", "stress_test", "dev_f1_target_1", "prediction_changes_vs_identity"],
    ].copy()
    stress_display["dev_f1_target_1"] = stress_display["dev_f1_target_1"].map(
        lambda value: f"{value:.6f}"
    )

    example_display = examples.loc[
        :,
        [
            "id",
            "y_true",
            "change_type",
            "has_url",
            "baseline_score",
            "candidate_score",
            "text",
        ],
    ].copy()
    for column in ("baseline_score", "candidate_score"):
        example_display[column] = example_display[column].map(lambda value: f"{value:.4f}")

    url_change_rate = float(
        change_summary.loc[change_summary["group"] == "has_url", "prediction_change_rate"].iloc[0]
    )
    no_url_change_rate = float(
        change_summary.loc[change_summary["group"] == "no_url", "prediction_change_rate"].iloc[0]
    )
    url_changed_share = float(changes["has_url"].mean())
    heldout_url_share = float(
        change_summary.loc[change_summary["group"] == "all", "url_prevalence"].iloc[0]
    )
    url_row = stress.loc[
        (stress["model_name"] == protocol["baseline_model"])
        & (stress["stress_test"] == "url_rewritten")
    ].iloc[0]
    selected_url_row = stress.loc[
        (stress["model_name"] == protocol["candidate_model"])
        & (stress["stress_test"] == "url_rewritten")
    ].iloc[0]
    vocabulary_display = vocabulary.loc[
        vocabulary["token"].isin(["http", "https", "co", "url", "user"]),
        ["model_name", "token", "in_vocabulary", "coefficient_target_1"],
    ].copy()
    vocabulary_display["coefficient_target_1"] = vocabulary_display[
        "coefficient_target_1"
    ].map(lambda value: "" if pd.isna(value) else f"{value:+.6f}")

    content = f"""# Ticket 2 — URL normalization lever

## Answer in one sentence

The confirmatory **URL-only canonicalization** lever is adopted on dev: it raises dev F1 from {baseline.dev_f1_target_1:.6f} to {selected.dev_f1_target_1:.6f} and, more importantly, changes **zero** predictions when URL strings are rewritten, whereas the baseline changes {int(url_row.prediction_changes_vs_identity)}; frozen held-out F1 is {selected.heldout_f1_target_1:.6f}, but paired uncertainty prevents claiming a certain general score gain.

## Hypothesis and intended lever

**Hypothesis.** Arbitrary URL strings create brittle lexical features (`http`, `https`, `co`, path fragments). Replacing each complete URL with one `url` token should retain the information that a link exists while making predictions invariant to URL spelling.

**One intended lever.** URL canonicalization only. Lowercasing, tokenizer, TF-IDF settings, classifier, training IDs, threshold 0.5, and all non-URL tweet text remain fixed. Mention-only, hashtag-marker, and bundled multi-operation variants are dev-only falsification controls and are ineligible for selection.

## Frozen protocol and leakage control

`configs/ticket2_protocol.json` declares the model registry, stress variants, and decision rule. All models are fitted on train and evaluated on dev first. The candidate is frozen only if dev F1 improves **and** URL rewriting changes zero candidate decisions while changing baseline decisions. Held-out scores are then computed only for the baseline and frozen candidate; dev-only controls have blank held-out cells.

## Dev-only component ablation

{markdown_table(ablation_display, list(ablation_display.columns))}

URL-only improves dev F1 by {selected.dev_f1_target_1 - baseline.dev_f1_target_1:+.6f}. Mention-only changes F1 only marginally, hashtag-marker handling does not support adoption, and the three-operation bundle is excluded from attribution because it changes multiple factors at once.

## Independent surface-stress evidence

{markdown_table(stress_display, list(stress_display.columns))}

Under URL rewriting, baseline dev F1 moves from {baseline.dev_f1_target_1:.6f} to {url_row.dev_f1_target_1:.6f} and {int(url_row.prediction_changes_vs_identity)} decisions change. URL-only stays at {selected_url_row.dev_f1_target_1:.6f} with {int(selected_url_row.prediction_changes_vs_identity)} changes. The 5,000-resample robustness-advantage interval is [{robustness.ci_2_5:+.6f}, {robustness.ci_97_5:+.6f}] with P(advantage>0)={robustness.probability_delta_gt_zero:.3f}. Case, hashtag-marker, and appended-emoji controls show which transformations the word tokenizer already ignores; mention rewriting remains a deliberately unprotected falsification case.

## Frozen held-out evidence and precision–recall movement

After the dev decision was frozen, URL-only held-out precision/recall/F1 are {selected.heldout_precision_target_1:.6f}/{selected.heldout_recall_target_1:.6f}/{selected.heldout_f1_target_1:.6f}, versus baseline {baseline.heldout_precision_target_1:.6f}/{baseline.heldout_recall_target_1:.6f}/{baseline.heldout_f1_target_1:.6f}. It fixes {counts.get('fixed_fp', 0)} false positives and {counts.get('fixed_fn', 0)} false negatives while introducing {counts.get('new_fp', 0)} false positives and {counts.get('new_fn', 0)} false negatives.

The observed held-out F1 difference is {held_stats.observed_delta:+.6f}; paired bootstrap 95% CI [{held_stats.ci_2_5:+.6f}, {held_stats.ci_97_5:+.6f}], P(delta>0)={held_stats.probability_delta_gt_zero:.3f}. The exact paired correctness test has {int(held_stats.baseline_correct_candidate_wrong)} baseline-only correct versus {int(held_stats.baseline_wrong_candidate_correct)} candidate-only correct cases (p={held_stats.exact_mcnemar_p_value:.4f}). Thus robustness is strong evidence; the small benchmark gain remains uncertain.

## Does the movement match the mechanism?

URLs occur in {heldout_url_share:.1%} of held-out rows but in {url_changed_share:.1%} of changed predictions. The prediction-change rate is {url_change_rate:.1%} for URL rows versus {no_url_change_rate:.1%} for rows without URLs. This enrichment, together with exact URL-rewrite invariance and the vocabulary audit below, is consistent with the intended mechanism. Non-URL changes still occur because canonicalization changes global document frequencies and which terms enter the fixed 5,000-feature vocabulary.

{markdown_table(vocabulary_display, list(vocabulary_display.columns))}

## Balanced concrete examples

{markdown_table(example_display, list(example_display.columns))}

Examples cover every available fixed/new FP/FN category rather than selecting only improvements. They also expose label-policy ambiguity: a movement can be metric-correct without being semantically obvious, so examples support mechanism diagnosis rather than replacing aggregate evidence.

## Decision

**{decision.upper()} `{selected_name}`.** The candidate satisfies both protocol-specified dev conditions. Ticket 2 therefore selects URL-only canonicalization for subsequent tickets. Downstream artifacts are valid only after their exact upstream checks reproduce this frozen representation.

## Limitation

The point F1 gain is small and its paired confidence interval crosses zero. Replacing domains removes potentially meaningful source information, while keeping a generic `url` token still permits reliance on link presence as metadata. The case/hashtag/emoji invariance results are specific to the current word tokenizer and do not generalize to character or emoji-aware models.

## Artifacts

- `configs/ticket2_protocol.json`
- `results/ticket2_ablation.csv`
- `results/ticket2_stress_matrix.csv`
- `results/ticket2_statistics.csv`
- `results/ticket2_prediction_changes.csv`
- `results/ticket2_change_summary.csv`
- `results/ticket2_vocabulary_audit.csv`
- `predictions/ticket_2_selected_heldout.csv`
"""
    TICKET_PATH.write_text(content.strip() + "\n", encoding="utf-8")


def write_multifactor_ticket_document(
    protocol: dict,
    ablation: pd.DataFrame,
    stress: pd.DataFrame,
    statistics: pd.DataFrame,
    heldout_changes: pd.DataFrame,
    factor_changes: pd.DataFrame,
    factor_change_summary: pd.DataFrame,
    coverage: pd.DataFrame,
    mention_identity_audit: pd.DataFrame,
    hashtag_component_audit: pd.DataFrame,
    decision: str,
    selected_name: str,
) -> None:
    baseline = ablation.loc[ablation["model_name"] == protocol["baseline_model"]].iloc[0]
    selected = ablation.loc[ablation["model_name"] == selected_name].iloc[0]
    held_stats = statistics.loc[
        statistics["analysis"] == "candidate_minus_baseline_heldout"
    ].iloc[0]
    held_counts = heldout_changes["change_type"].value_counts().to_dict()

    coverage_display = coverage.loc[
        (coverage["split"] == "dev")
        & coverage["factor"].isin(
            ["url", "mention", "hashtag_any", "hashtag_decomposable", "emoji"]
        ),
        ["factor", "affected_rows", "rows", "prevalence"],
    ].copy()
    coverage_display["prevalence"] = coverage_display["prevalence"].map(
        lambda value: f"{value:.1%}"
    )

    ablation_display = ablation.loc[
        :,
        [
            "model_name",
            "role",
            "dev_precision_target_1",
            "dev_recall_target_1",
            "dev_f1_target_1",
            "heldout_f1_target_1",
        ],
    ].copy()
    for column in (
        "dev_precision_target_1",
        "dev_recall_target_1",
        "dev_f1_target_1",
    ):
        ablation_display[column] = ablation_display[column].map(lambda value: f"{value:.6f}")
    ablation_display["heldout_f1_target_1"] = ablation_display[
        "heldout_f1_target_1"
    ].map(lambda value: "" if pd.isna(value) else f"{value:.6f}")

    strategy_display = statistics.loc[
        statistics["analysis"].str.startswith("strategy_"),
        [
            "factor",
            "strategy",
            "model_name",
            "selected_within_factor",
            "observed_delta",
            "ci_2_5",
            "ci_97_5",
            "bonferroni_ci_lower",
            "bonferroni_ci_upper",
        ],
    ].copy()
    for column in (
        "observed_delta",
        "ci_2_5",
        "ci_97_5",
        "bonferroni_ci_lower",
        "bonferroni_ci_upper",
    ):
        strategy_display[column] = strategy_display[column].map(
            lambda value: f"{value:+.6f}"
        )

    mention_audit_display = mention_identity_audit.copy()
    for column in ("singleton_share_of_unique", "unseen_occurrence_rate_vs_train"):
        mention_audit_display[column] = mention_audit_display[column].map(
            lambda value: f"{value:.1%}"
        )

    paired_display = statistics.loc[
        statistics["analysis"].str.match(r"factor_(url|mention|hashtag)_minus_baseline_dev"),
        [
            "factor",
            "observed_delta",
            "ci_2_5",
            "ci_97_5",
            "bonferroni_ci_lower",
            "bonferroni_ci_upper",
            "probability_delta_gt_zero",
            "baseline_correct_candidate_wrong",
            "baseline_wrong_candidate_correct",
            "exact_mcnemar_p_value",
        ],
    ].copy()
    for column in (
        "observed_delta",
        "ci_2_5",
        "ci_97_5",
        "bonferroni_ci_lower",
        "bonferroni_ci_upper",
    ):
        paired_display[column] = paired_display[column].map(lambda value: f"{value:+.6f}")
    paired_display["probability_delta_gt_zero"] = paired_display[
        "probability_delta_gt_zero"
    ].map(lambda value: f"{value:.3f}")
    paired_display["exact_mcnemar_p_value"] = paired_display[
        "exact_mcnemar_p_value"
    ].map(lambda value: f"{value:.4f}")

    stress_rows: list[dict] = []
    for entry in protocol["factor_registry"]:
        factor = entry["factor"]
        stress_name = entry["matched_stress"]
        base_row = stress.loc[
            (stress["model_name"] == protocol["baseline_model"])
            & (stress["stress_test"] == stress_name)
        ].iloc[0]
        factor_row = stress.loc[
            (stress["model_name"] == entry["model_name"])
            & (stress["stress_test"] == stress_name)
        ].iloc[0]
        robust_row = statistics.loc[
            statistics["analysis"] == f"factor_{factor}_matched_stress_advantage_dev"
        ].iloc[0]
        stress_rows.append(
            {
                "factor": factor,
                "matched_stress": stress_name,
                "baseline_changes": int(base_row["prediction_changes_vs_identity"]),
                "factor_model_changes": int(factor_row["prediction_changes_vs_identity"]),
                "baseline_stressed_f1": f"{base_row['dev_f1_target_1']:.6f}",
                "factor_stressed_f1": f"{factor_row['dev_f1_target_1']:.6f}",
                "robustness_advantage": f"{robust_row['observed_delta']:+.6f}",
                "robustness_95_ci": (
                    f"[{robust_row['ci_2_5']:+.6f}, "
                    f"{robust_row['ci_97_5']:+.6f}]"
                ),
            }
        )
    stress_display = pd.DataFrame(stress_rows)

    movement_display = factor_change_summary.loc[
        :,
        [
            "factor",
            "changed_predictions",
            "fixed_fp",
            "fixed_fn",
            "new_fp",
            "new_fn",
            "treatment_prevalence",
            "changed_share_treated",
            "treated_change_rate",
            "untreated_change_rate",
            "change_rate_ratio",
        ],
    ].copy()
    for column in (
        "treatment_prevalence",
        "changed_share_treated",
        "treated_change_rate",
        "untreated_change_rate",
    ):
        movement_display[column] = movement_display[column].map(
            lambda value: "" if pd.isna(value) else f"{value:.1%}"
        )
    movement_display["change_rate_ratio"] = movement_display["change_rate_ratio"].map(
        lambda value: "" if pd.isna(value) else f"{value:.2f}x"
    )

    example_parts: list[pd.DataFrame] = []
    treatment_by_factor = {
        entry["factor"]: entry["treatment_mask"] for entry in protocol["factor_registry"]
    }
    for factor in ("url", "mention", "hashtag"):
        factor_part = factor_changes.loc[factor_changes["factor"] == factor]
        chosen = balanced_examples_by_treatment(
            factor_part,
            treatment_by_factor[factor],
            per_type=1,
        ).copy()
        if not chosen.empty:
            chosen.insert(0, "factor_name", factor)
            example_parts.append(chosen)
    examples = (
        pd.concat(example_parts, ignore_index=True)
        if example_parts
        else factor_changes.head(0)
    )
    example_columns = [
        "factor_name",
        "id",
        "y_true",
        "change_type",
        "baseline_score",
        "candidate_score",
        "text",
    ]
    example_display = examples.loc[:, example_columns].copy()
    for column in ("baseline_score", "candidate_score"):
        example_display[column] = example_display[column].map(lambda value: f"{value:.4f}")

    hashtag_display = hashtag_component_audit.head(10).copy()
    for column in ("baseline_coefficient", "hashtag_model_coefficient"):
        hashtag_display[column] = hashtag_display[column].map(
            lambda value: "" if pd.isna(value) else f"{value:+.4f}"
        )

    factor_rows = {
        entry["factor"]: ablation.loc[
            ablation["model_name"] == entry["model_name"]
        ].iloc[0]
        for entry in protocol["factor_registry"]
    }
    mention_row = factor_rows["mention"]
    hashtag_row = factor_rows["hashtag"]
    mention_canonical_row = ablation.loc[
        ablation["model_name"] == "mention_canonicalization"
    ].iloc[0]
    mention_removal_row = ablation.loc[
        ablation["model_name"] == "mention_removal"
    ].iloc[0]
    hashtag_generic_row = ablation.loc[
        ablation["model_name"] == "hashtag_generic_token"
    ].iloc[0]
    paired_by_factor = {
        row.factor: row
        for row in statistics.loc[
            statistics["analysis"].str.match(
                r"factor_(url|mention|hashtag)_minus_baseline_dev"
            )
        ].itertuples(index=False)
    }
    movement_by_factor = {
        row.factor: row
        for row in factor_change_summary.itertuples(index=False)
    }

    content = f"""# Ticket 2 — Multi-factor text normalization audit

## Answer in one sentence

On the explicit unweighted controlled baseline, URL canonicalization is adopted ({baseline.dev_f1_target_1:.6f} to {selected.dev_f1_target_1:.6f}) because it removes severe, treatment-localized URL-identity sensitivity; mention canonicalization has the largest exploratory point estimate ({mention_canonical_row.dev_f1_target_1:.6f}) but its interval crosses zero and most boundary changes occur outside mention rows, while hashtag decomposition is effectively neutral ({hashtag_row.dev_f1_target_1:.6f}).

## Scope chosen from data, not from a checklist

{markdown_table(coverage_display, list(coverage_display.columns))}

Mention and hashtag were selected for deeper study because they occur in 26.2% and 21.7% of development rows and have falsifiable mechanisms. Case is already folded by the baseline vectorizer, punctuation is largely discarded by its word tokenizer, and only {int(coverage_display.loc[coverage_display['factor'] == 'emoji', 'affected_rows'].iloc[0])} development rows meet the recorded emoji detector, so those factors are not promoted to fitted strategies.

## Hypotheses

- **H-URL:** {protocol['hypotheses']['url_only_normalization']}
- **H-mention:** {protocol['hypotheses']['mention_strategy']}
- **H-hashtag:** {protocol['hypotheses']['hashtag_strategy']}

## Provenance and leakage control

The frozen Ticket 2 normalization protocol anchors every comparison to Ticket 1's explicit unweighted controlled baseline. Its URL adoption rule is fixed before held-out scoring. Mention and hashtag strategies are fitted on train and evaluated on development only; their held-out cells are deliberately blank. All six representations share 5,000-feature English-stop-word sublinear TF--IDF, unweighted C=1 logistic regression, threshold 0.5, the fixed split, and 5,000 paired resamples. Each normalization arm independently refits its training vocabulary and IDF. Performance intervals use a Bonferroni family size of five, covering every fitted non-baseline strategy rather than only favorable results.

## Factor-specific development strategy ablation

{markdown_table(ablation_display, list(ablation_display.columns))}

{markdown_table(strategy_display, list(strategy_display.columns))}

Mention canonicalization moves dev F1 by {mention_canonical_row.dev_f1_target_1 - baseline.dev_f1_target_1:+.6f}; removal moves it by {mention_removal_row.dev_f1_target_1 - baseline.dev_f1_target_1:+.6f}. The canonicalization point estimate is promising, but its ordinary 95% interval [{paired_by_factor['mention'].ci_2_5:+.6f}, {paired_by_factor['mention'].ci_97_5:+.6f}] and Bonferroni interval [{paired_by_factor['mention'].bonferroni_ci_lower:+.6f}, {paired_by_factor['mention'].bonferroni_ci_upper:+.6f}] cross zero. It is protocol-designated as a development-only mechanism audit, so it cannot be promoted after inspection. Generic hashtag replacement moves F1 by {hashtag_generic_row.dev_f1_target_1 - baseline.dev_f1_target_1:+.6f}, whereas conservative decomposition moves it by {hashtag_row.dev_f1_target_1 - baseline.dev_f1_target_1:+.6f}. The latter preserves content and is the within-factor intervention winner, but its ordinary 95% interval [{paired_by_factor['hashtag'].ci_2_5:+.6f}, {paired_by_factor['hashtag'].ci_97_5:+.6f}] also crosses zero.

{markdown_table(paired_display, list(paired_display.columns))}

McNemar columns estimate paired correctness rather than F1; they are reported alongside, not substituted for, the paired F1 intervals.

## Mention-specific identity evidence

{markdown_table(mention_audit_display, list(mention_audit_display.columns))}

The audit extracts handles without labels from each split and compares them with the training handle vocabulary. High singleton and unseen-handle rates support the premise that exact account identity is weakly portable, but that mechanism does not guarantee a stable predictive gain from normalization. Canonicalization raises the development point estimate, whereas removal is nearly neutral. However, the controlled baseline changes only one decision when handles are synthetically rewritten, and only a minority of canonicalization-induced boundary movements occur on mention rows. The apparent gain is therefore weakly localized and can arise partly from global vocabulary/IDF refitting.

## Matched mechanism stress tests

{markdown_table(stress_display, list(stress_display.columns))}

Each stress matches one factor-specific intervention. URL strings are replaced by another syntactically valid URL, mention handles are rewritten under the canonicalization diagnostic, and decomposable CamelCase hashtag boundaries are rewritten with underscores. Every corresponding intervention model changes zero hard predictions and zero scores. Invariance is interpreted separately from predictive value: the baseline has severe URL sensitivity, but it is already almost invariant to mention rewriting. That asymmetry gives URL canonicalization a much clearer causal mechanism than mention canonicalization.

## FP/FN movements and treatment localization on development

{markdown_table(movement_display, list(movement_display.columns))}

The table includes improvements and regressions. `changed_share_treated` tests whether movements concentrate where the transformation can act, while treated and untreated change rates expose global vocabulary/IDF refitting effects. A factor is not credited merely because a few examples cross 0.5.

**Hypothesis-to-movement verdict.** URL supports H-URL as an invariance and localization mechanism: {int(movement_by_factor['url'].changed_rows_treated)}/{int(movement_by_factor['url'].changed_predictions)} boundary changes occur on URL rows, while improvements and regressions show no FP-only or FN-only direction. Mention does not strongly support H-mention as an identity-specific error mechanism because only {int(movement_by_factor['mention'].changed_rows_treated)}/{int(movement_by_factor['mention'].changed_predictions)} changes occur on mention rows and the controlled model is already nearly invariant to handle rewriting. Hashtag remains inconclusive: only {int(movement_by_factor['hashtag'].changed_rows_treated)}/{int(movement_by_factor['hashtag'].changed_predictions)} changes occur on decomposable-hashtag rows, and fixed FNs ({int(movement_by_factor['hashtag'].fixed_fn)}) do not exceed new FNs ({int(movement_by_factor['hashtag'].new_fn)}), so the expected semantic-recall mechanism is not demonstrated.

{markdown_table(example_display, list(example_display.columns))}

Examples are sampled symmetrically from every available fixed/new FP/FN direction for each factor. They diagnose how a lever moves the boundary; they do not replace aggregate or paired evidence.

## Independent hashtag vocabulary check

{markdown_table(hashtag_display, list(hashtag_display.columns))}

The audit derives component counts from training hashtags only and then checks whether those components enter each fitted vocabulary and how their coefficients differ. It verifies that the intended component words are actually exposed to the fitted model. Refitting changes global document frequencies and competition for the 5,000-feature cap, so the treatment-enrichment table, rather than this vocabulary check alone, supports localization.

## Frozen held-out URL result

Only the frozen unweighted baseline and URL candidate are scored on held-out. URL-only precision/recall/F1 are {selected.heldout_precision_target_1:.6f}/{selected.heldout_recall_target_1:.6f}/{selected.heldout_f1_target_1:.6f}, versus {baseline.heldout_precision_target_1:.6f}/{baseline.heldout_recall_target_1:.6f}/{baseline.heldout_f1_target_1:.6f}. It fixes {held_counts.get('fixed_fp', 0)} FP and {held_counts.get('fixed_fn', 0)} FN while creating {held_counts.get('new_fp', 0)} FP and {held_counts.get('new_fn', 0)} FN. The F1 difference is {held_stats.observed_delta:+.6f}, paired 95% CI [{held_stats.ci_2_5:+.6f}, {held_stats.ci_97_5:+.6f}].

## Decision

**{decision.upper()} `{selected_name}` as the unweighted downstream representation.** Retain mentions unchanged because canonicalization was exploratory, its interval crosses zero, and its changes are weakly localized despite a positive point estimate. Keep conservative hashtag decomposition as a development-only future candidate because its interval also crosses zero. This decision changes only URL normalization; class weighting remains untouched until Ticket 4.

## Limitations

The hashtag splitter handles only explicit orthographic boundaries and misses all-lowercase compounds. Mention normalization can discard meaningful source or conversational context; its positive point estimate is exploratory and not sufficiently localized to the treatment rows. Matched stresses test invariance to constructed equivalent spellings, not performance under platform drift. Development intervals quantify finite-sample uncertainty on this split.

## Artifacts

- `configs/ticket2_protocol.json`
- `results/ticket2_ablation.csv`
- `results/ticket2_factor_coverage.csv`
- `results/ticket2_mention_identity_audit.csv`
- `results/ticket2_factor_prediction_changes_dev.csv`
- `results/ticket2_factor_change_summary_dev.csv`
- `results/ticket2_stress_matrix.csv`
- `results/ticket2_hashtag_component_audit.csv`
- `results/ticket2_statistics.csv`
- `results/ticket2_prediction_changes.csv`
- `results/ticket2_change_summary.csv`
- `results/ticket2_vocabulary_audit.csv`
- `predictions/ticket_2_selected_heldout.csv`
"""
    TICKET_PATH.write_text(content.strip() + "\n", encoding="utf-8")


def main() -> None:
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    PREDICTIONS_DIR.mkdir(parents=True, exist_ok=True)
    protocol = load_protocol()
    data = load_project_data()
    threshold = float(protocol["threshold"])
    shared_params = dict(protocol["shared_pipeline_params"])

    models = {}
    dev_scores = {}
    ablation_rows = []
    # Phase 1: train and dev only. No held-out prediction exists yet.
    for specification in protocol["dev_only_ablation_registry"]:
        preprocessor = make_preprocessor(specification["operations"])
        parameters = dict(shared_params)
        if preprocessor is not None:
            parameters.update(preprocessor=preprocessor, lowercase=False)
        model = make_text_pipeline(
            **parameters,
            random_state=int(protocol["random_state"]),
        )
        model.fit(data.train["text"].fillna(""), data.train["target"])
        score = predict_scores(model, data.dev)
        metrics = binary_metrics(data.dev["target"], score, threshold)
        models[specification["name"]] = model
        dev_scores[specification["name"]] = score
        ablation_rows.append(
            {
                "model_name": specification["name"],
                "role": specification["role"],
                "operations": "+".join(specification["operations"]) or "none",
                **metric_columns("dev", metrics),
                "heldout_precision_target_1": np.nan,
                "heldout_recall_target_1": np.nan,
                "heldout_f1_target_1": np.nan,
                "heldout_accuracy": np.nan,
                "heldout_tn": np.nan,
                "heldout_fp": np.nan,
                "heldout_fn": np.nan,
                "heldout_tp": np.nan,
                "heldout_evaluated_after_freeze": False,
            }
        )

    baseline_name = protocol["baseline_model"]
    candidate_name = protocol["candidate_model"]
    baseline_identity = dev_scores[baseline_name]
    candidate_identity = dev_scores[candidate_name]
    stress_rows = []
    stressed_scores = {}
    audit_model_names = [
        specification["name"] for specification in protocol["dev_only_ablation_registry"]
    ]
    for model_name in audit_model_names:
        for stress_name in protocol["stress_registry"]:
            stressed = data.dev.copy()
            stressed["text"] = stress_text(data.dev["text"], stress_name)
            score = predict_scores(models[model_name], stressed)
            stressed_scores[(model_name, stress_name)] = score
            identity_score = dev_scores[model_name]
            metrics = binary_metrics(data.dev["target"], score, threshold)
            stress_rows.append(
                {
                    "model_name": model_name,
                    "stress_test": stress_name,
                    "dev_precision_target_1": metrics["precision_target_1"],
                    "dev_recall_target_1": metrics["recall_target_1"],
                    "dev_f1_target_1": metrics["f1_target_1"],
                    "dev_accuracy": metrics["accuracy"],
                    "prediction_changes_vs_identity": int(
                        np.sum((score >= threshold) != (identity_score >= threshold))
                    ),
                    "mean_absolute_score_delta": float(np.mean(np.abs(score - identity_score))),
                    "max_absolute_score_delta": float(np.max(np.abs(score - identity_score))),
                }
            )
    stress = pd.DataFrame(stress_rows)
    stress.to_csv(RESULTS_DIR / "ticket2_stress_matrix.csv", index=False)

    baseline_dev_f1 = f1_score(data.dev["target"], baseline_identity >= threshold)
    candidate_dev_f1 = f1_score(data.dev["target"], candidate_identity >= threshold)
    baseline_url_changes = int(
        stress.loc[
            (stress["model_name"] == baseline_name)
            & (stress["stress_test"] == "url_rewritten"),
            "prediction_changes_vs_identity",
        ].iloc[0]
    )
    candidate_url_changes = int(
        stress.loc[
            (stress["model_name"] == candidate_name)
            & (stress["stress_test"] == "url_rewritten"),
            "prediction_changes_vs_identity",
        ].iloc[0]
    )
    adopted = (
        candidate_dev_f1 > baseline_dev_f1
        and candidate_url_changes == 0
        and baseline_url_changes > 0
    )
    decision = "adopt" if adopted else "reject"
    selected_name = candidate_name if adopted else baseline_name

    # Phase 2: only after the decision is frozen, score baseline and selected on held-out.
    heldout_scores = {}
    for model_name in {baseline_name, selected_name}:
        score = predict_scores(models[model_name], data.heldout)
        heldout_scores[model_name] = score
        metrics = binary_metrics(data.heldout["target"], score, threshold)
        for row in ablation_rows:
            if row["model_name"] == model_name:
                row.update(metric_columns("heldout", metrics))
                row["heldout_evaluated_after_freeze"] = True
    ablation = pd.DataFrame(ablation_rows)
    ablation.to_csv(RESULTS_DIR / "ticket2_ablation.csv", index=False)
    upstream_audit = verify_ticket1_controlled_baseline(
        protocol,
        data,
        dev_scores[baseline_name],
        heldout_scores[baseline_name],
    )
    (RESULTS_DIR / "ticket2_upstream_audit.json").write_text(
        json.dumps(upstream_audit, indent=2, sort_keys=True), encoding="utf-8"
    )

    changes = prediction_changes(
        data.heldout,
        heldout_scores[baseline_name],
        heldout_scores[selected_name],
        threshold,
    )
    changes.to_csv(RESULTS_DIR / "ticket2_prediction_changes.csv", index=False)

    coverage = build_factor_coverage(data)
    coverage.to_csv(RESULTS_DIR / "ticket2_factor_coverage.csv", index=False)
    mention_identity_audit = build_mention_identity_audit(data)
    mention_identity_audit.to_csv(
        RESULTS_DIR / "ticket2_mention_identity_audit.csv",
        index=False,
    )
    factor_changes = build_factor_prediction_changes(
        protocol,
        data.dev,
        dev_scores,
        threshold,
    )
    factor_changes.to_csv(
        RESULTS_DIR / "ticket2_factor_prediction_changes_dev.csv",
        index=False,
    )
    factor_change_summary = build_factor_change_summary(
        protocol,
        data.dev,
        factor_changes,
    )
    factor_change_summary.to_csv(
        RESULTS_DIR / "ticket2_factor_change_summary_dev.csv",
        index=False,
    )

    heldout_text = data.heldout["text"].fillna("").astype(str)
    url_mask = heldout_text.str.contains(URL_RE).to_numpy()
    changed_ids = set(changes["id"].astype(int))
    changed_mask = data.heldout["id"].astype(int).isin(changed_ids).to_numpy()
    change_summary_rows = [
        {
            "group": "all",
            "rows": len(data.heldout),
            "changed_predictions": int(changed_mask.sum()),
            "prediction_change_rate": float(changed_mask.mean()),
            "url_prevalence": float(url_mask.mean()),
        },
        {
            "group": "has_url",
            "rows": int(url_mask.sum()),
            "changed_predictions": int(np.sum(changed_mask & url_mask)),
            "prediction_change_rate": float(np.mean(changed_mask[url_mask])),
            "url_prevalence": 1.0,
        },
        {
            "group": "no_url",
            "rows": int((~url_mask).sum()),
            "changed_predictions": int(np.sum(changed_mask & ~url_mask)),
            "prediction_change_rate": float(np.mean(changed_mask[~url_mask])),
            "url_prevalence": 0.0,
        },
    ]
    for change_type, group in changes.groupby("change_type"):
        change_summary_rows.append(
            {
                "group": change_type,
                "rows": len(group),
                "changed_predictions": len(group),
                "prediction_change_rate": 1.0,
                "url_prevalence": float(group["has_url"].mean()),
            }
        )
    change_summary = pd.DataFrame(change_summary_rows)
    change_summary.to_csv(RESULTS_DIR / "ticket2_change_summary.csv", index=False)

    statistics_rows: list[dict] = []
    y_dev = data.dev["target"].to_numpy(dtype=int)
    performance_family_size = len(protocol["strategy_registry"])
    strategy_statistics_rows: list[dict] = []
    for offset, strategy_entry in enumerate(protocol["strategy_registry"]):
        model_name = strategy_entry["model_name"]
        strategy_score = dev_scores[model_name]
        strategy_statistics_rows.append(
            {
                "analysis": f"strategy_{model_name}_minus_baseline_dev",
                "factor": strategy_entry["factor"],
                "strategy": strategy_entry["strategy"],
                "selected_within_factor": strategy_entry["selected_within_factor"],
                "model_name": model_name,
                "split": "dev",
                "estimand": "paired F1 difference",
                "observed_delta": f1_score(y_dev, strategy_score >= threshold)
                - f1_score(y_dev, baseline_identity >= threshold),
                **paired_bootstrap_delta(
                    y_dev,
                    baseline_identity,
                    strategy_score,
                    threshold=threshold,
                    resamples=int(protocol["bootstrap_resamples"]),
                    seed=int(protocol["random_state"]) + offset,
                    family_size=performance_family_size,
                ),
                **exact_correctness_test(
                    y_dev,
                    baseline_identity,
                    strategy_score,
                    threshold,
                ),
            }
        )
    statistics_rows.extend(strategy_statistics_rows)

    robustness_family_size = len(protocol["factor_registry"])
    for offset, entry in enumerate(protocol["factor_registry"]):
        factor = entry["factor"]
        model_name = entry["model_name"]
        factor_score = dev_scores[model_name]
        selected_strategy_row = next(
            row for row in strategy_statistics_rows if row["model_name"] == model_name
        )
        statistics_rows.append(
            {
                **selected_strategy_row,
                "analysis": f"factor_{factor}_minus_baseline_dev",
            }
        )

        stress_name = entry["matched_stress"]
        baseline_stressed = stressed_scores[(baseline_name, stress_name)]
        factor_stressed = stressed_scores[(model_name, stress_name)]
        robustness_observed = (
            f1_score(y_dev, baseline_identity >= threshold)
            - f1_score(y_dev, baseline_stressed >= threshold)
        ) - (
            f1_score(y_dev, factor_score >= threshold)
            - f1_score(y_dev, factor_stressed >= threshold)
        )
        statistics_rows.append(
            {
                "analysis": f"factor_{factor}_matched_stress_advantage_dev",
                "factor": factor,
                "model_name": model_name,
                "split": "dev",
                "estimand": f"F1 loss avoided under {stress_name}",
                "observed_delta": robustness_observed,
                **bootstrap_robustness_advantage(
                    y_dev,
                    baseline_identity,
                    baseline_stressed,
                    factor_score,
                    factor_stressed,
                    threshold=threshold,
                    resamples=int(protocol["bootstrap_resamples"]),
                    seed=int(protocol["random_state"]) + 10 + offset,
                    family_size=robustness_family_size,
                ),
                "baseline_correct_candidate_wrong": np.nan,
                "baseline_wrong_candidate_correct": np.nan,
                "discordant_correctness_pairs": np.nan,
                "exact_mcnemar_p_value": np.nan,
            }
        )

    # Compatibility rows preserve the machine-readable interface used by the
    # original URL-only protocol and downstream tests.
    url_dev = next(
        row for row in statistics_rows if row["analysis"] == "factor_url_minus_baseline_dev"
    )
    url_robustness = next(
        row
        for row in statistics_rows
        if row["analysis"] == "factor_url_matched_stress_advantage_dev"
    )
    statistics_rows.append({**url_dev, "analysis": "candidate_minus_baseline_dev"})
    statistics_rows.append(
        {**url_robustness, "analysis": "url_rewrite_robustness_advantage_dev"}
    )

    y_heldout = data.heldout["target"].to_numpy(dtype=int)
    heldout_baseline_score = heldout_scores[baseline_name]
    heldout_candidate_score = heldout_scores[selected_name]
    statistics_rows.append(
        {
            "analysis": "candidate_minus_baseline_heldout",
            "factor": "url",
            "model_name": selected_name,
            "split": "heldout",
            "estimand": "post-freeze held-out paired F1 difference for the URL policy",
            "observed_delta": f1_score(y_heldout, heldout_candidate_score >= threshold)
            - f1_score(y_heldout, heldout_baseline_score >= threshold),
            **paired_bootstrap_delta(
                y_heldout,
                heldout_baseline_score,
                heldout_candidate_score,
                threshold=threshold,
                resamples=int(protocol["bootstrap_resamples"]),
                seed=int(protocol["random_state"]) + 1,
            ),
            **exact_correctness_test(
                y_heldout,
                heldout_baseline_score,
                heldout_candidate_score,
                threshold,
            ),
        }
    )
    statistics = pd.DataFrame(statistics_rows)
    statistics.to_csv(RESULTS_DIR / "ticket2_statistics.csv", index=False)

    vocabulary_rows = []
    for model_name in audit_model_names:
        vectorizer = models[model_name].named_steps["tfidf"]
        classifier = models[model_name].named_steps["classifier"]
        for token in ("http", "https", "co", "url", "user", "www"):
            feature_index = vectorizer.vocabulary_.get(token)
            vocabulary_rows.append(
                {
                    "model_name": model_name,
                    "token": token,
                    "in_vocabulary": feature_index is not None,
                    "idf": np.nan if feature_index is None else float(vectorizer.idf_[feature_index]),
                    "coefficient_target_1": np.nan
                    if feature_index is None
                    else float(classifier.coef_[0, feature_index]),
                }
            )
    vocabulary = pd.DataFrame(vocabulary_rows)
    vocabulary.to_csv(RESULTS_DIR / "ticket2_vocabulary_audit.csv", index=False)
    hashtag_component_audit = build_hashtag_component_audit(
        data.train["text"],
        models[baseline_name],
        models["hashtag_decomposition"],
    )
    hashtag_component_audit.to_csv(
        RESULTS_DIR / "ticket2_hashtag_component_audit.csv",
        index=False,
    )

    selected_predictions = prediction_frame(
        data.heldout,
        heldout_scores[selected_name],
        model_name=selected_name,
        ticket="ticket_2",
        threshold=threshold,
    )
    selected_predictions.to_csv(PREDICTIONS_DIR / "ticket_2_selected_heldout.csv", index=False)
    pd.concat(
        [
            prediction_frame(
                data.dev,
                dev_scores[name],
                model_name=name,
                ticket="ticket_2_dev",
                threshold=threshold,
            )
            for name in audit_model_names
        ],
        ignore_index=True,
    ).to_csv(PREDICTIONS_DIR / "ticket_2_dev_predictions.csv", index=False)

    mechanism_summary = {
        "baseline_url_rewrite_changes": baseline_url_changes,
        "candidate_url_rewrite_changes": candidate_url_changes,
        "heldout_changed_predictions": len(changes),
        "changed_rows_url_share": float(changes["has_url"].mean()) if len(changes) else 0.0,
        "factor_dev_f1": {
            entry["factor"]: float(
                ablation.loc[
                    ablation["model_name"] == entry["model_name"],
                    "dev_f1_target_1",
                ].iloc[0]
            )
            for entry in protocol["factor_registry"]
        },
        "factor_decisions": {
            "url": "adopt_confirmatory_candidate" if adopted else "reject",
            "mention": "retain_unchanged_exploratory_interval_crosses_zero",
            "hashtag": "retain_unchanged_exploratory_interval_crosses_zero",
        },
    }
    for entry in protocol["factor_registry"]:
        stress_name = entry["matched_stress"]
        mechanism_summary[f"baseline_{entry['factor']}_stress_changes"] = int(
            stress.loc[
                (stress["model_name"] == baseline_name)
                & (stress["stress_test"] == stress_name),
                "prediction_changes_vs_identity",
            ].iloc[0]
        )
        mechanism_summary[f"factor_model_{entry['factor']}_stress_changes"] = int(
            stress.loc[
                (stress["model_name"] == entry["model_name"])
                & (stress["stress_test"] == stress_name),
                "prediction_changes_vs_identity",
            ].iloc[0]
        )
    update_interfaces(
        protocol,
        ablation,
        changes,
        decision,
        selected_name,
        mechanism_summary,
    )
    write_multifactor_ticket_document(
        protocol,
        ablation,
        stress,
        statistics,
        changes,
        factor_changes,
        factor_change_summary,
        coverage,
        mention_identity_audit,
        hashtag_component_audit,
        decision,
        selected_name,
    )

    selected = ablation.loc[ablation["model_name"] == selected_name].iloc[0]
    print(
        f"Ticket 2 decision={decision}; selected={selected_name}; "
        f"dev F1={selected.dev_f1_target_1:.6f}; held-out F1={selected.heldout_f1_target_1:.6f}"
    )
    print(
        f"URL rewrite prediction changes: baseline={baseline_url_changes}, "
        f"candidate={candidate_url_changes}; held-out model changes={len(changes)}"
    )
    for entry in protocol["factor_registry"]:
        model_row = ablation.loc[ablation["model_name"] == entry["model_name"]].iloc[0]
        stress_name = entry["matched_stress"]
        stress_row = stress.loc[
            (stress["model_name"] == entry["model_name"])
            & (stress["stress_test"] == stress_name)
        ].iloc[0]
        print(
            f"{entry['factor']}: dev F1={model_row.dev_f1_target_1:.6f}; "
            f"matched-stress prediction changes="
            f"{int(stress_row.prediction_changes_vs_identity)}"
        )


if __name__ == "__main__":
    main()
