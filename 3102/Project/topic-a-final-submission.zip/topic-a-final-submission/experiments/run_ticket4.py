"""Run Ticket 4 with a fair development model-by-threshold comparison."""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import binomtest


PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from pipeline.core import (  # noqa: E402
    binary_metrics,
    load_project_data,
    make_text_pipeline,
    predict_scores,
    prediction_frame,
    strict_content_key,
)


PROTOCOL_PATH = PROJECT_ROOT / "configs" / "ticket4_protocol.json"
RESULTS_DIR = PROJECT_ROOT / "results"
PREDICTIONS_DIR = PROJECT_ROOT / "predictions"
TICKET_PATH = PROJECT_ROOT / "tickets" / "ticket-4-decision-rule.md"

URL_RE = re.compile(r"(?:https?://|www\.)\S+", flags=re.IGNORECASE)
SPACE_RE = re.compile(r"\s+")

# Artifacts outside the declared Ticket 4 interface are removed before
# regeneration so that only one model-by-threshold protocol is represented.
STALE_ARTIFACTS = (
    RESULTS_DIR / "ticket4_cost_sensitivity.csv",
    RESULTS_DIR / "ticket4_grouped_oof_sensitivity.csv",
    RESULTS_DIR / "ticket4_invariance_audit.csv",
    RESULTS_DIR / "ticket4_model_audit.csv",
    RESULTS_DIR / "ticket4_oof_scores.csv",
    RESULTS_DIR / "ticket4_policy_metrics.csv",
    RESULTS_DIR / "ticket4_threshold_bootstrap.csv",
    PREDICTIONS_DIR / "ticket_4_decision_rule_heldout.csv",
)


def load_protocol() -> dict:
    with PROTOCOL_PATH.open(encoding="utf-8") as handle:
        protocol = json.load(handle)

    registry = protocol["model_registry"]
    names = [item["name"] for item in registry]
    if names != ["logreg_unweighted_c1", "logreg_balanced_c1"]:
        raise ValueError("Ticket 4 must compare exactly the two declared C=1 LR models.")
    if len({item["preference_rank"] for item in registry}) != len(registry):
        raise ValueError("Ticket 4 model preference ranks must be unique.")
    if any(item["family"] != "logistic_regression" for item in registry):
        raise ValueError("Ticket 4's fair comparison is restricted to logistic regression.")
    if any(float(item["c"]) != 1.0 for item in registry):
        raise ValueError("Regularization must stay fixed at C=1 in Ticket 4.")
    if registry[0]["class_weight"] is not None:
        raise ValueError("The Ticket 4 upstream model must be unweighted.")
    if registry[1]["class_weight"] != "balanced":
        raise ValueError("The only Ticket 4 challenger must use balanced class weights.")

    thresholds = threshold_grid(protocol)
    default = float(protocol["default_threshold"])
    if not np.any(np.isclose(thresholds, default)):
        raise ValueError("The default threshold must be present in the frozen grid.")
    if int(protocol["grouped_sensitivity_resamples"]) <= 0:
        raise ValueError("Ticket 4 grouped sensitivity requires positive resamples.")
    return protocol


def remove_stale_artifacts() -> None:
    for path in STALE_ARTIFACTS:
        path.unlink(missing_ok=True)


def url_only_preprocess(text: str) -> str:
    value = str(text).lower()
    value = URL_RE.sub(" url ", value)
    return SPACE_RE.sub(" ", value).strip()


def make_model(specification: dict, protocol: dict):
    params = protocol["shared_vectorizer_params"]
    return make_text_pipeline(
        preprocessor=url_only_preprocess,
        lowercase=False,
        max_features=params.get("max_features"),
        stop_words=params["stop_words"],
        sublinear_tf=bool(params["sublinear_tf"]),
        class_weight=specification["class_weight"],
        c=float(specification["c"]),
        random_state=int(protocol["random_state"]),
    )


def threshold_grid(protocol: dict) -> np.ndarray:
    start = float(protocol["threshold_grid_start"])
    stop = float(protocol["threshold_grid_stop"])
    step = float(protocol["threshold_grid_step"])
    thresholds = np.round(np.arange(start, stop + step / 2, step), 10)
    if not np.isclose(thresholds[0], start) or not np.isclose(thresholds[-1], stop):
        raise ValueError("Ticket 4 threshold grid does not match its declared bounds.")
    return thresholds


def build_threshold_sweep(
    y_true: np.ndarray,
    scores: dict[str, np.ndarray],
    protocol: dict,
) -> pd.DataFrame:
    rows: list[dict] = []
    thresholds = threshold_grid(protocol)
    roles = {item["name"]: item["role"] for item in protocol["model_registry"]}
    for model_name, score in scores.items():
        for threshold in thresholds:
            metrics = binary_metrics(y_true, score, float(threshold))
            rows.append(
                {
                    "model_name": model_name,
                    "model_role": roles[model_name],
                    "threshold": float(threshold),
                    "precision_target_1": metrics["precision_target_1"],
                    "recall_target_1": metrics["recall_target_1"],
                    "f1_target_1": metrics["f1_target_1"],
                    "accuracy": metrics["accuracy"],
                    "tn": metrics["tn"],
                    "fp": metrics["fp"],
                    "fn": metrics["fn"],
                    "tp": metrics["tp"],
                    "predicted_positive_count": metrics["fp"] + metrics["tp"],
                }
            )
    return pd.DataFrame(rows)


def select_best_row(frame: pd.DataFrame, protocol: dict) -> pd.Series:
    preference = {
        item["name"]: int(item["preference_rank"])
        for item in protocol["model_registry"]
    }
    ranked = frame.copy()
    ranked["distance_to_default"] = np.abs(
        ranked["threshold"] - float(protocol["default_threshold"])
    )
    ranked["model_preference"] = ranked["model_name"].map(preference)
    return ranked.sort_values(
        [
            "f1_target_1",
            "distance_to_default",
            "model_preference",
            "threshold",
        ],
        ascending=[False, True, True, True],
    ).iloc[0]


def model_best_rows(sweep: pd.DataFrame, protocol: dict) -> pd.DataFrame:
    rows = [
        select_best_row(group, protocol).to_dict()
        for _, group in sweep.groupby("model_name", sort=False)
    ]
    return pd.DataFrame(rows).drop(
        columns=["distance_to_default", "model_preference"], errors="ignore"
    )


def f1_grid_for_indices(
    y_true: np.ndarray,
    prediction_grid: np.ndarray,
    indices: np.ndarray,
) -> np.ndarray:
    """Return model-by-threshold F1 for one bootstrap sample."""
    labels = y_true[indices]
    prediction = prediction_grid[:, indices, :]
    positive = labels[None, :, None] == 1
    tp = np.sum(prediction & positive, axis=1)
    fp = np.sum(prediction & ~positive, axis=1)
    fn = np.sum(~prediction & positive, axis=1)
    denominator = 2 * tp + fp + fn
    return np.divide(
        2 * tp,
        denominator,
        out=np.zeros_like(tp, dtype=float),
        where=denominator > 0,
    )


def select_from_f1_grid(
    f1_values: np.ndarray,
    thresholds: np.ndarray,
    protocol: dict,
) -> tuple[int, int, float]:
    maximum = float(np.max(f1_values))
    candidates = np.argwhere(np.isclose(f1_values, maximum, rtol=0, atol=1e-15))
    distances = np.abs(
        thresholds[candidates[:, 1]] - float(protocol["default_threshold"])
    )
    candidates = candidates[np.isclose(distances, np.min(distances))]

    preference = np.asarray(
        [int(item["preference_rank"]) for item in protocol["model_registry"]]
    )
    ranks = preference[candidates[:, 0]]
    candidates = candidates[ranks == np.min(ranks)]

    # A lower threshold has weakly higher recall, matching the final tie-break.
    chosen = candidates[np.argmin(thresholds[candidates[:, 1]])]
    return int(chosen[0]), int(chosen[1]), maximum


def select_threshold_from_f1_row(
    f1_values: np.ndarray,
    thresholds: np.ndarray,
    default_threshold: float,
) -> int:
    """Select one model's threshold with the protocol's threshold tie-break."""
    maximum = float(np.max(f1_values))
    candidates = np.flatnonzero(
        np.isclose(f1_values, maximum, rtol=0, atol=1e-15)
    )
    distances = np.abs(thresholds[candidates] - default_threshold)
    candidates = candidates[np.isclose(distances, np.min(distances))]
    return int(candidates[np.argmin(thresholds[candidates])])


def bootstrap_joint_selection(
    y_true: np.ndarray,
    scores: dict[str, np.ndarray],
    protocol: dict,
) -> pd.DataFrame:
    model_names = [item["name"] for item in protocol["model_registry"]]
    thresholds = threshold_grid(protocol)
    score_matrix = np.stack([np.asarray(scores[name]) for name in model_names])
    prediction_grid = score_matrix[:, :, None] >= thresholds[None, None, :]
    default_index = int(
        np.flatnonzero(np.isclose(thresholds, float(protocol["default_threshold"])))[0]
    )
    baseline_prediction = prediction_grid[0, :, default_index]
    labels = np.asarray(y_true, dtype=int)
    rng = np.random.default_rng(int(protocol["random_state"]) + 1000)
    rows: list[dict] = []

    for replicate in range(int(protocol["selection_bootstrap_resamples"])):
        sample = rng.integers(0, len(labels), size=len(labels))
        inbag_grid = f1_grid_for_indices(labels, prediction_grid, sample)
        model_index, threshold_index, inbag_f1 = select_from_f1_grid(
            inbag_grid,
            thresholds,
            protocol,
        )
        per_model_threshold_indices = [
            select_threshold_from_f1_row(
                inbag_grid[index],
                thresholds,
                float(protocol["default_threshold"]),
            )
            for index in range(len(model_names))
        ]
        observed = np.zeros(len(labels), dtype=bool)
        observed[sample] = True
        out_of_bag = np.flatnonzero(~observed)
        if not len(out_of_bag):
            continue

        candidate_prediction = prediction_grid[
            model_index, out_of_bag, threshold_index
        ]
        candidate_score = candidate_prediction.astype(float)
        baseline_score = baseline_prediction[out_of_bag].astype(float)
        candidate_metrics = binary_metrics(
            labels[out_of_bag], candidate_score, threshold=0.5
        )
        baseline_metrics = binary_metrics(
            labels[out_of_bag], baseline_score, threshold=0.5
        )
        per_model_oob_metrics = []
        for index, per_model_threshold_index in enumerate(
            per_model_threshold_indices
        ):
            prediction = prediction_grid[
                index, out_of_bag, per_model_threshold_index
            ]
            per_model_oob_metrics.append(
                binary_metrics(
                    labels[out_of_bag],
                    prediction.astype(float),
                    threshold=0.5,
                )
            )
        unweighted_oob = per_model_oob_metrics[0]["f1_target_1"]
        balanced_oob = per_model_oob_metrics[1]["f1_target_1"]
        rows.append(
            {
                "replicate": replicate,
                "selected_model": model_names[model_index],
                "selected_threshold": float(thresholds[threshold_index]),
                "inbag_selected_f1": inbag_f1,
                "oob_rows": len(out_of_bag),
                "oob_candidate_precision": candidate_metrics["precision_target_1"],
                "oob_candidate_recall": candidate_metrics["recall_target_1"],
                "oob_candidate_f1": candidate_metrics["f1_target_1"],
                "oob_upstream_precision": baseline_metrics["precision_target_1"],
                "oob_upstream_recall": baseline_metrics["recall_target_1"],
                "oob_upstream_f1": baseline_metrics["f1_target_1"],
                "oob_f1_delta_vs_upstream": (
                    candidate_metrics["f1_target_1"]
                    - baseline_metrics["f1_target_1"]
                ),
                "unweighted_inbag_selected_threshold": float(
                    thresholds[per_model_threshold_indices[0]]
                ),
                "balanced_inbag_selected_threshold": float(
                    thresholds[per_model_threshold_indices[1]]
                ),
                "oob_unweighted_tuned_f1": unweighted_oob,
                "oob_balanced_tuned_f1": balanced_oob,
                "oob_balanced_minus_unweighted_tuned_f1": (
                    balanced_oob - unweighted_oob
                ),
            }
        )
    return pd.DataFrame(rows)


def grouped_bootstrap_joint_selection(
    y_true: np.ndarray,
    scores: dict[str, np.ndarray],
    groups: np.ndarray,
    protocol: dict,
) -> pd.DataFrame:
    """Repeat the dev joint search with strict-content groups kept indivisible.

    This is a post-decision sensitivity analysis. Its output is deliberately
    separate from the row-bootstrap adoption gates.
    """
    model_names = [item["name"] for item in protocol["model_registry"]]
    thresholds = threshold_grid(protocol)
    score_matrix = np.stack([np.asarray(scores[name]) for name in model_names])
    prediction_grid = score_matrix[:, :, None] >= thresholds[None, None, :]
    default_index = int(
        np.flatnonzero(np.isclose(thresholds, float(protocol["default_threshold"])))[0]
    )
    baseline_prediction = prediction_grid[0, :, default_index]
    labels = np.asarray(y_true, dtype=int)
    group_values = np.asarray(groups, dtype=object)
    if len(group_values) != len(labels):
        raise ValueError("Ticket 4 group keys must align with development rows.")
    group_codes, unique_groups = pd.factorize(group_values, sort=True)
    if np.any(group_codes < 0):
        raise ValueError("Ticket 4 strict-content group keys cannot be missing.")
    group_rows = [
        np.flatnonzero(group_codes == group_index)
        for group_index in range(len(unique_groups))
    ]
    total_groups = len(group_rows)
    rng = np.random.default_rng(int(protocol["random_state"]) + 4000)
    rows: list[dict] = []

    for replicate in range(int(protocol["grouped_sensitivity_resamples"])):
        sampled_groups = rng.integers(0, total_groups, size=total_groups)
        sample = np.concatenate([group_rows[index] for index in sampled_groups])
        inbag_group_mask = np.zeros(total_groups, dtype=bool)
        inbag_group_mask[sampled_groups] = True
        oob_group_indices = np.flatnonzero(~inbag_group_mask)
        if not len(oob_group_indices):
            continue
        group_overlap_count = int(
            np.intersect1d(
                np.flatnonzero(inbag_group_mask), oob_group_indices
            ).size
        )
        if group_overlap_count:
            raise AssertionError(
                "Strict-content groups crossed the grouped bootstrap boundary."
            )
        out_of_bag = np.concatenate(
            [group_rows[index] for index in oob_group_indices]
        )

        inbag_grid = f1_grid_for_indices(labels, prediction_grid, sample)
        model_index, threshold_index, inbag_f1 = select_from_f1_grid(
            inbag_grid,
            thresholds,
            protocol,
        )
        candidate_prediction = prediction_grid[
            model_index, out_of_bag, threshold_index
        ]
        candidate_metrics = binary_metrics(
            labels[out_of_bag], candidate_prediction.astype(float), threshold=0.5
        )
        baseline_metrics = binary_metrics(
            labels[out_of_bag],
            baseline_prediction[out_of_bag].astype(float),
            threshold=0.5,
        )
        inbag_unique_rows = int(
            sum(len(group_rows[index]) for index in np.flatnonzero(inbag_group_mask))
        )
        rows.append(
            {
                "replicate": replicate,
                "analysis_role": "post_decision_non_selecting_dev_only",
                "sampling_unit": "url_canonical_strict_content_group",
                "total_groups": total_groups,
                "inbag_unique_groups": int(inbag_group_mask.sum()),
                "oob_groups": len(oob_group_indices),
                "inbag_rows_with_multiplicity": len(sample),
                "inbag_unique_rows": inbag_unique_rows,
                "oob_rows": len(out_of_bag),
                "group_overlap_count": group_overlap_count,
                "selected_model": model_names[model_index],
                "selected_threshold": float(thresholds[threshold_index]),
                "inbag_selected_f1": inbag_f1,
                "oob_candidate_precision": candidate_metrics[
                    "precision_target_1"
                ],
                "oob_candidate_recall": candidate_metrics["recall_target_1"],
                "oob_candidate_f1": candidate_metrics["f1_target_1"],
                "oob_upstream_precision": baseline_metrics[
                    "precision_target_1"
                ],
                "oob_upstream_recall": baseline_metrics["recall_target_1"],
                "oob_upstream_f1": baseline_metrics["f1_target_1"],
                "oob_f1_delta_vs_upstream": (
                    candidate_metrics["f1_target_1"]
                    - baseline_metrics["f1_target_1"]
                ),
            }
        )
    return pd.DataFrame(rows)


def build_pair_selection_frequency(
    row_bootstrap: pd.DataFrame,
    grouped_bootstrap: pd.DataFrame,
    protocol: dict,
    *,
    proposed_model: str,
    proposed_threshold: float,
    selected_model: str,
    selected_threshold: float,
) -> pd.DataFrame:
    """Tabulate exact model-threshold frequencies on the complete search grid."""
    rows: list[dict] = []
    thresholds = threshold_grid(protocol)
    for specification in protocol["model_registry"]:
        model_name = str(specification["name"])
        row_model_count = int(row_bootstrap["selected_model"].eq(model_name).sum())
        grouped_model_count = int(
            grouped_bootstrap["selected_model"].eq(model_name).sum()
        )
        for threshold in thresholds:
            row_count = int(
                (
                    row_bootstrap["selected_model"].eq(model_name)
                    & np.isclose(row_bootstrap["selected_threshold"], threshold)
                ).sum()
            )
            grouped_count = int(
                (
                    grouped_bootstrap["selected_model"].eq(model_name)
                    & np.isclose(grouped_bootstrap["selected_threshold"], threshold)
                ).sum()
            )
            rows.append(
                {
                    "model_name": model_name,
                    "threshold": float(threshold),
                    "row_selected_replicates": row_count,
                    "row_pair_selection_frequency": row_count
                    / len(row_bootstrap),
                    "row_frequency_conditional_on_model": (
                        row_count / row_model_count if row_model_count else 0.0
                    ),
                    "grouped_selected_replicates": grouped_count,
                    "grouped_pair_selection_frequency": grouped_count
                    / len(grouped_bootstrap),
                    "grouped_frequency_conditional_on_model": (
                        grouped_count / grouped_model_count
                        if grouped_model_count
                        else 0.0
                    ),
                    "full_dev_proposal": bool(
                        model_name == proposed_model
                        and np.isclose(threshold, proposed_threshold)
                    ),
                    "selected_policy": bool(
                        model_name == selected_model
                        and np.isclose(threshold, selected_threshold)
                    ),
                }
            )
    return pd.DataFrame(rows)


def paired_f1_statistics(
    y_true: np.ndarray,
    baseline_score: np.ndarray,
    baseline_threshold: float,
    candidate_score: np.ndarray,
    candidate_threshold: float,
    *,
    resamples: int,
    seed: int,
) -> dict:
    labels = np.asarray(y_true, dtype=int)
    baseline_prediction = np.asarray(baseline_score) >= baseline_threshold
    candidate_prediction = np.asarray(candidate_score) >= candidate_threshold
    observed = float(
        binary_metrics(labels, candidate_prediction.astype(float), 0.5)[
            "f1_target_1"
        ]
        - binary_metrics(labels, baseline_prediction.astype(float), 0.5)[
            "f1_target_1"
        ]
    )
    rng = np.random.default_rng(seed)
    deltas = np.empty(resamples, dtype=float)
    for replicate in range(resamples):
        sample = rng.integers(0, len(labels), size=len(labels))
        candidate = binary_metrics(
            labels[sample], candidate_prediction[sample].astype(float), 0.5
        )["f1_target_1"]
        baseline = binary_metrics(
            labels[sample], baseline_prediction[sample].astype(float), 0.5
        )["f1_target_1"]
        deltas[replicate] = candidate - baseline

    baseline_correct_candidate_wrong = int(
        np.sum((baseline_prediction == labels) & (candidate_prediction != labels))
    )
    baseline_wrong_candidate_correct = int(
        np.sum((baseline_prediction != labels) & (candidate_prediction == labels))
    )
    discordant = baseline_correct_candidate_wrong + baseline_wrong_candidate_correct
    exact_p = (
        float(
            binomtest(
                min(
                    baseline_correct_candidate_wrong,
                    baseline_wrong_candidate_correct,
                ),
                discordant,
                0.5,
            ).pvalue
        )
        if discordant
        else 1.0
    )
    return {
        "observed_f1_delta": observed,
        "bootstrap_resamples": int(resamples),
        "ci_2_5": float(np.quantile(deltas, 0.025)),
        "median_delta": float(np.median(deltas)),
        "ci_97_5": float(np.quantile(deltas, 0.975)),
        "bootstrap_fraction_delta_gt_zero": float(np.mean(deltas > 0)),
        "baseline_correct_candidate_wrong": baseline_correct_candidate_wrong,
        "baseline_wrong_candidate_correct": baseline_wrong_candidate_correct,
        "discordant_correctness_pairs": discordant,
        "exact_mcnemar_p_value": exact_p,
    }


def prediction_changes(
    frame: pd.DataFrame,
    baseline_score: np.ndarray,
    baseline_threshold: float,
    candidate_score: np.ndarray,
    candidate_threshold: float,
) -> pd.DataFrame:
    labels = frame["target"].to_numpy(dtype=int)
    old = np.asarray(baseline_score) >= baseline_threshold
    new = np.asarray(candidate_score) >= candidate_threshold
    changed = old != new
    change_type = np.select(
        [
            changed & (labels == 0) & old & ~new,
            changed & (labels == 1) & ~old & new,
            changed & (labels == 0) & ~old & new,
            changed & (labels == 1) & old & ~new,
        ],
        ["fixed_fp", "fixed_fn", "new_fp", "new_fn"],
        default="unchanged",
    )
    output = pd.DataFrame(
        {
            "ticket": "ticket_4",
            "id": frame["id"].astype(int),
            "y_true": labels,
            "old_pred": old.astype(int),
            "new_pred": new.astype(int),
            "baseline_model": "logreg_unweighted_c1",
            "baseline_threshold": baseline_threshold,
            "candidate_threshold": candidate_threshold,
            "baseline_score": np.asarray(baseline_score),
            "candidate_score": np.asarray(candidate_score),
            "change_type": change_type,
            "text": frame["text"].fillna("").astype(str),
        }
    )
    return output.loc[changed].sort_values(["change_type", "id"]).reset_index(
        drop=True
    )


def reference_scores(
    frame: pd.DataFrame,
    path: Path,
    *,
    model_name: str | None = None,
) -> np.ndarray:
    reference = pd.read_csv(path)
    if model_name is not None:
        reference = reference.loc[reference["model_name"] == model_name]
    mapped = frame["id"].map(reference.set_index("id")["score"]).to_numpy(float)
    if np.isnan(mapped).any():
        raise AssertionError(f"Missing upstream prediction IDs in {path.name}.")
    return mapped


def verify_upstream(
    dev: pd.DataFrame,
    heldout: pd.DataFrame,
    dev_score: np.ndarray,
    heldout_score: np.ndarray,
) -> dict:
    manifest_path = RESULTS_DIR / "run_manifest.json"
    with manifest_path.open(encoding="utf-8") as handle:
        manifest = json.load(handle)
    dev_expected = reference_scores(
        dev,
        PREDICTIONS_DIR / "ticket_2_dev_predictions.csv",
        model_name="url_only_normalization",
    )
    heldout_expected = reference_scores(
        heldout,
        PREDICTIONS_DIR / "ticket_2_selected_heldout.csv",
    )
    audit = {
        "ticket2_selected_normalization": manifest["ticket_2_protocol"][
            "selected_model"
        ],
        "ticket3_selected_features": manifest["ticket_3_protocol"][
            "selected_features"
        ],
        "dev_max_absolute_score_difference": float(
            np.max(np.abs(dev_score - dev_expected))
        ),
        "heldout_max_absolute_score_difference": float(
            np.max(np.abs(heldout_score - heldout_expected))
        ),
        "tolerance": 1e-12,
    }
    audit["within_tolerance"] = bool(
        audit["ticket2_selected_normalization"] == "url_only_normalization"
        and audit["ticket3_selected_features"] == []
        and audit["dev_max_absolute_score_difference"] <= audit["tolerance"]
        and audit["heldout_max_absolute_score_difference"] <= audit["tolerance"]
    )
    if not audit["within_tolerance"]:
        raise AssertionError("Ticket 4 does not reproduce its frozen upstream.")
    return audit


def clean_markdown(value: object, limit: int = 118) -> str:
    text = str(value).replace("|", "\\|").replace("\n", " ")
    return text if len(text) <= limit else text[: limit - 1] + "…"


def markdown_table(frame: pd.DataFrame, columns: list[str]) -> str:
    display = frame[columns].copy()
    for column in columns:
        display[column] = display[column].map(clean_markdown)
    header = "| " + " | ".join(columns) + " |"
    separator = "| " + " | ".join(["---"] * len(columns)) + " |"
    rows = [
        "| " + " | ".join(map(str, row)) + " |"
        for row in display.itertuples(index=False, name=None)
    ]
    return "\n".join([header, separator, *rows])


def write_ticket_document(
    protocol: dict,
    operating_points: pd.DataFrame,
    bootstrap_summary: pd.DataFrame,
    statistics: pd.DataFrame,
    changes: pd.DataFrame,
    mechanism: dict,
) -> None:
    point_display = operating_points[
        [
            "policy",
            "model_name",
            "threshold",
            "dev_precision_target_1",
            "dev_recall_target_1",
            "dev_f1_target_1",
            "heldout_precision_target_1",
            "heldout_recall_target_1",
            "heldout_f1_target_1",
            "selected_policy",
        ]
    ].copy()
    for column in (
        "threshold",
        "dev_precision_target_1",
        "dev_recall_target_1",
        "dev_f1_target_1",
        "heldout_precision_target_1",
        "heldout_recall_target_1",
        "heldout_f1_target_1",
    ):
        point_display[column] = point_display[column].map(
            lambda value: "" if pd.isna(value) else f"{float(value):.4f}"
        )

    bootstrap_display = bootstrap_summary.copy()
    for column in (
        "selection_frequency",
        "threshold_2_5",
        "threshold_median",
        "threshold_97_5",
    ):
        bootstrap_display[column] = bootstrap_display[column].map(
            lambda value: f"{float(value):.4f}"
        )

    dev_stat = statistics.loc[statistics["split"] == "dev"].iloc[0]
    heldout_stat = statistics.loc[statistics["split"] == "heldout"].iloc[0]
    examples = (
        changes.groupby("change_type", group_keys=False)
        .head(2)[
            [
                "id",
                "y_true",
                "change_type",
                "old_pred",
                "new_pred",
                "baseline_threshold",
                "candidate_threshold",
                "baseline_score",
                "candidate_score",
                "text",
            ]
        ]
        .copy()
    )
    for column in (
        "baseline_threshold",
        "candidate_threshold",
        "baseline_score",
        "candidate_score",
    ):
        examples[column] = examples[column].map(lambda value: f"{value:.4f}")

    change_counts = changes["change_type"].value_counts().to_dict()
    decision_word = "ADOPT" if mechanism["decision"] == "adopt" else "REJECT"
    selected_weight = (
        "unweighted"
        if mechanism["selected_model"] == "logreg_unweighted_c1"
        else "balanced"
    )
    content = f"""# Ticket 4 — Fair model and decision-rule selection

## Answer in one sentence

The fair dev model-by-threshold comparison **rejects balanced class weighting and adopts threshold tuning**: the joint proposal is `{mechanism['proposed_model']}` at {mechanism['proposed_threshold']:.2f}, selected on full dev with F1 {mechanism['proposed_dev_f1']:.6f}; its model wins {mechanism['proposed_model_selection_frequency']:.1%} of row bootstraps, while the exact pair wins {mechanism['proposed_pair_selection_frequency']:.1%}, and its OOB F1 delta versus the frozen upstream has median {mechanism['oob_delta_median']:+.6f} with {mechanism['oob_fraction_delta_gt_zero']:.1%} above zero.

## Frozen question and controlled design

The ticket hypothesis is that balanced class weighting may improve the precision-recall operating point, but it is supported only if it wins a fair development model-by-threshold comparison; otherwise the unweighted model is retained and threshold tuning is adopted only when the development OOB evidence meets the stated stability gates.

Ticket 4 inherits Ticket 2's URL canonicalization and Ticket 3's no-shallow-feature decision. The intended policy-level lever is joint model-by-threshold operating-point selection: `class_weight` is the sole model-side change, and threshold is the decision-rule coordinate. Both model variants use the same word TF-IDF representation, `C=1`, training rows, and 0.20–0.80 threshold grid. **Dev chooses the model variant and threshold jointly**, ensuring equal operating-point opportunity.

Every selection bootstrap repeats the complete model-by-threshold search on in-bag dev rows and evaluates the selected pair out of bag against the frozen unweighted model at threshold 0.50. Adoption requires a positive full-dev delta, positive OOB median delta, at least {protocol['minimum_oob_fraction_positive']:.0%} positive OOB deltas, and at least {protocol['minimum_proposed_model_selection_frequency']:.0%} selection frequency for the proposed model. After that decision is fixed, a separate strict-content grouped bootstrap checks duplicate sensitivity without entering any gate or changing the pair. Held-out is not scored until both dev analyses finish.

The upstream refit matches Ticket 2 probabilities within {mechanism['upstream_dev_max_abs_diff']:.3g} on dev and {mechanism['upstream_heldout_max_abs_diff']:.3g} on held-out.

## Equal threshold opportunity on development

{markdown_table(point_display, list(point_display.columns))}

The balanced model's own best dev threshold is {mechanism['balanced_best_threshold']:.2f} with F1 {mechanism['balanced_best_dev_f1']:.6f}; the unweighted model reaches {mechanism['unweighted_best_dev_f1']:.6f} at {mechanism['unweighted_best_threshold']:.2f}. A fixed-0.50 comparison alone is not treated as model improvement: after equal threshold opportunity, unweighted is better on the declared dev estimand. In the nested bootstrap, each model also tunes its own threshold on the same in-bag rows before both are compared on the same OOB rows. Balanced minus unweighted tuned OOB F1 has median {mechanism['balanced_minus_unweighted_oob_median']:+.6f}, interval [{mechanism['balanced_minus_unweighted_oob_ci_2_5']:+.6f}, {mechanism['balanced_minus_unweighted_oob_ci_97_5']:+.6f}], and is positive in only {mechanism['balanced_minus_unweighted_oob_fraction_gt_zero']:.1%} of replicates.

## Joint-selection stability

{markdown_table(bootstrap_display, list(bootstrap_display.columns))}

Across {mechanism['bootstrap_resamples']} row bootstraps, the OOB delta distribution has central interval [{mechanism['oob_delta_ci_2_5']:+.6f}, {mechanism['oob_delta_ci_97_5']:+.6f}]. The interval crosses zero, so the result is not presented as a certain improvement in every resample. The adoption gates use the positive median and positive-resample fraction, while model-selection frequency directly tests whether the class-weight choice is stable. These OOB deltas evaluate an adaptive retuning procedure, not a fixed @{mechanism['proposed_threshold']:.2f} policy. The exact `{mechanism['proposed_model']}@{mechanism['proposed_threshold']:.2f}` pair appears in {mechanism['proposed_pair_selection_frequency']:.1%} of all replicates and {mechanism['proposed_threshold_frequency_conditional_on_model']:.1%} of replicates selecting that model, while its conditional full-dev paired interval [{dev_stat['ci_2_5']:+.6f}, {dev_stat['ci_97_5']:+.6f}] crosses zero. Thus {mechanism['proposed_threshold']:.2f} is the frozen full-dev point choice and the selected model's median bootstrap threshold, not a uniquely stable cutoff.

### Non-selecting strict-content group sensitivity

The {mechanism['grouped_sensitivity_resamples']} grouped replicates treat each URL-canonical strict-content key as one indivisible sampling unit, so no group can cross their in-bag/OOB boundary. Dev contains {mechanism['grouped_total_dev_groups']} groups; {mechanism['grouped_multirow_dev_groups']} multirow groups cover {mechanism['grouped_rows_in_multirow_dev_groups']} rows. The proposed model is selected in {mechanism['grouped_proposed_model_selection_frequency']:.1%} of grouped replicates, the exact @{mechanism['proposed_threshold']:.2f} pair in {mechanism['grouped_proposed_pair_selection_frequency']:.1%}, and the unweighted @0.50 pair in only {mechanism['grouped_default_pair_selection_frequency']:.1%}. Grouped OOB delta has median {mechanism['grouped_oob_delta_median']:+.6f}, interval [{mechanism['grouped_oob_delta_ci_2_5']:+.6f}, {mechanism['grouped_oob_delta_ci_97_5']:+.6f}], and {mechanism['grouped_oob_fraction_delta_gt_zero']:.1%} positive replicates. This post-decision dev-only sensitivity did not influence selection. It also does not remove the {mechanism['dev_rows_with_strict_train_overlap']} dev rows whose strict key occurs in train; Ticket 5 audits that cross-split repetition separately.

## Precision-recall trade-off and final held-out evidence

At the frozen selected policy, dev precision/recall/F1 are {mechanism['selected_dev_precision']:.6f}/{mechanism['selected_dev_recall']:.6f}/{mechanism['selected_dev_f1']:.6f}. Relative to upstream at 0.50, the dev F1 delta is {dev_stat['observed_f1_delta']:+.6f} with conditional paired interval [{dev_stat['ci_2_5']:+.6f}, {dev_stat['ci_97_5']:+.6f}]. The selection-aware OOB evidence above, not this conditional interval, drives adoption.

After freeze, held-out precision/recall/F1 are {mechanism['selected_heldout_precision']:.6f}/{mechanism['selected_heldout_recall']:.6f}/{mechanism['selected_heldout_f1']:.6f}. The held-out F1 delta is {heldout_stat['observed_f1_delta']:+.6f}, interval [{heldout_stat['ci_2_5']:+.6f}, {heldout_stat['ci_97_5']:+.6f}]. It fixes {change_counts.get('fixed_fp', 0)} FP and {change_counts.get('fixed_fn', 0)} FN while creating {change_counts.get('new_fp', 0)} FP and {change_counts.get('new_fn', 0)} FN. Lowering the threshold raises recall and false positives; it is not a free accuracy gain.

{markdown_table(examples, list(examples.columns))}

## Decision

**{decision_word} the joint dev proposal; use the {selected_weight} C=1 logistic model at threshold {mechanism['selected_threshold']:.2f}.** Balanced class weighting is rejected because it loses the equal-opportunity dev comparison. Threshold tuning is adopted because the full-dev and adaptive OOB gates pass; {mechanism['selected_threshold']:.2f} is retained as the frozen full-dev operating point, not as a universal or uniquely stable cutoff. Ticket 5 must inherit this exact frozen pair.

## Limitations

The selected threshold is conditional on one development split and may drift with prevalence or calibration. Both row and grouped OOB bootstraps reuse the same finite dev set and do not simulate temporal or platform shift; the grouped sensitivity prevents within-dev duplicate splitting but does not remove train--dev content overlap. The paired dev interval is conditional on the chosen pair; the joint OOB procedures expose selection uncertainty without making 0.44 uniquely optimal. Final held-out evidence is reported only after the dev decision is frozen and cannot alter the selected model or threshold.

Artifacts: `configs/ticket4_protocol.json`, canonical `results/threshold_sweep.csv`, detailed `results/ticket4_threshold_sweep.csv`, `results/ticket4_operating_points.csv`, `results/ticket4_selection_bootstrap.csv`, `results/ticket4_grouped_selection_sensitivity.csv`, `results/ticket4_pair_selection_frequency.csv`, `results/ticket4_statistics.csv`, `results/ticket4_prediction_changes.csv`, `results/ticket4_upstream_audit.json`, `results/ticket4_mechanism_summary.json`, `predictions/ticket_4_selected_dev.csv`, and `predictions/ticket_4_selected_heldout.csv`.
"""
    TICKET_PATH.write_text(content, encoding="utf-8")


def upsert_summary(row: dict) -> None:
    path = RESULTS_DIR / "summary.csv"
    columns = [
        "ticket",
        "model_name",
        "dev_f1_target_1",
        "heldout_f1_target_1",
        "heldout_accuracy",
        "fixed_fp",
        "fixed_fn",
        "new_fp",
        "new_fn",
        "decision",
        "decision_reason",
    ]
    if path.exists():
        summary = pd.read_csv(path)
        summary = summary.loc[
            ~summary["ticket"].isin(["ticket_4", "ticket_5"])
        ].copy()
    else:
        summary = pd.DataFrame(columns=columns)
    summary = pd.concat([summary, pd.DataFrame([row])], ignore_index=True)
    summary = summary[columns].sort_values("ticket").reset_index(drop=True)
    summary.to_csv(path, index=False)


def update_interfaces(
    protocol: dict,
    mechanism: dict,
    selected_dev_score: np.ndarray,
    selected_heldout_score: np.ndarray,
    dev: pd.DataFrame,
    heldout: pd.DataFrame,
    selected_dev_metrics: dict,
    selected_heldout_metrics: dict,
    changes: pd.DataFrame,
) -> None:
    selected_label = (
        f"{mechanism['selected_model']}_threshold_"
        f"{mechanism['selected_threshold']:.2f}"
    )
    counts = changes["change_type"].value_counts().to_dict()
    upsert_summary(
        {
            "ticket": "ticket_4",
            "model_name": selected_label,
            "dev_f1_target_1": selected_dev_metrics["f1_target_1"],
            "heldout_f1_target_1": selected_heldout_metrics["f1_target_1"],
            "heldout_accuracy": selected_heldout_metrics["accuracy"],
            "fixed_fp": int(counts.get("fixed_fp", 0)),
            "fixed_fn": int(counts.get("fixed_fn", 0)),
            "new_fp": int(counts.get("new_fp", 0)),
            "new_fn": int(counts.get("new_fn", 0)),
            "decision": mechanism["decision"],
            "decision_reason": mechanism["decision_reason"],
        }
    )

    prediction_frame(
        dev,
        selected_dev_score,
        model_name=selected_label,
        ticket="ticket_4",
        threshold=float(mechanism["selected_threshold"]),
    ).to_csv(PREDICTIONS_DIR / "ticket_4_selected_dev.csv", index=False)
    selected_heldout = prediction_frame(
        heldout,
        selected_heldout_score,
        model_name=selected_label,
        ticket="ticket_4",
        threshold=float(mechanism["selected_threshold"]),
    )
    selected_heldout.to_csv(
        PREDICTIONS_DIR / "ticket_4_selected_heldout.csv", index=False
    )
    selected_heldout.to_csv(PREDICTIONS_DIR / "heldout_predictions.csv", index=False)

    manifest_path = RESULTS_DIR / "run_manifest.json"
    with manifest_path.open(encoding="utf-8") as handle:
        manifest = json.load(handle)
    for key in (
        "ticket_5_protocol",
        "ticket_5_rebased_on_ticket_4",
        "ticket_5_inherits_frozen_ticket_4",
        "training_label_fixes_proposed",
        "correction_selected_on_dev",
    ):
        manifest.pop(key, None)
    manifest["ticket_4_protocol"] = mechanism
    manifest["ticket_4_uses_frozen_ticket2_ticket3_pipeline"] = True
    manifest["ticket_4_fair_joint_dev_selection"] = True
    manifest["selected_threshold_on_dev"] = float(mechanism["selected_threshold"])
    selected_specification = next(
        item
        for item in protocol["model_registry"]
        if item["name"] == mechanism["selected_model"]
    )
    manifest["final_model_name"] = selected_label
    manifest["final_model_parameters"] = {
        "family": "logistic_regression",
        "c": float(selected_specification["c"]),
        "class_weight": selected_specification["class_weight"],
        **protocol["shared_vectorizer_params"],
        "threshold": float(mechanism["selected_threshold"]),
    }
    manifest["final_dev_metrics"] = selected_dev_metrics
    manifest["final_heldout_metrics"] = selected_heldout_metrics
    manifest["dependency_status"] = {
        "ticket_1_complete": True,
        "ticket_2_complete": True,
        "ticket_3_complete": True,
        "ticket_4_complete": True,
        "ticket_5_complete": False,
    }
    manifest_path.write_text(
        json.dumps(manifest, indent=2, sort_keys=True), encoding="utf-8"
    )


def main() -> None:
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    PREDICTIONS_DIR.mkdir(parents=True, exist_ok=True)
    remove_stale_artifacts()
    protocol = load_protocol()
    data = load_project_data()
    default_threshold = float(protocol["default_threshold"])
    y_dev = data.dev["target"].to_numpy(dtype=int)

    models = {}
    dev_scores: dict[str, np.ndarray] = {}
    for specification in protocol["model_registry"]:
        model = make_model(specification, protocol)
        model.fit(data.train["text"].fillna(""), data.train["target"])
        models[specification["name"]] = model
        dev_scores[specification["name"]] = predict_scores(model, data.dev)

    sweep = build_threshold_sweep(y_dev, dev_scores, protocol)
    per_model_best = model_best_rows(sweep, protocol)
    proposal = select_best_row(sweep, protocol)
    proposed_model = str(proposal["model_name"])
    proposed_threshold = float(proposal["threshold"])
    proposed_dev_score = dev_scores[proposed_model]
    baseline_name = str(protocol["baseline_model"])
    baseline_dev_score = dev_scores[baseline_name]

    bootstrap = bootstrap_joint_selection(y_dev, dev_scores, protocol)
    selection_frequency = (
        bootstrap["selected_model"].value_counts(normalize=True).to_dict()
    )
    proposed_model_frequency = float(selection_frequency.get(proposed_model, 0.0))
    oob_delta = bootstrap["oob_f1_delta_vs_upstream"]
    proposal_dev_metrics = binary_metrics(
        y_dev, proposed_dev_score, proposed_threshold
    )
    baseline_dev_metrics = binary_metrics(
        y_dev, baseline_dev_score, default_threshold
    )
    adoption_gates = {
        "positive_full_dev_f1_delta": bool(
            proposal_dev_metrics["f1_target_1"]
            > baseline_dev_metrics["f1_target_1"]
        ),
        "positive_oob_median_delta": bool(float(oob_delta.median()) > 0),
        "oob_fraction_positive_at_least_minimum": bool(
            float((oob_delta > 0).mean())
            >= float(protocol["minimum_oob_fraction_positive"])
        ),
        "proposed_model_selection_frequency_at_least_minimum": bool(
            proposed_model_frequency
            >= float(protocol["minimum_proposed_model_selection_frequency"])
        ),
    }
    failed_gates = [name for name, passed in adoption_gates.items() if not passed]
    adopted = all(adoption_gates.values())
    decision = "adopt" if adopted else "reject"
    selected_model = proposed_model if adopted else baseline_name
    selected_threshold = proposed_threshold if adopted else default_threshold
    selected_dev_score = dev_scores[selected_model]
    selected_dev_metrics = binary_metrics(
        y_dev, selected_dev_score, selected_threshold
    )

    # The row-bootstrap gates have fixed the decision above. This dev-only
    # grouped analysis is diagnostic and cannot alter the selected pair.
    dev_strict_groups = (
        data.dev["text"].fillna("").map(strict_content_key).to_numpy()
    )
    grouped_bootstrap = grouped_bootstrap_joint_selection(
        y_dev,
        dev_scores,
        dev_strict_groups,
        protocol,
    )
    pair_frequency = build_pair_selection_frequency(
        bootstrap,
        grouped_bootstrap,
        protocol,
        proposed_model=proposed_model,
        proposed_threshold=proposed_threshold,
        selected_model=selected_model,
        selected_threshold=selected_threshold,
    )
    proposed_pair_frequency = pair_frequency.loc[
        pair_frequency["full_dev_proposal"]
    ].iloc[0]
    default_pair_frequency = pair_frequency.loc[
        (pair_frequency["model_name"] == baseline_name)
        & np.isclose(pair_frequency["threshold"], default_threshold)
    ].iloc[0]
    grouped_selection_frequency = (
        grouped_bootstrap["selected_model"].value_counts(normalize=True).to_dict()
    )
    grouped_oob_delta = grouped_bootstrap["oob_f1_delta_vs_upstream"]
    dev_group_sizes = pd.Series(dev_strict_groups).value_counts()
    train_strict_groups = set(
        data.train["text"].fillna("").map(strict_content_key)
    )
    dev_rows_overlapping_train = int(
        pd.Series(dev_strict_groups).isin(train_strict_groups).sum()
    )

    # The model/threshold decision is frozen above. Held-out access starts here.
    required_heldout_models = {baseline_name, proposed_model}
    heldout_scores = {
        name: predict_scores(models[name], data.heldout)
        for name in required_heldout_models
    }
    baseline_heldout_score = heldout_scores[baseline_name]
    proposal_heldout_score = heldout_scores[proposed_model]
    selected_heldout_score = heldout_scores[selected_model]
    y_heldout = data.heldout["target"].to_numpy(dtype=int)
    selected_heldout_metrics = binary_metrics(
        y_heldout, selected_heldout_score, selected_threshold
    )
    upstream_audit = verify_upstream(
        data.dev,
        data.heldout,
        baseline_dev_score,
        baseline_heldout_score,
    )

    bootstrap_summary_rows = []
    for specification in protocol["model_registry"]:
        name = specification["name"]
        selected_rows = bootstrap.loc[bootstrap["selected_model"] == name]
        bootstrap_summary_rows.append(
            {
                "model_name": name,
                "selected_replicates": len(selected_rows),
                "selection_frequency": len(selected_rows) / len(bootstrap),
                "threshold_2_5": float(
                    selected_rows["selected_threshold"].quantile(0.025)
                ),
                "threshold_median": float(
                    selected_rows["selected_threshold"].median()
                ),
                "threshold_97_5": float(
                    selected_rows["selected_threshold"].quantile(0.975)
                ),
            }
        )
    bootstrap_summary = pd.DataFrame(bootstrap_summary_rows)

    sweep["per_model_dev_best"] = False
    for row in per_model_best.itertuples(index=False):
        sweep.loc[
            (sweep["model_name"] == row.model_name)
            & np.isclose(sweep["threshold"], row.threshold),
            "per_model_dev_best",
        ] = True
    sweep["joint_dev_proposal"] = (
        (sweep["model_name"] == proposed_model)
        & np.isclose(sweep["threshold"], proposed_threshold)
    )

    operating_rows: list[dict] = []
    baseline_row = sweep.loc[
        (sweep["model_name"] == baseline_name)
        & np.isclose(sweep["threshold"], default_threshold)
    ].iloc[0]
    candidates = [
        ("upstream_default", baseline_row),
        *[
            (f"{row.model_name}_dev_optimum", row)
            for row in per_model_best.itertuples(index=False)
        ],
    ]
    for policy, row in candidates:
        model_name = str(row.model_name)
        threshold = float(row.threshold)
        is_proposal = model_name == proposed_model and np.isclose(
            threshold, proposed_threshold
        )
        is_selected = model_name == selected_model and np.isclose(
            threshold, selected_threshold
        )
        heldout_evaluated = policy == "upstream_default" or is_proposal
        if heldout_evaluated:
            heldout_metrics = binary_metrics(
                y_heldout, heldout_scores[model_name], threshold
            )
        else:
            heldout_metrics = None
        operating_rows.append(
            {
                "policy": policy,
                "model_name": model_name,
                "threshold": threshold,
                "dev_precision_target_1": float(row.precision_target_1),
                "dev_recall_target_1": float(row.recall_target_1),
                "dev_f1_target_1": float(row.f1_target_1),
                "dev_accuracy": float(row.accuracy),
                "dev_fp": int(row.fp),
                "dev_fn": int(row.fn),
                "heldout_precision_target_1": (
                    heldout_metrics["precision_target_1"]
                    if heldout_metrics
                    else np.nan
                ),
                "heldout_recall_target_1": (
                    heldout_metrics["recall_target_1"]
                    if heldout_metrics
                    else np.nan
                ),
                "heldout_f1_target_1": (
                    heldout_metrics["f1_target_1"] if heldout_metrics else np.nan
                ),
                "heldout_accuracy": (
                    heldout_metrics["accuracy"] if heldout_metrics else np.nan
                ),
                "heldout_fp": heldout_metrics["fp"] if heldout_metrics else np.nan,
                "heldout_fn": heldout_metrics["fn"] if heldout_metrics else np.nan,
                "joint_dev_proposal": bool(is_proposal),
                "selected_policy": bool(is_selected),
                "heldout_evaluated_after_freeze": bool(heldout_evaluated),
            }
        )
    operating_points = pd.DataFrame(operating_rows)

    statistics = pd.DataFrame(
        [
            {
                "split": "dev",
                "analysis": "joint_proposal_minus_upstream",
                "baseline_model": baseline_name,
                "baseline_threshold": default_threshold,
                "candidate_model": proposed_model,
                "candidate_threshold": proposed_threshold,
                "interpretation": (
                    "conditional paired interval; joint selection uncertainty "
                    "is assessed by ticket4_selection_bootstrap.csv"
                ),
                **paired_f1_statistics(
                    y_dev,
                    baseline_dev_score,
                    default_threshold,
                    proposed_dev_score,
                    proposed_threshold,
                    resamples=int(protocol["metric_bootstrap_resamples"]),
                    seed=int(protocol["random_state"]) + 2000,
                ),
            },
            {
                "split": "heldout",
                "analysis": "frozen_joint_proposal_minus_upstream",
                "baseline_model": baseline_name,
                "baseline_threshold": default_threshold,
                "candidate_model": proposed_model,
                "candidate_threshold": proposed_threshold,
                "interpretation": "final held-out benchmark evidence after frozen dev selection",
                **paired_f1_statistics(
                    y_heldout,
                    baseline_heldout_score,
                    default_threshold,
                    proposal_heldout_score,
                    proposed_threshold,
                    resamples=int(protocol["metric_bootstrap_resamples"]),
                    seed=int(protocol["random_state"]) + 2001,
                ),
            },
        ]
    )

    changes = prediction_changes(
        data.heldout,
        baseline_heldout_score,
        default_threshold,
        selected_heldout_score,
        selected_threshold,
    )
    best_lookup = per_model_best.set_index("model_name")
    balanced_minus_unweighted_oob = bootstrap[
        "oob_balanced_minus_unweighted_tuned_f1"
    ]
    mechanism = {
        "protocol_version": int(protocol["protocol_version"]),
        "upstream_representation": protocol["upstream_representation"],
        "selection_uses_dev_for_model_variants": True,
        "equal_threshold_grid_for_all_models": True,
        "candidate_models": [
            item["name"] for item in protocol["model_registry"]
        ],
        "upstream_dev_max_abs_diff": upstream_audit[
            "dev_max_absolute_score_difference"
        ],
        "upstream_heldout_max_abs_diff": upstream_audit[
            "heldout_max_absolute_score_difference"
        ],
        "unweighted_best_threshold": float(
            best_lookup.loc["logreg_unweighted_c1", "threshold"]
        ),
        "unweighted_best_dev_f1": float(
            best_lookup.loc["logreg_unweighted_c1", "f1_target_1"]
        ),
        "balanced_best_threshold": float(
            best_lookup.loc["logreg_balanced_c1", "threshold"]
        ),
        "balanced_best_dev_f1": float(
            best_lookup.loc["logreg_balanced_c1", "f1_target_1"]
        ),
        "proposed_model": proposed_model,
        "proposed_threshold": proposed_threshold,
        "proposed_dev_precision": proposal_dev_metrics["precision_target_1"],
        "proposed_dev_recall": proposal_dev_metrics["recall_target_1"],
        "proposed_dev_f1": proposal_dev_metrics["f1_target_1"],
        "bootstrap_resamples": len(bootstrap),
        "proposed_model_selection_frequency": proposed_model_frequency,
        "proposed_pair_selection_frequency": float(
            proposed_pair_frequency["row_pair_selection_frequency"]
        ),
        "proposed_threshold_frequency_conditional_on_model": float(
            proposed_pair_frequency["row_frequency_conditional_on_model"]
        ),
        "oob_delta_ci_2_5": float(oob_delta.quantile(0.025)),
        "oob_delta_median": float(oob_delta.median()),
        "oob_delta_ci_97_5": float(oob_delta.quantile(0.975)),
        "oob_fraction_delta_gt_zero": float((oob_delta > 0).mean()),
        "balanced_minus_unweighted_oob_ci_2_5": float(
            balanced_minus_unweighted_oob.quantile(0.025)
        ),
        "balanced_minus_unweighted_oob_median": float(
            balanced_minus_unweighted_oob.median()
        ),
        "balanced_minus_unweighted_oob_ci_97_5": float(
            balanced_minus_unweighted_oob.quantile(0.975)
        ),
        "balanced_minus_unweighted_oob_fraction_gt_zero": float(
            (balanced_minus_unweighted_oob > 0).mean()
        ),
        "grouped_sensitivity_analysis_role": (
            "post_decision_non_selecting_dev_only"
        ),
        "grouped_sensitivity_influenced_selection": False,
        "grouped_sensitivity_sampling_unit": (
            "url_canonical_strict_content_group"
        ),
        "grouped_sensitivity_resamples": len(grouped_bootstrap),
        "grouped_total_dev_groups": int(dev_group_sizes.size),
        "grouped_multirow_dev_groups": int((dev_group_sizes > 1).sum()),
        "grouped_rows_in_multirow_dev_groups": int(
            dev_group_sizes.loc[dev_group_sizes > 1].sum()
        ),
        "dev_rows_with_strict_train_overlap": dev_rows_overlapping_train,
        "grouped_proposed_model_selection_frequency": float(
            grouped_selection_frequency.get(proposed_model, 0.0)
        ),
        "grouped_proposed_pair_selection_frequency": float(
            proposed_pair_frequency["grouped_pair_selection_frequency"]
        ),
        "grouped_proposed_threshold_frequency_conditional_on_model": float(
            proposed_pair_frequency["grouped_frequency_conditional_on_model"]
        ),
        "grouped_default_pair_selection_frequency": float(
            default_pair_frequency["grouped_pair_selection_frequency"]
        ),
        "grouped_oob_delta_ci_2_5": float(grouped_oob_delta.quantile(0.025)),
        "grouped_oob_delta_median": float(grouped_oob_delta.median()),
        "grouped_oob_delta_ci_97_5": float(grouped_oob_delta.quantile(0.975)),
        "grouped_oob_fraction_delta_gt_zero": float(
            (grouped_oob_delta > 0).mean()
        ),
        "adoption_gates": adoption_gates,
        "failed_adoption_gates": failed_gates,
        "decision": decision,
        "decision_reason": (
            "fair dev model-by-threshold proposal passes every joint OOB stability gate"
            if adopted
            else "fair dev proposal rejected because gates failed: "
            + ", ".join(failed_gates)
        ),
        "class_weight_decision": (
            "reject_balanced_class_weight"
            if proposed_model == "logreg_unweighted_c1"
            else "adopt_balanced_class_weight"
        ),
        "threshold_decision": (
            "adopt_dev_selected_threshold"
            if adopted and not np.isclose(proposed_threshold, default_threshold)
            else "retain_default_threshold"
        ),
        "selected_model": selected_model,
        "selected_threshold": selected_threshold,
        "selected_dev_precision": selected_dev_metrics["precision_target_1"],
        "selected_dev_recall": selected_dev_metrics["recall_target_1"],
        "selected_dev_f1": selected_dev_metrics["f1_target_1"],
        "selected_heldout_precision": selected_heldout_metrics[
            "precision_target_1"
        ],
        "selected_heldout_recall": selected_heldout_metrics["recall_target_1"],
        "selected_heldout_f1": selected_heldout_metrics["f1_target_1"],
        "selected_heldout_fp": selected_heldout_metrics["fp"],
        "selected_heldout_fn": selected_heldout_metrics["fn"],
        "selected_heldout_predicted_positive_count": (
            selected_heldout_metrics["fp"] + selected_heldout_metrics["tp"]
        ),
        "heldout_prediction_changes": len(changes),
    }

    sweep.to_csv(RESULTS_DIR / "ticket4_threshold_sweep.csv", index=False)
    canonical_sweep = sweep.loc[
        sweep["model_name"] == selected_model,
        [
            "threshold",
            "precision_target_1",
            "recall_target_1",
            "f1_target_1",
        ],
    ].copy()
    canonical_sweep.insert(0, "ticket", "ticket_4")
    canonical_sweep.to_csv(RESULTS_DIR / "threshold_sweep.csv", index=False)
    operating_points.to_csv(
        RESULTS_DIR / "ticket4_operating_points.csv", index=False
    )
    bootstrap.to_csv(
        RESULTS_DIR / "ticket4_selection_bootstrap.csv", index=False
    )
    grouped_bootstrap.to_csv(
        RESULTS_DIR / "ticket4_grouped_selection_sensitivity.csv", index=False
    )
    pair_frequency.to_csv(
        RESULTS_DIR / "ticket4_pair_selection_frequency.csv", index=False
    )
    statistics.to_csv(RESULTS_DIR / "ticket4_statistics.csv", index=False)
    changes.to_csv(RESULTS_DIR / "ticket4_prediction_changes.csv", index=False)
    (RESULTS_DIR / "ticket4_upstream_audit.json").write_text(
        json.dumps(upstream_audit, indent=2, sort_keys=True), encoding="utf-8"
    )
    (RESULTS_DIR / "ticket4_mechanism_summary.json").write_text(
        json.dumps(mechanism, indent=2, sort_keys=True), encoding="utf-8"
    )
    write_ticket_document(
        protocol,
        operating_points,
        bootstrap_summary,
        statistics,
        changes,
        mechanism,
    )
    update_interfaces(
        protocol,
        mechanism,
        selected_dev_score,
        selected_heldout_score,
        data.dev,
        data.heldout,
        selected_dev_metrics,
        selected_heldout_metrics,
        changes,
    )

    print(
        "Ticket 4 fair dev proposal="
        f"{proposed_model}@{proposed_threshold:.2f}; decision={decision}; "
        f"selected={selected_model}@{selected_threshold:.2f}"
    )
    print(
        "Selected dev/held-out F1="
        f"{selected_dev_metrics['f1_target_1']:.6f}/"
        f"{selected_heldout_metrics['f1_target_1']:.6f}; "
        f"OOB median delta={mechanism['oob_delta_median']:+.6f}; "
        f"positive fraction={mechanism['oob_fraction_delta_gt_zero']:.3f}"
    )


if __name__ == "__main__":
    main()
