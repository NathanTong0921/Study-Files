"""Run the staged Ticket 5 data-quality, duplicate, and error audit."""

from __future__ import annotations

import hashlib
import json
import re
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import binomtest
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import (
    accuracy_score,
    f1_score,
    precision_score,
    recall_score,
)
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.naive_bayes import ComplementNB
from sklearn.pipeline import Pipeline

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from pipeline.core import (  # noqa: E402
    binary_metrics,
    load_project_data,
    make_text_pipeline,
    predict_scores,
    prediction_frame,
    strict_content_key,
)


PROTOCOL_PATH = PROJECT_ROOT / "configs" / "ticket5_protocol.json"
TICKET4_PROTOCOL_PATH = PROJECT_ROOT / "configs" / "ticket4_protocol.json"
RESULTS_DIR = PROJECT_ROOT / "results"
PREDICTIONS_DIR = PROJECT_ROOT / "predictions"
TICKET_PATH = PROJECT_ROOT / "tickets" / "ticket-5-data-quality.md"

URL_RE = re.compile(r"(?:https?://|www\.)\S+", flags=re.IGNORECASE)
MENTION_RE = re.compile(r"(?<!\w)@[A-Za-z0-9_]+")
HASHTAG_RE = re.compile(r"(?<!\w)#([A-Za-z0-9_]+)")
NON_ALNUM_RE = re.compile(r"[^a-z0-9]+")
SPACE_RE = re.compile(r"\s+")


def same_finite_number(actual: object, expected: object) -> bool:
    """Compare JSON numeric contract values without accepting strings or booleans."""
    numeric_types = (int, float)
    if (
        isinstance(actual, bool)
        or isinstance(expected, bool)
        or not isinstance(actual, numeric_types)
        or not isinstance(expected, numeric_types)
    ):
        return False
    return bool(
        np.isfinite(float(actual))
        and np.isfinite(float(expected))
        and float(actual) == float(expected)
    )


def ticket4_model_spec(model_name: str) -> dict:
    """Return the unique Ticket 4 registry entry inherited by Ticket 5."""
    with TICKET4_PROTOCOL_PATH.open(encoding="utf-8") as handle:
        ticket4_protocol = json.load(handle)
    matches = [
        item
        for item in ticket4_protocol.get("model_registry", [])
        if item.get("name") == model_name
    ]
    if len(matches) != 1:
        raise ValueError(
            "Ticket 5 upstream_model must identify exactly one Ticket 4 model."
        )
    specification = matches[0]
    required = {"family", "c", "class_weight"}
    if not required.issubset(specification):
        missing = sorted(required - set(specification))
        raise ValueError(
            f"Ticket 4 upstream model specification is missing fields: {missing}"
        )
    return specification


def load_protocol() -> dict:
    with PROTOCOL_PATH.open(encoding="utf-8") as handle:
        protocol = json.load(handle)
    registry = protocol["sensitivity_registry"]
    names = [item["name"] for item in registry]
    if len(names) != len(set(names)):
        raise ValueError("Ticket 5 sensitivity names must be unique.")
    eligible = [item for item in registry if item["eligible_for_adoption"]]
    primary = protocol["primary_correction_rule"]["name"]
    if len(eligible) != 1 or eligible[0]["name"] != primary:
        raise ValueError("Exactly the frozen primary correction may be adopted.")
    if protocol["primary_correction_rule"]["uses_dev_or_heldout_labels"]:
        raise ValueError("Ticket 5 corrections must be training-only.")
    expected = {"fix", "keep_but_flag", "ambiguous", "reject_false_positive"}
    if set(protocol["audit_dispositions"]) != expected:
        raise ValueError("Ticket 5 disposition registry is invalid.")

    upstream_params = protocol.get("upstream_model_params")
    if not isinstance(upstream_params, dict) or set(upstream_params) != {
        "c",
        "class_weight",
    }:
        raise ValueError(
            "Ticket 5 upstream_model_params must contain exactly c and class_weight."
        )
    upstream_spec = ticket4_model_spec(str(protocol.get("upstream_model", "")))
    if upstream_spec["family"] != "logistic_regression":
        raise ValueError("Ticket 5 requires the frozen Ticket 4 logistic model.")
    if not same_finite_number(upstream_params["c"], upstream_spec["c"]):
        raise ValueError("Ticket 5 C does not match the Ticket 4 model registry.")
    if upstream_params["class_weight"] != upstream_spec["class_weight"]:
        raise ValueError(
            "Ticket 5 class_weight does not match the Ticket 4 model registry."
        )

    threshold = float(protocol["upstream_threshold"])
    with TICKET4_PROTOCOL_PATH.open(encoding="utf-8") as handle:
        ticket4_protocol = json.load(handle)
    start = float(ticket4_protocol["threshold_grid_start"])
    stop = float(ticket4_protocol["threshold_grid_stop"])
    step = float(ticket4_protocol["threshold_grid_step"])
    ticket4_grid = np.round(np.arange(start, stop + step / 2, step), 10)
    if not np.any(np.isclose(ticket4_grid, threshold, rtol=0, atol=1e-12)):
        raise ValueError("Ticket 5 threshold is not on Ticket 4's frozen grid.")
    return protocol


def url_only_preprocess(text: str) -> str:
    value = str(text).lower()
    value = URL_RE.sub(" url ", value)
    return SPACE_RE.sub(" ", value).strip()


def duplicate_base(text: str) -> str:
    return strict_content_key(text)


def strict_duplicate_key(text: str) -> str:
    return duplicate_base(text)


def relaxed_duplicate_key(text: str) -> str:
    value = MENTION_RE.sub(" user ", duplicate_base(text))
    value = HASHTAG_RE.sub(r" \1 ", value)
    return SPACE_RE.sub(" ", NON_ALNUM_RE.sub(" ", value)).strip()


def key_digest(key_type: str, value: str) -> str:
    digest = hashlib.sha256(f"{key_type}\0{value}".encode("utf-8")).hexdigest()
    return f"{key_type}_{digest[:12]}"


def attach_duplicate_keys(frame: pd.DataFrame) -> pd.DataFrame:
    output = frame.copy()
    text = output["text"].fillna("").astype(str)
    output["strict_key"] = text.map(strict_duplicate_key)
    output["relaxed_key"] = text.map(relaxed_duplicate_key)
    output["strict_group_id"] = output["strict_key"].map(
        lambda value: key_digest("strict", value)
    )
    output["relaxed_group_id"] = output["relaxed_key"].map(
        lambda value: key_digest("relaxed", value)
    )
    return output


def make_upstream_model(protocol: dict) -> Pipeline:
    params = protocol["shared_vectorizer_params"]
    model_params = protocol["upstream_model_params"]
    return make_text_pipeline(
        preprocessor=url_only_preprocess,
        lowercase=False,
        max_features=params.get("max_features"),
        stop_words=params["stop_words"],
        sublinear_tf=bool(params["sublinear_tf"]),
        class_weight=model_params["class_weight"],
        c=float(model_params["c"]),
        random_state=int(protocol["random_state"]),
    )


def make_oof_nb_model(protocol: dict) -> Pipeline:
    params = protocol["shared_vectorizer_params"]
    return Pipeline(
        [
            (
                "tfidf",
                TfidfVectorizer(
                    preprocessor=url_only_preprocess,
                    lowercase=False,
                    max_features=params.get("max_features"),
                    stop_words=params["stop_words"],
                    sublinear_tf=bool(params["sublinear_tf"]),
                ),
            ),
            ("classifier", ComplementNB(alpha=1.0)),
        ]
    )


def correction_candidates(
    train: pd.DataFrame, *, key_type: str, minimum_peers: int
) -> pd.DataFrame:
    key_column = f"{key_type}_key"
    group_column = f"{key_type}_group_id"
    rows: list[dict] = []
    for _, group in train.groupby(key_column, sort=True):
        if len(group) <= minimum_peers or group["target"].nunique() < 2:
            continue
        for position, item in group.iterrows():
            peers = group.drop(index=position)
            if len(peers) < minimum_peers or peers["target"].nunique() != 1:
                continue
            peer_label = int(peers["target"].iloc[0])
            if peer_label == int(item["target"]):
                continue
            rows.append(
                {
                    "id": int(item["id"]),
                    "group_id": str(item[group_column]),
                    "key_type": key_type,
                    "original_label": int(item["target"]),
                    "proposed_label": peer_label,
                    "unanimous_peer_count": int(len(peers)),
                    "training_group_size": int(len(group)),
                    "peer_label_0_count": int((peers["target"] == 0).sum()),
                    "peer_label_1_count": int((peers["target"] == 1).sum()),
                    "text": str(item["text"]),
                }
            )
    columns = [
        "id",
        "group_id",
        "key_type",
        "original_label",
        "proposed_label",
        "unanimous_peer_count",
        "training_group_size",
        "peer_label_0_count",
        "peer_label_1_count",
        "text",
    ]
    return pd.DataFrame(rows, columns=columns).sort_values("id").reset_index(drop=True)


def fit_variant(
    train: pd.DataFrame, protocol: dict, specification: dict, fixes: pd.DataFrame
) -> Pipeline:
    model = make_upstream_model(protocol)
    operation = specification["operation"]
    if operation == "none":
        fit_frame = train
        labels = train["target"]
    elif operation == "drop":
        fix_ids = set(fixes["id"].astype(int))
        fit_frame = train.loc[~train["id"].astype(int).isin(fix_ids)].copy()
        labels = fit_frame["target"]
    elif operation == "relabel":
        fit_frame = train
        fix_map = dict(zip(fixes["id"].astype(int), fixes["proposed_label"].astype(int)))
        labels = pd.Series(
            [
                fix_map.get(int(identifier), int(label))
                for identifier, label in zip(train["id"], train["target"])
            ],
            index=train.index,
        )
    else:
        raise ValueError(f"Unsupported Ticket 5 operation: {operation}")
    model.fit(fit_frame["text"].fillna(""), labels)
    return model


def paired_f1_statistics(
    y_true: np.ndarray,
    baseline_score: np.ndarray,
    candidate_score: np.ndarray,
    *,
    threshold: float,
    resamples: int,
    seed: int,
    groups: np.ndarray | None = None,
) -> dict:
    y = np.asarray(y_true, dtype=int)
    base_prediction = np.asarray(baseline_score) >= threshold
    candidate_prediction = np.asarray(candidate_score) >= threshold
    observed = float(
        f1_score(y, candidate_prediction, zero_division=0)
        - f1_score(y, base_prediction, zero_division=0)
    )
    rng = np.random.default_rng(seed)
    deltas = np.empty(resamples, dtype=float)
    if groups is None:
        sampling_unit = "row"
        for index in range(resamples):
            sample = rng.integers(0, len(y), size=len(y))
            deltas[index] = f1_score(
                y[sample], candidate_prediction[sample], zero_division=0
            ) - f1_score(y[sample], base_prediction[sample], zero_division=0)
    else:
        sampling_unit = "strict_duplicate_group"
        codes, unique_groups = pd.factorize(np.asarray(groups, dtype=object), sort=True)
        members = [np.flatnonzero(codes == code) for code in range(len(unique_groups))]
        for index in range(resamples):
            sampled_groups = rng.integers(0, len(members), size=len(members))
            sample = np.concatenate([members[group] for group in sampled_groups])
            deltas[index] = f1_score(
                y[sample], candidate_prediction[sample], zero_division=0
            ) - f1_score(y[sample], base_prediction[sample], zero_division=0)
    base_correct_candidate_wrong = int(
        np.sum((base_prediction == y) & (candidate_prediction != y))
    )
    base_wrong_candidate_correct = int(
        np.sum((base_prediction != y) & (candidate_prediction == y))
    )
    discordant = base_correct_candidate_wrong + base_wrong_candidate_correct
    exact_p = (
        float(
            binomtest(
                min(base_correct_candidate_wrong, base_wrong_candidate_correct),
                discordant,
                0.5,
            ).pvalue
        )
        if discordant and groups is None
        else 1.0
    )
    return {
        "observed_delta": observed,
        "bootstrap_sampling_unit": sampling_unit,
        "bootstrap_resamples": int(resamples),
        "ci_2_5": float(np.quantile(deltas, 0.025)),
        "median_delta": float(np.median(deltas)),
        "ci_97_5": float(np.quantile(deltas, 0.975)),
        "resampling_fraction_delta_gt_zero": float(np.mean(deltas > 0)),
        "baseline_correct_candidate_wrong": base_correct_candidate_wrong,
        "baseline_wrong_candidate_correct": base_wrong_candidate_correct,
        "discordant_correctness_pairs": discordant,
        "exact_mcnemar_p_value": exact_p if groups is None else np.nan,
        "correctness_test_note": (
            "row-level exact paired test"
            if groups is None
            else "not reported because exact row-pair independence is incompatible with grouped resampling"
        ),
    }


def prediction_changes(
    frame: pd.DataFrame,
    baseline_score: np.ndarray,
    candidate_score: np.ndarray,
    *,
    threshold: float,
) -> pd.DataFrame:
    y = frame["target"].to_numpy(dtype=int)
    old = np.asarray(baseline_score) >= threshold
    new = np.asarray(candidate_score) >= threshold
    changed = old != new
    change_type = np.select(
        [
            changed & (y == 0) & old & ~new,
            changed & (y == 1) & ~old & new,
            changed & (y == 0) & ~old & new,
            changed & (y == 1) & old & ~new,
        ],
        ["fixed_fp", "fixed_fn", "new_fp", "new_fn"],
        default="unchanged",
    )
    output = pd.DataFrame(
        {
            "ticket": "ticket_5",
            "id": frame["id"].astype(int),
            "y_true": y,
            "old_pred": old.astype(int),
            "new_pred": new.astype(int),
            "old_score": np.asarray(baseline_score),
            "new_score": np.asarray(candidate_score),
            "change_type": change_type,
            "score_change": np.asarray(candidate_score) - np.asarray(baseline_score),
            "text": frame["text"].fillna("").astype(str),
        }
    )
    return output.loc[changed].sort_values(["change_type", "id"]).reset_index(drop=True)


def oof_audit(train: pd.DataFrame, protocol: dict) -> pd.DataFrame:
    labels = train["target"].to_numpy(dtype=int)
    groups = train["strict_key"].to_numpy()
    folds = list(
        StratifiedGroupKFold(
            n_splits=int(protocol["oof_folds"]),
            shuffle=True,
            random_state=int(protocol["random_state"]),
        ).split(train, labels, groups=groups)
    )
    fold_assignment = np.empty(len(train), dtype=int)
    maximum_group_overlap = 0
    for fold, (fit_index, validation_index) in enumerate(folds):
        fold_assignment[validation_index] = fold
        overlap = set(groups[fit_index]).intersection(groups[validation_index])
        maximum_group_overlap = max(maximum_group_overlap, len(overlap))
    if maximum_group_overlap:
        raise AssertionError("Ticket 5 OOF leaks strict duplicate groups across folds.")
    scores: dict[str, np.ndarray] = {}
    upstream_name = protocol["upstream_model"]
    factories = {
        upstream_name: lambda: make_upstream_model(protocol),
        "complement_nb_alpha1": lambda: make_oof_nb_model(protocol),
    }
    for name in protocol["oof_audit_models"]:
        score = np.empty(len(train), dtype=float)
        for fit_index, validation_index in folds:
            model = factories[name]()
            model.fit(
                train.iloc[fit_index]["text"].fillna(""),
                train.iloc[fit_index]["target"],
            )
            score[validation_index] = predict_scores(model, train.iloc[validation_index])
        scores[name] = score
    lr_wrong = np.where(labels == 1, 1 - scores[upstream_name], scores[upstream_name])
    nb_wrong = np.where(labels == 1, 1 - scores["complement_nb_alpha1"], scores["complement_nb_alpha1"])
    threshold = float(protocol["model_only_disagreement_threshold"])
    return pd.DataFrame(
        {
            "id": train["id"].astype(int),
            "y_true": labels,
            "logreg_oof_score": scores[upstream_name],
            "complement_nb_oof_score": scores["complement_nb_alpha1"],
            "logreg_label_disagreement_score": lr_wrong,
            "complement_nb_label_disagreement_score": nb_wrong,
            "consensus_high_disagreement_score": (lr_wrong >= threshold)
            & (nb_wrong >= threshold),
            "oof_scheme": "stratified_group_k_fold_by_strict_duplicate_key",
            "oof_fold": fold_assignment,
            "oof_max_train_validation_group_overlap": maximum_group_overlap,
            "strict_group_id": train["strict_group_id"].astype(str),
            "relaxed_group_id": train["relaxed_group_id"].astype(str),
            "text": train["text"].fillna("").astype(str),
        }
    )


def duplicate_group_table(full: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict] = []
    for key_type in ("strict", "relaxed"):
        key_column = f"{key_type}_key"
        group_column = f"{key_type}_group_id"
        for _, group in full.groupby(key_column, sort=True):
            if len(group) < 2:
                continue
            counts = group["target"].value_counts()
            rows.append(
                {
                    "key_type": key_type,
                    "group_id": str(group[group_column].iloc[0]),
                    "row_count": int(len(group)),
                    "train_rows": int((group["split"] == "train").sum()),
                    "dev_rows": int((group["split"] == "dev").sum()),
                    "heldout_rows": int((group["split"] == "heldout").sum()),
                    "label_0_rows": int(counts.get(0, 0)),
                    "label_1_rows": int(counts.get(1, 0)),
                    "conflicting_labels": bool(group["target"].nunique() > 1),
                    "cross_split": bool(group["split"].nunique() > 1),
                    "key_excerpt": str(group[key_column].iloc[0])[:180],
                    "example_text": str(group["text"].iloc[0]),
                }
            )
    return pd.DataFrame(rows).sort_values(
        ["key_type", "conflicting_labels", "row_count", "group_id"],
        ascending=[True, False, False, True],
    ).reset_index(drop=True)


def build_audit_table(
    full: pd.DataFrame,
    primary_fixes: pd.DataFrame,
    oof: pd.DataFrame,
    *,
    correction_adopted: bool,
) -> pd.DataFrame:
    fix_lookup = primary_fixes.set_index("id").to_dict("index")
    correction_group_consensus: dict[str, dict] = {}
    for group_id, fixes in primary_fixes.groupby("group_id", sort=False):
        proposed_labels = fixes["proposed_label"].astype(int).unique()
        if len(proposed_labels) != 1:
            raise AssertionError(
                "One strict correction group cannot imply multiple consensus labels."
            )
        correction_group_consensus[str(group_id)] = {
            "label": int(proposed_labels[0]),
            "candidate_ids": sorted(fixes["id"].astype(int).tolist()),
            "peer_count": int(fixes["unanimous_peer_count"].max()),
        }
    strict_sizes = full.groupby("strict_key").size().to_dict()
    relaxed_sizes = full.groupby("relaxed_key").size().to_dict()
    audited_ids: set[int] = set()
    rows: list[dict] = []
    for item in full.itertuples(index=False):
        strict_size = int(strict_sizes[item.strict_key])
        relaxed_size = int(relaxed_sizes[item.relaxed_key])
        if strict_size < 2 and relaxed_size < 2:
            continue
        key_type = "strict" if strict_size >= 2 else "relaxed"
        key_column = f"{key_type}_key"
        group_column = f"{key_type}_group_id"
        key_value = getattr(item, key_column)
        group = full.loc[full[key_column] == key_value]
        train_group = group.loc[group["split"] == "train"]
        label_counts = group["target"].value_counts()
        train_counts = train_group["target"].value_counts()
        conflict = group["target"].nunique() > 1
        train_consensus = (
            int(train_group["target"].iloc[0])
            if len(train_group) and train_group["target"].nunique() == 1
            else None
        )
        identifier = int(item.id)
        strict_group_id = str(item.strict_group_id)
        proposed: int | float = np.nan
        if identifier in fix_lookup:
            disposition = "fix"
            issue_type = "training_strict_duplicate_consensus_minority"
            proposed = int(fix_lookup[identifier]["proposed_label"])
            audit_confidence = "high"
            confidence_basis = "training-only strict key with at least three unanimous opposing peers"
            evidence = (
                f"Training-only strict group has {fix_lookup[identifier]['unanimous_peer_count']} "
                f"other unanimous peers with label {proposed}; row label is {int(item.target)}."
            )
        elif (
            str(item.split) == "train"
            and strict_group_id in correction_group_consensus
            and int(item.target)
            == correction_group_consensus[strict_group_id]["label"]
        ):
            consensus = correction_group_consensus[strict_group_id]
            disposition = "keep_but_flag"
            issue_type = "training_strict_duplicate_consensus_peer"
            audit_confidence = "high"
            confidence_basis = (
                "training-only strict key; row supports the unanimous consensus "
                "used to flag the minority candidate"
            )
            evidence = (
                f"This row is one of {consensus['peer_count']} unanimous training "
                f"peers with label {consensus['label']} supporting minority candidate "
                f"ID(s) {', '.join(map(str, consensus['candidate_ids']))}; retain its "
                "label and flag duplicate weighting."
            )
        elif conflict:
            if train_consensus is not None and int(item.target) == train_consensus:
                disposition = "keep_but_flag"
                issue_type = f"{key_type}_duplicate_conflict_matches_train_consensus"
                audit_confidence = "moderate"
                confidence_basis = "duplicate conflict exists, but row agrees with unanimous training subset"
                evidence = (
                    f"{key_type} group labels are 0:{int(label_counts.get(0, 0))}, "
                    f"1:{int(label_counts.get(1, 0))}; this label matches the unanimous "
                    f"training label {train_consensus}, but the cross-row conflict is retained."
                )
            else:
                disposition = "ambiguous"
                issue_type = f"conflicting_{key_type}_duplicate"
                audit_confidence = "low"
                confidence_basis = "conflicting duplicate labels without eligible training-only consensus"
                evidence = (
                    f"{key_type} group labels are 0:{int(label_counts.get(0, 0))}, "
                    f"1:{int(label_counts.get(1, 0))}; training labels are "
                    f"0:{int(train_counts.get(0, 0))}, 1:{int(train_counts.get(1, 0))}. "
                    "No dev or held-out label is proposed for change."
                )
        else:
            disposition = "keep_but_flag"
            issue_type = f"consistent_{key_type}_duplicate"
            audit_confidence = "moderate"
            confidence_basis = "repeated content has consistent labels but alters evaluation weighting"
            evidence = (
                f"{key_type} duplicate group has {len(group)} rows with consistent label "
                f"{int(item.target)}; retain but flag repeated-content weighting."
            )
        rows.append(
            {
                "id": identifier,
                "issue_type": issue_type,
                "evidence": evidence,
                "disposition": disposition,
                "audit_confidence": audit_confidence,
                "confidence_basis": confidence_basis,
                "split": str(item.split),
                "original_label": int(item.target),
                "proposed_label": proposed,
                "used_in_selected_training": bool(
                    correction_adopted and disposition == "fix"
                ),
                "key_type": key_type,
                "group_id": str(getattr(item, group_column)),
                "group_size": int(len(group)),
                "requires_human_review": disposition in {"fix", "ambiguous"},
                "text": str(item.text),
            }
        )
        audited_ids.add(identifier)

    rejected = oof.loc[oof["consensus_high_disagreement_score"]].copy()
    for item in rejected.itertuples(index=False):
        identifier = int(item.id)
        if identifier in audited_ids:
            continue
        rows.append(
            {
                "id": identifier,
                "issue_type": "model_only_oof_consensus_disagreement",
                "evidence": (
                    f"Two strict-group-isolated OOF models oppose label {int(item.y_true)} with "
                    f"disagreement scores {item.logreg_label_disagreement_score:.3f} and "
                    f"{item.complement_nb_label_disagreement_score:.3f}, but no duplicate "
                    "evidence corroborates a label change."
                ),
                "disposition": "reject_false_positive",
                "audit_confidence": "low",
                "confidence_basis": "model disagreement only; no duplicate or human-label evidence",
                "split": "train",
                "original_label": int(item.y_true),
                "proposed_label": np.nan,
                "used_in_selected_training": False,
                "key_type": "none",
                "group_id": "",
                "group_size": 1,
                "requires_human_review": True,
                "text": str(item.text),
            }
        )
    audit = pd.DataFrame(rows)
    return audit.sort_values(["disposition", "id"]).reset_index(drop=True)


def subset_metrics(y: np.ndarray, score: np.ndarray, threshold: float) -> dict:
    return binary_metrics(y, score, threshold)


def build_overlap_metrics(
    train: pd.DataFrame,
    evaluations: list[tuple[str, pd.DataFrame, np.ndarray]],
    *,
    threshold: float,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    strict_train = set(train["strict_key"])
    relaxed_train = set(train["relaxed_key"])
    overlap_rows: list[dict] = []
    weighting_rows: list[dict] = []
    for split, frame, score in evaluations:
        stratum = np.where(
            frame["strict_key"].isin(strict_train),
            "strict_train_overlap",
            np.where(
                frame["relaxed_key"].isin(relaxed_train),
                "relaxed_only_train_overlap",
                "novel_to_train",
            ),
        )
        for name in ("all", "strict_train_overlap", "relaxed_only_train_overlap", "novel_to_train"):
            mask = np.ones(len(frame), dtype=bool) if name == "all" else stratum == name
            if not np.any(mask):
                continue
            metrics = subset_metrics(
                frame.loc[mask, "target"].to_numpy(dtype=int), np.asarray(score)[mask], threshold
            )
            overlap_rows.append(
                {
                    "split": split,
                    "stratum": name,
                    "rows": int(np.sum(mask)),
                    "positive_rate": float(frame.loc[mask, "target"].mean()),
                    **metrics,
                }
            )
        prediction = np.asarray(score) >= threshold
        y = frame["target"].to_numpy(dtype=int)
        for key_type in ("strict", "relaxed"):
            key_column = f"{key_type}_key"
            sizes = frame.groupby(key_column)["id"].transform("size").to_numpy(dtype=float)
            weights = 1.0 / sizes
            weighting_rows.append(
                {
                    "split": split,
                    "key_type": key_type,
                    "rows": len(frame),
                    "unique_content_groups": int(frame[key_column].nunique()),
                    "row_level_f1": float(f1_score(y, prediction, zero_division=0)),
                    "cluster_balanced_f1": float(
                        f1_score(y, prediction, sample_weight=weights, zero_division=0)
                    ),
                    "cluster_balanced_precision": float(
                        precision_score(y, prediction, sample_weight=weights, zero_division=0)
                    ),
                    "cluster_balanced_recall": float(
                        recall_score(y, prediction, sample_weight=weights, zero_division=0)
                    ),
                    "cluster_balanced_accuracy": float(
                        accuracy_score(y, prediction, sample_weight=weights)
                    ),
                }
            )
    return pd.DataFrame(overlap_rows), pd.DataFrame(weighting_rows)


def overlap_bootstrap_statistics(
    train: pd.DataFrame,
    evaluations: list[tuple[str, pd.DataFrame, np.ndarray]],
    *,
    threshold: float,
    resamples: int,
    seed: int,
) -> pd.DataFrame:
    strict_train = set(train["strict_key"])
    relaxed_train = set(train["relaxed_key"])
    rows: list[dict] = []
    for split_index, (split, frame, score) in enumerate(evaluations):
        overlap_mask = frame["strict_key"].isin(strict_train).to_numpy()
        novel_mask = ~frame["relaxed_key"].isin(relaxed_train).to_numpy()
        y = frame["target"].to_numpy(dtype=int)
        prediction = np.asarray(score) >= threshold
        overlap_y, overlap_prediction = y[overlap_mask], prediction[overlap_mask]
        novel_y, novel_prediction = y[novel_mask], prediction[novel_mask]
        overlap_groups = frame.loc[overlap_mask, "strict_key"].to_numpy()
        novel_groups = frame.loc[novel_mask, "strict_key"].to_numpy()
        overlap_codes, overlap_unique = pd.factorize(overlap_groups, sort=True)
        novel_codes, novel_unique = pd.factorize(novel_groups, sort=True)
        overlap_members = [
            np.flatnonzero(overlap_codes == code) for code in range(len(overlap_unique))
        ]
        novel_members = [
            np.flatnonzero(novel_codes == code) for code in range(len(novel_unique))
        ]
        observed = float(
            f1_score(overlap_y, overlap_prediction, zero_division=0)
            - f1_score(novel_y, novel_prediction, zero_division=0)
        )
        rng = np.random.default_rng(seed + split_index)
        deltas = np.empty(resamples, dtype=float)
        for index in range(resamples):
            overlap_sample = np.concatenate(
                [
                    overlap_members[group]
                    for group in rng.integers(
                        0, len(overlap_members), size=len(overlap_members)
                    )
                ]
            )
            novel_sample = np.concatenate(
                [
                    novel_members[group]
                    for group in rng.integers(
                        0, len(novel_members), size=len(novel_members)
                    )
                ]
            )
            deltas[index] = f1_score(
                overlap_y[overlap_sample],
                overlap_prediction[overlap_sample],
                zero_division=0,
            ) - f1_score(
                novel_y[novel_sample],
                novel_prediction[novel_sample],
                zero_division=0,
            )
        rows.append(
            {
                "split": split,
                "analysis": "strict_train_overlap_minus_novel_f1",
                "strict_overlap_rows": int(overlap_mask.sum()),
                "novel_rows": int(novel_mask.sum()),
                "strict_overlap_groups": int(len(overlap_members)),
                "novel_groups": int(len(novel_members)),
                "observed_f1_difference": observed,
                "bootstrap_sampling_unit": "within_stratum_strict_duplicate_group",
                "bootstrap_resamples": int(resamples),
                "ci_2_5": float(np.quantile(deltas, 0.025)),
                "median_difference": float(np.median(deltas)),
                "ci_97_5": float(np.quantile(deltas, 0.975)),
                "resampling_fraction_difference_gt_zero": float(np.mean(deltas > 0)),
            }
        )
    return pd.DataFrame(rows)


def top_contributions(model: Pipeline, text: str, limit: int = 3) -> tuple[str, str, list[dict]]:
    vectorizer = model.named_steps["tfidf"]
    classifier = model.named_steps["classifier"]
    matrix = vectorizer.transform([text])
    features = vectorizer.get_feature_names_out()
    coefficients = classifier.coef_[0]
    row = matrix.getrow(0)
    values = row.data * coefficients[row.indices]
    triples = [(str(features[index]), float(value)) for index, value in zip(row.indices, values)]
    positive = sorted((item for item in triples if item[1] > 0), key=lambda item: -item[1])[:limit]
    negative = sorted((item for item in triples if item[1] < 0), key=lambda item: item[1])[:limit]
    details = [
        {"direction": "positive", "feature": feature, "contribution": value}
        for feature, value in positive
    ] + [
        {"direction": "negative", "feature": feature, "contribution": value}
        for feature, value in negative
    ]
    positive_text = "; ".join(f"{feature}:{value:.3f}" for feature, value in positive)
    negative_text = "; ".join(f"{feature}:{value:.3f}" for feature, value in negative)
    return positive_text, negative_text, details


def error_attribution(
    model: Pipeline,
    train: pd.DataFrame,
    evaluations: list[tuple[str, pd.DataFrame, np.ndarray]],
    *,
    threshold: float,
    hard_margin: float,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    strict_train = set(train["strict_key"])
    relaxed_train = set(train["relaxed_key"])
    train_strict_conflicts = set(
        train.groupby("strict_key")["target"].nunique().loc[lambda values: values > 1].index
    )
    rows: list[dict] = []
    feature_rows: list[dict] = []
    for split, frame, score in evaluations:
        y = frame["target"].to_numpy(dtype=int)
        prediction = np.asarray(score) >= threshold
        for position in np.flatnonzero(prediction != y):
            item = frame.iloc[position]
            error_type = "false_positive" if y[position] == 0 else "false_negative"
            hard = bool(
                score[position] >= threshold + hard_margin
                if y[position] == 0
                else score[position] <= threshold - hard_margin
            )
            strict_overlap = item["strict_key"] in strict_train
            relaxed_overlap = item["relaxed_key"] in relaxed_train
            stratum = (
                "strict_train_overlap"
                if strict_overlap
                else "relaxed_only_train_overlap"
                if relaxed_overlap
                else "novel_to_train"
            )
            positive, negative, details = top_contributions(model, str(item["text"]))
            rows.append(
                {
                    "id": int(item["id"]),
                    "split": split,
                    "y_true": int(y[position]),
                    "y_pred": int(prediction[position]),
                    "score": float(score[position]),
                    "error_type": error_type,
                    "hard_error": hard,
                    "duplicate_stratum": stratum,
                    "training_strict_group_conflict": item["strict_key"] in train_strict_conflicts,
                    "top_positive_contributors": positive,
                    "top_negative_contributors": negative,
                    "keyword": "" if pd.isna(item["keyword"]) else str(item["keyword"]),
                    "text": str(item["text"]),
                }
            )
            for detail in details:
                feature_rows.append(
                    {
                        "split": split,
                        "error_type": error_type,
                        "direction": detail["direction"],
                        "feature": detail["feature"],
                        "contribution": detail["contribution"],
                    }
                )
    errors = pd.DataFrame(rows).sort_values(["split", "error_type", "score"]).reset_index(drop=True)
    slices = (
        errors.groupby(["split", "error_type", "hard_error", "duplicate_stratum"], dropna=False)
        .agg(rows=("id", "size"), mean_score=("score", "mean"))
        .reset_index()
    )
    features = pd.DataFrame(feature_rows)
    feature_summary = (
        features.groupby(["split", "error_type", "direction", "feature"])
        .agg(rows=("feature", "size"), mean_contribution=("contribution", "mean"))
        .reset_index()
        .sort_values(["split", "error_type", "direction", "rows"], ascending=[True, True, True, False])
    )
    return errors, slices, feature_summary


def verify_upstream(
    protocol: dict,
    dev: pd.DataFrame,
    heldout: pd.DataFrame,
    dev_score: np.ndarray,
    heldout_score: np.ndarray,
) -> dict:
    with (RESULTS_DIR / "run_manifest.json").open(encoding="utf-8") as handle:
        manifest = json.load(handle)
    ticket4_summary = manifest.get("ticket_4_protocol")
    if not isinstance(ticket4_summary, dict):
        raise AssertionError("Run manifest has no Ticket 4 protocol summary.")
    manifest_params = manifest.get("final_model_parameters")
    if not isinstance(manifest_params, dict):
        raise AssertionError("Run manifest has no final model parameters.")

    upstream_name = str(protocol["upstream_model"])
    upstream_spec = ticket4_model_spec(upstream_name)
    upstream_params = protocol["upstream_model_params"]
    expected_threshold = float(protocol["upstream_threshold"])
    expected_model = (
        f"{upstream_name}_threshold_"
        f"{expected_threshold:.2f}"
    )
    if manifest["final_model_name"] != expected_model:
        raise AssertionError(
            "Ticket 5 protocol does not match the model frozen by Ticket 4."
        )
    required_manifest_params = {"family", "c", "class_weight", "threshold"}
    if not required_manifest_params.issubset(manifest_params):
        missing = sorted(required_manifest_params - set(manifest_params))
        raise AssertionError(
            f"Run manifest final model parameters are missing fields: {missing}"
        )

    contract_checks = {
        "ticket4 selected model": ticket4_summary.get("selected_model")
        == upstream_name,
        "model family": manifest_params["family"] == upstream_spec["family"],
        "C versus Ticket 5": same_finite_number(
            manifest_params["c"], upstream_params["c"]
        ),
        "C versus Ticket 4": same_finite_number(
            manifest_params["c"], upstream_spec["c"]
        ),
        "class_weight versus Ticket 5": manifest_params["class_weight"]
        == upstream_params["class_weight"],
        "class_weight versus Ticket 4": manifest_params["class_weight"]
        == upstream_spec["class_weight"],
        "threshold versus Ticket 5": same_finite_number(
            manifest_params["threshold"], expected_threshold
        ),
        "threshold versus Ticket 4 summary": same_finite_number(
            ticket4_summary.get("selected_threshold"), expected_threshold
        ),
        "selected_threshold_on_dev": same_finite_number(
            manifest.get("selected_threshold_on_dev"), expected_threshold
        ),
    }
    failed_contract_checks = [
        name for name, passed in contract_checks.items() if not passed
    ]
    if failed_contract_checks:
        raise AssertionError(
            "Ticket 5 upstream contract disagrees with Ticket 4: "
            + ", ".join(failed_contract_checks)
        )

    dev_reference = pd.read_csv(PREDICTIONS_DIR / "ticket_4_selected_dev.csv")[
        ["id", "score"]
    ]
    heldout_reference = pd.read_csv(PREDICTIONS_DIR / "ticket_4_selected_heldout.csv")[["id", "score"]]
    dev_expected = dev["id"].map(dev_reference.set_index("id")["score"]).to_numpy(float)
    held_expected = heldout["id"].map(heldout_reference.set_index("id")["score"]).to_numpy(float)
    if np.isnan(dev_expected).any() or np.isnan(held_expected).any():
        raise ValueError("Ticket 5 upstream artifacts do not cover all IDs.")
    tolerance = 1e-12
    audit = {
        "upstream_model": expected_model,
        "ticket4_manifest_model": manifest["final_model_name"],
        "family": manifest_params["family"],
        "c": float(manifest_params["c"]),
        "class_weight": manifest_params["class_weight"],
        "threshold": float(manifest_params["threshold"]),
        "manifest_contract_checks": contract_checks,
        "dev_max_absolute_score_difference": float(np.max(np.abs(dev_score - dev_expected))),
        "heldout_max_absolute_score_difference": float(
            np.max(np.abs(heldout_score - held_expected))
        ),
        "tolerance": tolerance,
    }
    audit["within_tolerance"] = bool(
        audit["dev_max_absolute_score_difference"] <= tolerance
        and audit["heldout_max_absolute_score_difference"] <= tolerance
    )
    if not audit["within_tolerance"]:
        raise AssertionError("Ticket 5 does not reproduce the frozen Ticket 4 upstream.")
    return audit


def markdown_table(frame: pd.DataFrame, columns: list[str], limit: int | None = None) -> str:
    selected = frame.loc[:, columns]
    if limit is not None:
        selected = selected.head(limit)
    if selected.empty:
        return "No rows met this criterion."
    lines = [
        "| " + " | ".join(columns) + " |",
        "| " + " | ".join(["---"] * len(columns)) + " |",
    ]
    for row in selected.itertuples(index=False, name=None):
        values = []
        for value in row:
            if isinstance(value, float):
                rendered = "" if np.isnan(value) else f"{value:.4f}"
            else:
                rendered = str(value)
            rendered = SPACE_RE.sub(" ", rendered).replace("|", "\\|")
            values.append(rendered if len(rendered) <= 100 else rendered[:99] + "…")
        lines.append("| " + " | ".join(values) + " |")
    return "\n".join(lines)


def write_ticket_document(
    protocol: dict,
    ablation: pd.DataFrame,
    fixes: pd.DataFrame,
    statistics: pd.DataFrame,
    jackknife: pd.DataFrame,
    groups: pd.DataFrame,
    audit: pd.DataFrame,
    overlap: pd.DataFrame,
    overlap_statistics: pd.DataFrame,
    weighting: pd.DataFrame,
    errors: pd.DataFrame,
    feature_summary: pd.DataFrame,
    changes: pd.DataFrame,
    mechanism: dict,
) -> None:
    ablation_display = ablation[
        [
            "model_name",
            "operation",
            "correction_rows",
            "dev_f1_target_1",
            "dev_delta_f1_vs_upstream",
            "heldout_f1_target_1",
            "heldout_evaluated_after_freeze",
        ]
    ].copy()
    fix_display = fixes[
        [
            "id",
            "original_label",
            "proposed_label",
            "unanimous_peer_count",
            "logreg_oof_score",
            "complement_nb_oof_score",
            "text",
        ]
    ].copy()
    disposition_counts = audit["disposition"].value_counts().to_dict()
    examples = pd.concat(
        [
            group.sort_values("id").head(2)
            for _, group in audit.groupby("disposition", sort=True)
        ],
        ignore_index=True,
    )
    strict_groups = groups.loc[groups["key_type"] == "strict"]
    relaxed_groups = groups.loc[groups["key_type"] == "relaxed"]
    overlap_display = overlap[
        ["split", "stratum", "rows", "precision_target_1", "recall_target_1", "f1_target_1"]
    ].copy()
    weighting_display = weighting[
        ["split", "key_type", "unique_content_groups", "row_level_f1", "cluster_balanced_f1"]
    ].copy()
    overlap_statistics_display = overlap_statistics[
        [
            "split",
            "observed_f1_difference",
            "ci_2_5",
            "ci_97_5",
            "resampling_fraction_difference_gt_zero",
        ]
    ].copy()
    jackknife_display = jackknife[
        [
            "omitted_correction_ids",
            "omitted_label_change",
            "dev_delta_f1_vs_upstream",
            "prediction_changes_vs_upstream",
            "omitted_text",
        ]
    ].sort_values("dev_delta_f1_vs_upstream")
    feature_display = (
        feature_summary.sort_values(
            ["split", "error_type", "direction", "rows"],
            ascending=[True, True, True, False],
        )
        .groupby(["split", "error_type", "direction"], sort=False)
        .head(2)[
            ["split", "error_type", "direction", "feature", "rows", "mean_contribution"]
        ]
    )
    hard_examples = pd.concat(
        [
            errors.loc[
                (errors["split"] == split)
                & (errors["error_type"] == error_type)
                & errors["hard_error"]
            ]
            .sort_values("score", ascending=error_type == "false_negative")
            .head(2)
            for split in ("dev", "heldout")
            for error_type in ("false_positive", "false_negative")
        ],
        ignore_index=True,
    )
    hard_counts = {
        (split, error_type): int(
            (
                (errors["split"] == split)
                & (errors["error_type"] == error_type)
                & errors["hard_error"].astype(bool)
            ).sum()
        )
        for split in ("dev", "heldout")
        for error_type in ("false_positive", "false_negative")
    }
    heldout_stat = statistics.loc[
        statistics["analysis"] == "candidate_minus_upstream_heldout_group_primary"
    ].iloc[0]
    dev_stat = statistics.loc[
        statistics["analysis"] == "candidate_minus_upstream_dev_group_primary"
    ].iloc[0]
    change_counts = changes["change_type"].value_counts().to_dict()
    content = f"""# Ticket 5 — Data-quality and error audit

## Answer in one sentence

The frozen training-only duplicate rule identifies {len(fixes)} label-consistency fixes, but their corrected model is **{mechanism['decision'].upper()}ED**: although dev F1 changes by {dev_stat['observed_delta']:+.6f} and {mechanism['jackknife_probability_positive']:.1%} of group-jackknife deltas are positive, the strict-group bootstrap interval [{dev_stat['ci_2_5']:+.6f}, {dev_stat['ci_97_5']:+.6f}] crosses zero; the final through-Ticket-5 model therefore remains `{mechanism['selected_model']}` at threshold {mechanism['selected_threshold']:.2f}.

## Frozen protocol and intended lever

**Hypothesis.** {protocol['hypothesis']}

The intended lever is **training-label correction supported by URL-canonical strict duplicate consensus**. A training row is eligible only when at least three other training rows share its strict key, every peer has the same label, and that unanimous label opposes the row. Dev and held-out labels never enter a proposal. The relaxed key masks mentions and punctuation and is audit-only. A five-fold strict-group-isolated OOF logistic/CNB consensus flag is also audit-only: without duplicate corroboration it is assigned `reject_false_positive`, not `fix`.

Adoption requires all four dev conditions: positive point F1 delta, a positive strict-group-bootstrap lower bound, a positive leave-one-correction-group-out median, and at least 60% positive group-jackknife deltas. The upstream refit matches Ticket 4 probabilities within {mechanism['upstream_dev_max_abs_diff']:.3g} on dev and {mechanism['upstream_heldout_max_abs_diff']:.3g} on held-out.

## Duplicate structure and correction evidence

The strict audit finds {len(strict_groups)} duplicate groups covering {int(strict_groups['row_count'].sum())} row memberships; {int(strict_groups['conflicting_labels'].sum())} groups have conflicting labels and {int(strict_groups['cross_split'].sum())} cross split boundaries. The relaxed audit finds {len(relaxed_groups)} groups covering {int(relaxed_groups['row_count'].sum())} memberships, including {int(relaxed_groups['conflicting_labels'].sum())} conflicts. The larger relaxed counts are evidence about sensitivity, not permission to broaden the correction rule.

{markdown_table(fix_display, list(fix_display.columns), limit=12)}

Every proposed label is preserved beside its original label. OOF scores are secondary evidence only; they do not define the fix. Their grouped folds have maximum strict-group train/validation overlap {mechanism['oof_max_train_validation_group_overlap']}.

## Controlled correction and stability

{markdown_table(ablation_display, list(ablation_display.columns))}

The primary corrected model changes dev F1 by {dev_stat['observed_delta']:+.6f}; the strict-group bootstrap interval is [{dev_stat['ci_2_5']:+.6f}, {dev_stat['ci_97_5']:+.6f}], with {dev_stat['resampling_fraction_delta_gt_zero']:.1%} of resamples above zero. A row-bootstrap sensitivity is retained in the statistics artifact but does not drive adoption. Across {len(jackknife)} leave-one-correction-group-out fits, median delta is {mechanism['jackknife_median_delta']:+.6f} and {mechanism['jackknife_probability_positive']:.1%} are positive. Thus a plausible data-consistency repair is not automatically a supported predictive improvement.

{markdown_table(jackknife_display, list(jackknife_display.columns), limit=12)}

The leave-one-group table reveals whether the apparent gain is distributed or driven by particular correction groups; both negative and positive deltas are retained rather than summarized away.

After rejection was frozen, the candidate held-out delta is {heldout_stat['observed_delta']:+.6f}, interval [{heldout_stat['ci_2_5']:+.6f}, {heldout_stat['ci_97_5']:+.6f}]. It fixes {change_counts.get('fixed_fp', 0)} FP and {change_counts.get('fixed_fn', 0)} FN while creating {change_counts.get('new_fp', 0)} FP and {change_counts.get('new_fn', 0)} FN. This post-freeze result cannot reverse the dev decision.

## Cross-split repetition and score limitation

{markdown_table(overlap_display, list(overlap_display.columns))}

{markdown_table(overlap_statistics_display, list(overlap_statistics_display.columns))}

{markdown_table(weighting_display, list(weighting_display.columns))}

The overlap table keeps every fixed-split row and reports performance by content provenance. Cluster-balanced F1 gives each within-split duplicate key total weight one; it is a sensitivity estimand, not a replacement score and does not delete held-out examples. The overlap gap is descriptive rather than causal because the strata also differ in class mix and difficulty.

## Ambiguity, hard negatives, and model-only findings

Disposition counts are: fix={disposition_counts.get('fix', 0)}, keep-but-flag={disposition_counts.get('keep_but_flag', 0)}, ambiguous={disposition_counts.get('ambiguous', 0)}, and rejected model-only findings={disposition_counts.get('reject_false_positive', 0)}. Here, `fix` is an audit/human-review disposition, not automatic model adoption; the separate `used_in_selected_training` field records the dev-gated pipeline decision. Within each eligible correction group, the minority candidate is `fix/high`, while its unanimous supporting training peers are `keep_but_flag/high`; they are evidence for the correction candidate, not ambiguous rows. Other conflicting duplicate labels remain policy/data ambiguity unless the training-only strict rule supplies consensus evidence. Consistent duplicates are kept but flagged because repetition changes evaluation weighting.

{markdown_table(examples, ['id', 'split', 'original_label', 'proposed_label', 'used_in_selected_training', 'disposition', 'audit_confidence', 'confidence_basis', 'issue_type', 'evidence'], limit=10)}

`error_type` records only `false_positive` or `false_negative`; the independent Boolean `hard_error` records whether the score is at least {protocol['hard_error_margin']:.2f} beyond the decision boundary. Hard negatives—target-0 false positives satisfying this margin—number {hard_counts[('dev', 'false_positive')]} on dev and {hard_counts[('heldout', 'false_positive')]} on held-out ({hard_counts[('dev', 'false_positive')] + hard_counts[('heldout', 'false_positive')]} total); hard false negatives number {hard_counts[('dev', 'false_negative')]} and {hard_counts[('heldout', 'false_negative')]}, respectively ({hard_counts[('dev', 'false_negative')] + hard_counts[('heldout', 'false_negative')]} total). Feature contributions come from the frozen linear model and explain model behavior, not label correctness.

{markdown_table(hard_examples, ['id', 'split', 'y_true', 'score', 'error_type', 'hard_error', 'duplicate_stratum', 'top_positive_contributors', 'top_negative_contributors', 'text'], limit=10)}

{markdown_table(feature_display, list(feature_display.columns), limit=20)}

The complete error and feature tables retain every error. Frequent contributors can identify lexical mechanisms, but no token is treated as proof that a label is wrong.

## Decision

**{mechanism['decision'].upper()} the training-label correction candidate; retain `{mechanism['selected_model']}` at threshold {mechanism['selected_threshold']:.2f}.** Final dev F1 is {mechanism['selected_dev_f1']:.6f}; held-out precision/recall/F1 are {mechanism['selected_heldout_precision']:.6f}/{mechanism['selected_heldout_recall']:.6f}/{mechanism['selected_heldout_f1']:.6f}. The {mechanism['correction_rows']} rows remain explicit human-review and dataset-consistency candidates; `used_in_selected_training` records whether they entered the frozen training labels. No held-out label was modified and no held-out row was removed.

## Limitations

Duplicate agreement establishes internal consistency, not ground-truth semantics; copied messages can still be assigned different labels under an unstated annotation policy. Relaxed matching can merge distinct messages. OOF consensus remains correlated model evidence, and linear token contributions omit pragmatic context, sarcasm, images, and linked-page content. The fixed split cannot establish how duplication or ambiguity behaves in future data, so production repair requires human reannotation under an explicit rubric.

Artifacts: `configs/ticket5_protocol.json`, `results/ticket5_correction_candidates.csv`, `results/ticket5_correction_ablation.csv`, `results/ticket5_statistics.csv`, `results/ticket5_group_jackknife.csv`, `results/ticket5_duplicate_groups.csv`, canonical `results/data_quality_audit.csv`, detailed `results/ticket5_audit_table.csv`, `results/ticket5_oof_audit.csv`, `results/ticket5_overlap_metrics.csv`, `results/ticket5_overlap_statistics.csv`, `results/ticket5_duplicate_weighting.csv`, `results/ticket5_error_attribution.csv`, `results/ticket5_error_slices.csv`, `results/ticket5_error_feature_summary.csv`, `results/ticket5_prediction_changes.csv`, and `predictions/ticket_5_data_quality_heldout.csv`.
"""
    TICKET_PATH.write_text(content.strip() + "\n", encoding="utf-8")


def update_interfaces(
    protocol: dict,
    ablation: pd.DataFrame,
    changes: pd.DataFrame,
    audit: pd.DataFrame,
    oof: pd.DataFrame,
    mechanism: dict,
    candidate_dev_metrics: dict,
    candidate_heldout_metrics: dict,
    final_dev_metrics: dict,
    final_heldout_metrics: dict,
    final_heldout_score: np.ndarray,
    heldout: pd.DataFrame,
) -> None:
    counts = changes["change_type"].value_counts().to_dict()
    summary_path = RESULTS_DIR / "summary.csv"
    summary = pd.read_csv(summary_path)
    row = {
        "ticket": "ticket_5",
        "model_name": (
            f"{mechanism['selected_model']}_threshold_"
            f"{mechanism['selected_threshold']:.2f}"
        ),
        "dev_f1_target_1": final_dev_metrics["f1_target_1"],
        "heldout_f1_target_1": final_heldout_metrics["f1_target_1"],
        "heldout_accuracy": final_heldout_metrics["accuracy"],
        "fixed_fp": int(counts.get("fixed_fp", 0)),
        "fixed_fn": int(counts.get("fixed_fn", 0)),
        "new_fp": int(counts.get("new_fp", 0)),
        "new_fn": int(counts.get("new_fn", 0)),
        "decision": mechanism["decision"],
        "decision_reason": mechanism["decision_reason"],
    }
    pd.concat(
        [summary.loc[summary["ticket"] != "ticket_5"], pd.DataFrame([row])],
        ignore_index=True,
    ).sort_values("ticket").to_csv(summary_path, index=False)

    final_label = f"{mechanism['selected_model']}_threshold_{mechanism['selected_threshold']:.2f}"
    prediction_frame(
        heldout,
        final_heldout_score,
        model_name=final_label,
        ticket="final_through_ticket_5",
        threshold=float(mechanism["selected_threshold"]),
    ).to_csv(PREDICTIONS_DIR / "heldout_predictions.csv", index=False)

    manifest_path = RESULTS_DIR / "run_manifest.json"
    with manifest_path.open(encoding="utf-8") as handle:
        manifest = json.load(handle)
    manifest["ticket_5_protocol"] = {
        "protocol_version": protocol["protocol_version"],
        **mechanism,
    }
    manifest["ticket_5_inherits_frozen_ticket_4"] = True
    manifest["dependency_status"] = {
        "ticket_1_complete": True,
        "ticket_2_complete": True,
        "ticket_3_complete": True,
        "ticket_4_complete": True,
        "ticket_5_complete": True,
    }
    manifest["training_label_fixes_proposed"] = int(mechanism["correction_rows"])
    manifest["correction_selected_on_dev"] = mechanism["decision"] == "adopt"
    manifest["final_model_name"] = final_label
    manifest["final_model_parameters"] = {
        "family": "logistic_regression",
        "c": float(protocol["upstream_model_params"]["c"]),
        "class_weight": protocol["upstream_model_params"]["class_weight"],
        "threshold": float(mechanism["selected_threshold"]),
        **protocol["shared_vectorizer_params"],
    }
    manifest["final_dev_metrics"] = final_dev_metrics
    manifest["final_heldout_metrics"] = final_heldout_metrics
    manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True), encoding="utf-8")


def main() -> None:
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    PREDICTIONS_DIR.mkdir(parents=True, exist_ok=True)
    protocol = load_protocol()
    data = load_project_data()
    threshold = float(protocol["upstream_threshold"])
    seed = int(protocol["random_state"])

    # Phase 1: correction evidence is training-only; models are selected on dev.
    train = attach_duplicate_keys(data.train)
    dev = attach_duplicate_keys(data.dev)
    primary_name = protocol["primary_correction_rule"]["name"]
    variant_fixes: dict[str, pd.DataFrame] = {}
    models: dict[str, Pipeline] = {}
    dev_scores: dict[str, np.ndarray] = {}
    ablation_rows: list[dict] = []

    for specification in protocol["sensitivity_registry"]:
        name = specification["name"]
        if specification["operation"] == "none":
            fixes = correction_candidates(train, key_type="strict", minimum_peers=3).iloc[0:0]
        else:
            fixes = correction_candidates(
                train,
                key_type=specification["key"],
                minimum_peers=int(specification["minimum_unanimous_training_peers"]),
            )
        variant_fixes[name] = fixes
        model = fit_variant(train, protocol, specification, fixes)
        score = predict_scores(model, dev)
        metrics = binary_metrics(dev["target"], score, threshold)
        models[name] = model
        dev_scores[name] = score
        ablation_rows.append(
            {
                "model_name": name,
                "operation": specification["operation"],
                "key_type": specification.get("key", "none"),
                "minimum_unanimous_training_peers": specification.get(
                    "minimum_unanimous_training_peers", np.nan
                ),
                "correction_rows": len(fixes),
                "eligible_for_adoption": bool(specification["eligible_for_adoption"]),
                "dev_precision_target_1": metrics["precision_target_1"],
                "dev_recall_target_1": metrics["recall_target_1"],
                "dev_f1_target_1": metrics["f1_target_1"],
                "dev_accuracy": metrics["accuracy"],
                "heldout_precision_target_1": np.nan,
                "heldout_recall_target_1": np.nan,
                "heldout_f1_target_1": np.nan,
                "heldout_accuracy": np.nan,
                "heldout_evaluated_after_freeze": False,
            }
        )

    baseline_name = "original_upstream"
    baseline_dev_score = dev_scores[baseline_name]
    primary_dev_score = dev_scores[primary_name]
    ablation = pd.DataFrame(ablation_rows)
    baseline_dev_f1 = float(
        ablation.loc[ablation["model_name"] == baseline_name, "dev_f1_target_1"].iloc[0]
    )
    ablation["dev_delta_f1_vs_upstream"] = ablation["dev_f1_target_1"] - baseline_dev_f1

    # Dev upstream check occurs before selection; held-out is checked in Phase 2.
    dev_reference = pd.read_csv(PREDICTIONS_DIR / "ticket_4_selected_dev.csv")[
        ["id", "score"]
    ]
    expected_dev = dev["id"].map(dev_reference.set_index("id")["score"]).to_numpy(float)
    dev_upstream_difference = float(np.max(np.abs(baseline_dev_score - expected_dev)))
    if dev_upstream_difference > 1e-12:
        raise AssertionError("Ticket 5 dev upstream does not match frozen Ticket 4.")

    oof = oof_audit(train, protocol)
    primary_fixes = variant_fixes[primary_name].merge(
        oof[
            [
                "id",
                "logreg_oof_score",
                "complement_nb_oof_score",
                "logreg_label_disagreement_score",
                "complement_nb_label_disagreement_score",
            ]
        ],
        on="id",
        how="left",
        validate="one_to_one",
    )

    dev_group_statistics = paired_f1_statistics(
        dev["target"].to_numpy(dtype=int),
        baseline_dev_score,
        primary_dev_score,
        threshold=threshold,
        resamples=int(protocol["bootstrap_resamples"]),
        seed=seed + 700,
        groups=dev["strict_key"].to_numpy(),
    )
    dev_group_statistics["analysis"] = "candidate_minus_upstream_dev_group_primary"
    dev_row_statistics = paired_f1_statistics(
        dev["target"].to_numpy(dtype=int),
        baseline_dev_score,
        primary_dev_score,
        threshold=threshold,
        resamples=int(protocol["bootstrap_resamples"]),
        seed=seed + 702,
    )
    dev_row_statistics["analysis"] = "candidate_minus_upstream_dev_row_sensitivity"

    jackknife_rows: list[dict] = []
    for omitted_group in sorted(primary_fixes["group_id"].unique()):
        omitted = primary_fixes.loc[primary_fixes["group_id"] == omitted_group]
        retained = primary_fixes.loc[primary_fixes["group_id"] != omitted_group]
        specification = next(
            item for item in protocol["sensitivity_registry"] if item["name"] == primary_name
        )
        model = fit_variant(train, protocol, specification, retained)
        score = predict_scores(model, dev)
        metrics = binary_metrics(dev["target"], score, threshold)
        jackknife_rows.append(
            {
                "omitted_group_id": omitted_group,
                "omitted_correction_ids": ";".join(
                    map(str, omitted["id"].astype(int).tolist())
                ),
                "omitted_label_change": ";".join(
                    f"{int(row.original_label)}->{int(row.proposed_label)}"
                    for row in omitted.itertuples(index=False)
                ),
                "omitted_text": " || ".join(omitted["text"].astype(str).tolist()),
                "retained_correction_rows": len(retained),
                "dev_f1_target_1": metrics["f1_target_1"],
                "dev_delta_f1_vs_upstream": metrics["f1_target_1"] - baseline_dev_f1,
                "prediction_changes_vs_upstream": int(
                    np.sum((score >= threshold) != (baseline_dev_score >= threshold))
                ),
            }
        )
    jackknife = pd.DataFrame(jackknife_rows)
    jackknife_median = float(jackknife["dev_delta_f1_vs_upstream"].median())
    jackknife_probability = float((jackknife["dev_delta_f1_vs_upstream"] > 0).mean())
    candidate_dev_metrics = binary_metrics(dev["target"], primary_dev_score, threshold)
    baseline_dev_metrics = binary_metrics(dev["target"], baseline_dev_score, threshold)
    adoption_gates = {
        "positive_dev_point_delta": bool(
            candidate_dev_metrics["f1_target_1"]
            > baseline_dev_metrics["f1_target_1"]
        ),
        "positive_strict_group_bootstrap_lower_bound": bool(
            dev_group_statistics["ci_2_5"] > 0
        ),
        "positive_group_jackknife_median": bool(jackknife_median > 0),
        "group_jackknife_probability_at_least_0_60": bool(
            jackknife_probability >= 0.60
        ),
    }
    failed_gates = [name for name, passed in adoption_gates.items() if not passed]
    adopted = all(adoption_gates.values())
    decision = "adopt" if adopted else "reject"
    primary_fixes = primary_fixes.copy()
    primary_fixes["modification_reason"] = (
        "training-only strict duplicate group with at least three unanimous peers"
    )
    primary_fixes["used_in_selected_training"] = bool(adopted)

    # Phase 2: the decision is frozen before any held-out score or label audit.
    heldout = attach_duplicate_keys(data.heldout)
    baseline_heldout_score = predict_scores(models[baseline_name], heldout)
    primary_heldout_score = predict_scores(models[primary_name], heldout)
    candidate_heldout_metrics = binary_metrics(data.heldout["target"], primary_heldout_score, threshold)
    for name, score in (
        (baseline_name, baseline_heldout_score),
        (primary_name, primary_heldout_score),
    ):
        metrics = binary_metrics(data.heldout["target"], score, threshold)
        mask = ablation["model_name"] == name
        ablation.loc[mask, "heldout_precision_target_1"] = metrics["precision_target_1"]
        ablation.loc[mask, "heldout_recall_target_1"] = metrics["recall_target_1"]
        ablation.loc[mask, "heldout_f1_target_1"] = metrics["f1_target_1"]
        ablation.loc[mask, "heldout_accuracy"] = metrics["accuracy"]
        ablation.loc[mask, "heldout_evaluated_after_freeze"] = True

    upstream_audit = verify_upstream(
        protocol,
        dev,
        heldout,
        baseline_dev_score,
        baseline_heldout_score,
    )
    heldout_group_statistics = paired_f1_statistics(
        data.heldout["target"].to_numpy(dtype=int),
        baseline_heldout_score,
        primary_heldout_score,
        threshold=threshold,
        resamples=int(protocol["bootstrap_resamples"]),
        seed=seed + 701,
        groups=heldout["strict_key"].to_numpy(),
    )
    heldout_group_statistics["analysis"] = (
        "candidate_minus_upstream_heldout_group_primary"
    )
    heldout_row_statistics = paired_f1_statistics(
        data.heldout["target"].to_numpy(dtype=int),
        baseline_heldout_score,
        primary_heldout_score,
        threshold=threshold,
        resamples=int(protocol["bootstrap_resamples"]),
        seed=seed + 703,
    )
    heldout_row_statistics["analysis"] = (
        "candidate_minus_upstream_heldout_row_sensitivity"
    )
    statistics = pd.DataFrame(
        [
            dev_group_statistics,
            dev_row_statistics,
            heldout_group_statistics,
            heldout_row_statistics,
        ]
    )
    changes = prediction_changes(
        data.heldout,
        baseline_heldout_score,
        primary_heldout_score,
        threshold=threshold,
    )

    if adopted:
        final_model = models[primary_name]
        final_dev_score = primary_dev_score
        final_heldout_score = primary_heldout_score
        selected_model = primary_name
    else:
        final_model = models[baseline_name]
        final_dev_score = baseline_dev_score
        final_heldout_score = baseline_heldout_score
        selected_model = protocol["upstream_model"]
    final_dev_metrics = binary_metrics(dev["target"], final_dev_score, threshold)
    final_heldout_metrics = binary_metrics(heldout["target"], final_heldout_score, threshold)

    full = pd.concat(
        [
            train.assign(split="train"),
            dev.assign(split="dev"),
            heldout.assign(split="heldout"),
        ],
        ignore_index=True,
    )
    groups = duplicate_group_table(full)
    audit = build_audit_table(
        full,
        primary_fixes,
        oof,
        correction_adopted=adopted,
    )
    overlap, weighting = build_overlap_metrics(
        train,
        [("dev", dev, final_dev_score), ("heldout", heldout, final_heldout_score)],
        threshold=threshold,
    )
    overlap_statistics = overlap_bootstrap_statistics(
        train,
        [("dev", dev, final_dev_score), ("heldout", heldout, final_heldout_score)],
        threshold=threshold,
        resamples=int(protocol["bootstrap_resamples"]),
        seed=seed + 800,
    )
    errors, error_slices, feature_summary = error_attribution(
        final_model,
        train,
        [("dev", dev, final_dev_score), ("heldout", heldout, final_heldout_score)],
        threshold=threshold,
        hard_margin=float(protocol["hard_error_margin"]),
    )

    correction_ids = set(primary_fixes["id"].astype(int))
    oof["primary_correction_candidate"] = oof["id"].astype(int).isin(correction_ids)
    counts = changes["change_type"].value_counts().to_dict()
    mechanism = {
        "upstream_dev_max_abs_diff": upstream_audit["dev_max_absolute_score_difference"],
        "upstream_heldout_max_abs_diff": upstream_audit[
            "heldout_max_absolute_score_difference"
        ],
        "correction_rows": len(primary_fixes),
        "correction_groups": int(primary_fixes["group_id"].nunique()),
        "correction_0_to_1": int(
            np.sum(
                (primary_fixes["original_label"] == 0)
                & (primary_fixes["proposed_label"] == 1)
            )
        ),
        "correction_1_to_0": int(
            np.sum(
                (primary_fixes["original_label"] == 1)
                & (primary_fixes["proposed_label"] == 0)
            )
        ),
        "dev_delta_f1": dev_group_statistics["observed_delta"],
        "dev_ci_2_5": dev_group_statistics["ci_2_5"],
        "dev_ci_97_5": dev_group_statistics["ci_97_5"],
        "dev_bootstrap_sampling_unit": dev_group_statistics[
            "bootstrap_sampling_unit"
        ],
        "dev_resampling_fraction_delta_gt_zero": dev_group_statistics[
            "resampling_fraction_delta_gt_zero"
        ],
        "jackknife_median_delta": jackknife_median,
        "jackknife_probability_positive": jackknife_probability,
        "heldout_delta_f1": heldout_group_statistics["observed_delta"],
        "heldout_ci_2_5": heldout_group_statistics["ci_2_5"],
        "heldout_ci_97_5": heldout_group_statistics["ci_97_5"],
        "heldout_bootstrap_sampling_unit": heldout_group_statistics[
            "bootstrap_sampling_unit"
        ],
        "heldout_prediction_changes": len(changes),
        "heldout_fixed_fp": int(counts.get("fixed_fp", 0)),
        "heldout_fixed_fn": int(counts.get("fixed_fn", 0)),
        "heldout_new_fp": int(counts.get("new_fp", 0)),
        "heldout_new_fn": int(counts.get("new_fn", 0)),
        "strict_duplicate_groups": int((groups["key_type"] == "strict").sum()),
        "strict_conflicting_groups": int(
            ((groups["key_type"] == "strict") & groups["conflicting_labels"]).sum()
        ),
        "relaxed_duplicate_groups": int((groups["key_type"] == "relaxed").sum()),
        "audit_fix_rows": int((audit["disposition"] == "fix").sum()),
        "audit_keep_but_flag_rows": int((audit["disposition"] == "keep_but_flag").sum()),
        "audit_ambiguous_rows": int((audit["disposition"] == "ambiguous").sum()),
        "audit_rejected_model_only_rows": int(
            (audit["disposition"] == "reject_false_positive").sum()
        ),
        "oof_consensus_disagreement_rows": int(
            oof["consensus_high_disagreement_score"].sum()
        ),
        "oof_scheme": str(oof["oof_scheme"].iloc[0]),
        "oof_max_train_validation_group_overlap": int(
            oof["oof_max_train_validation_group_overlap"].max()
        ),
        "dev_strict_overlap_minus_novel_f1": float(
            overlap_statistics.loc[
                overlap_statistics["split"] == "dev", "observed_f1_difference"
            ].iloc[0]
        ),
        "heldout_strict_overlap_minus_novel_f1": float(
            overlap_statistics.loc[
                overlap_statistics["split"] == "heldout", "observed_f1_difference"
            ].iloc[0]
        ),
        "hard_negative_rows": int(
            ((errors["error_type"] == "false_positive") & errors["hard_error"]).sum()
        ),
        "false_positive_rows": int((errors["error_type"] == "false_positive").sum()),
        "false_negative_rows": int((errors["error_type"] == "false_negative").sum()),
        "hard_false_negative_rows": int(
            ((errors["error_type"] == "false_negative") & errors["hard_error"]).sum()
        ),
        "adoption_gates": adoption_gates,
        "failed_adoption_gates": failed_gates,
        "decision": decision,
        "decision_reason": (
            "all protocol-specified dev bootstrap and group-stability criteria pass"
            if adopted
            else "protocol-specified dev gates failed: " + ", ".join(failed_gates)
        ),
        "selected_model": selected_model,
        "selected_threshold": threshold,
        "selected_dev_f1": final_dev_metrics["f1_target_1"],
        "selected_heldout_precision": final_heldout_metrics["precision_target_1"],
        "selected_heldout_recall": final_heldout_metrics["recall_target_1"],
        "selected_heldout_f1": final_heldout_metrics["f1_target_1"],
    }

    primary_fixes.to_csv(RESULTS_DIR / "ticket5_correction_candidates.csv", index=False)
    ablation.to_csv(RESULTS_DIR / "ticket5_correction_ablation.csv", index=False)
    statistics.to_csv(RESULTS_DIR / "ticket5_statistics.csv", index=False)
    jackknife.to_csv(RESULTS_DIR / "ticket5_group_jackknife.csv", index=False)
    groups.to_csv(RESULTS_DIR / "ticket5_duplicate_groups.csv", index=False)
    audit.to_csv(RESULTS_DIR / "ticket5_audit_table.csv", index=False)
    canonical_audit = audit.rename(
        columns={"audit_confidence": "confidence"}
    )[["id", "issue_type", "evidence", "disposition", "confidence"]]
    canonical_audit.to_csv(
        RESULTS_DIR / "data_quality_audit.csv", index=False
    )
    oof.to_csv(RESULTS_DIR / "ticket5_oof_audit.csv", index=False)
    overlap.to_csv(RESULTS_DIR / "ticket5_overlap_metrics.csv", index=False)
    overlap_statistics.to_csv(
        RESULTS_DIR / "ticket5_overlap_statistics.csv", index=False
    )
    weighting.to_csv(RESULTS_DIR / "ticket5_duplicate_weighting.csv", index=False)
    errors.to_csv(RESULTS_DIR / "ticket5_error_attribution.csv", index=False)
    error_slices.to_csv(RESULTS_DIR / "ticket5_error_slices.csv", index=False)
    feature_summary.to_csv(RESULTS_DIR / "ticket5_error_feature_summary.csv", index=False)
    changes.to_csv(RESULTS_DIR / "ticket5_prediction_changes.csv", index=False)
    (RESULTS_DIR / "ticket5_upstream_audit.json").write_text(
        json.dumps(upstream_audit, indent=2, sort_keys=True), encoding="utf-8"
    )
    (RESULTS_DIR / "ticket5_mechanism_summary.json").write_text(
        json.dumps(mechanism, indent=2, sort_keys=True), encoding="utf-8"
    )

    prediction_frame(
        heldout,
        primary_heldout_score,
        model_name=primary_name,
        ticket="ticket_5_candidate",
        threshold=threshold,
    ).to_csv(PREDICTIONS_DIR / "ticket_5_data_quality_heldout.csv", index=False)

    write_ticket_document(
        protocol,
        ablation,
        primary_fixes,
        statistics,
        jackknife,
        groups,
        audit,
        overlap,
        overlap_statistics,
        weighting,
        errors,
        feature_summary,
        changes,
        mechanism,
    )
    update_interfaces(
        protocol,
        ablation,
        changes,
        audit,
        oof,
        mechanism,
        candidate_dev_metrics,
        candidate_heldout_metrics,
        final_dev_metrics,
        final_heldout_metrics,
        final_heldout_score,
        heldout,
    )

    print(
        f"Ticket 5 fixes={len(primary_fixes)} across {primary_fixes['group_id'].nunique()} groups; "
        f"decision={decision}; dev delta={dev_group_statistics['observed_delta']:+.6f}"
    )
    print(
        f"Selected={selected_model}@{threshold:.2f}; dev/held-out F1="
        f"{final_dev_metrics['f1_target_1']:.6f}/{final_heldout_metrics['f1_target_1']:.6f}; "
        f"held-out candidate changes={len(changes)}"
    )


if __name__ == "__main__":
    main()
