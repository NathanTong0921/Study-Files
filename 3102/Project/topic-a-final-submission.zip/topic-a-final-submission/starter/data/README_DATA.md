# Real Starter Data

This project uses the Kaggle Natural Language Processing with Disaster Tweets
data from the public mirror `ucbrise/kaggle-nlp-disasters`.

Only `train.csv` is required by the assignment and the reproducible workflow.
The unused Kaggle test and sample-submission files are intentionally omitted
from this clean project copy.

## Columns

- `id`: unique integer tweet id.
- `keyword`: optional Kaggle keyword field.
- `location`: optional user-provided location.
- `text`: tweet text used by your models and audits.
- `target`: binary label, where `1` means a real disaster and `0` means not a real disaster.

## Split

`split_indices.json` contains three disjoint id lists:

- `train_ids`: 4567 rows used for fitting final models.
- `dev_ids`: 1523 rows used for choosing levers and hyperparameters.
- `heldout_ids`: 1523 rows used only for finished-ticket reporting.

Class balance in this fixed split:

- Full sample: 3271 positive, 4342 negative.
- Train split: 1962 positive, 2605 negative.
- Dev split: 655 positive, 868 negative.
- Held-out split: 654 positive, 869 negative.

The split is stratified and deterministic with seed `3102`. Do not regenerate it for submitted runs.
