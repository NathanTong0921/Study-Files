from __future__ import annotations

import json
import platform
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest
import scipy
import sklearn

from experiments import run_ticket1
from experiments.run_ticket2 import make_preprocessor
from experiments.run_ticket4 import select_best_row
from pipeline.core import (
    binary_metrics,
    load_project_data,
    normalize_social_text,
    prediction_frame,
    strict_content_key,
)


ROOT = Path(__file__).resolve().parents[1]


def load_json(relative_path: str) -> dict:
    with (ROOT / relative_path).open(encoding="utf-8") as handle:
        return json.load(handle)


def test_fixed_split_contract() -> None:
    data = load_project_data()
    assert (len(data.train), len(data.dev), len(data.heldout)) == (4567, 1523, 1523)
    assert tuple(part["target"].sum() for part in (data.train, data.dev, data.heldout)) == (
        1962,
        655,
        654,
    )
    split_ids = [set(part["id"]) for part in (data.train, data.dev, data.heldout)]
    assert split_ids[0].isdisjoint(split_ids[1])
    assert split_ids[0].isdisjoint(split_ids[2])
    assert split_ids[1].isdisjoint(split_ids[2])


def test_social_normalizers_change_only_declared_markup() -> None:
    text = "ALERT @Rescue: #ForestFire #alllower #New_York https://example.test/a!"
    assert (
        normalize_social_text(text)
        == "alert user : forestfire alllower new_york url"
    )

    mention = make_preprocessor(["mention"])
    mention_remove = make_preprocessor(["mention_remove"])
    hashtag = make_preprocessor(["hashtag_decompose"])
    hashtag_generic = make_preprocessor(["hashtag_generic"])
    assert mention is not None
    assert mention_remove is not None
    assert hashtag is not None
    assert hashtag_generic is not None
    assert strict_content_key("Ａ &amp; B HTTPS://EXAMPLE.TEST/a") == "a & b url"
    assert mention(text) == (
        "alert user : #forestfire #alllower #new_york https://example.test/a!"
    )
    assert mention_remove(text) == (
        "alert : #forestfire #alllower #new_york https://example.test/a!"
    )
    assert hashtag(text) == (
        "alert @rescue: forest fire alllower new york https://example.test/a!"
    )
    assert hashtag_generic(text) == (
        "alert @rescue: hashtag hashtag hashtag https://example.test/a!"
    )


def test_metric_and_prediction_schema() -> None:
    metrics = binary_metrics([0, 0, 1, 1], [0.1, 0.8, 0.4, 0.9], threshold=0.5)
    assert metrics["tp"] == metrics["tn"] == 1
    assert metrics["fp"] == metrics["fn"] == 1

    frame = pd.DataFrame({"id": [4, 9], "target": [0, 1]})
    output = prediction_frame(frame, [0.2, 0.7], model_name="test", ticket="test")
    assert list(output.columns) == [
        "id",
        "y_true",
        "y_pred",
        "score",
        "model_name",
        "ticket",
    ]
    assert output["y_pred"].tolist() == [0, 1]


def test_protocol_dependency_chain_is_explicit_and_unconfounded() -> None:
    t1 = load_json("configs/ticket1_protocol.json")
    assert t1["primary_baseline_model"] == "unweighted_controlled_baseline"
    assert t1["downstream_baseline_model"] == "unweighted_controlled_baseline"
    models_1 = {item["name"]: item for item in t1["models"]}
    assert len(models_1) == 8
    assert all(
        item["pipeline_params"]["class_weight"] is None
        and item["pipeline_params"]["c"] == 1.0
        for item in t1["models"]
    )
    factor_names = [item["name"] for item in t1["preprocessing_factors"]]
    assert {
        tuple(item["factor_levels"][factor] for factor in factor_names)
        for item in t1["models"]
    } == {
        (first, second, third)
        for first in (0, 1)
        for second in (0, 1)
        for third in (0, 1)
    }
    assert models_1["unweighted_controlled_baseline"]["pipeline_params"] == {
        "max_features": 5000,
        "stop_words": "english",
        "sublinear_tf": True,
        "class_weight": None,
        "c": 1.0,
    }

    t2 = load_json("configs/ticket2_protocol.json")
    assert t2["baseline_model"] == "unweighted_controlled_baseline"
    assert t2["shared_pipeline_params"] == {
        "max_features": 5000,
        "stop_words": "english",
        "sublinear_tf": True,
        "class_weight": None,
        "c": 1.0,
    }
    nonbaseline_2 = [
        item
        for item in t2["dev_only_ablation_registry"]
        if item["name"] != t2["baseline_model"]
    ]
    assert all(len(item["operations"]) == 1 for item in nonbaseline_2)

    t3 = load_json("configs/ticket3_protocol.json")
    assert t3["upstream_representation"] == "unweighted_controlled_baseline"
    assert t3["ticket2_sensitivity_representation"] == "url_only_normalization"
    assert t3["shared_pipeline_params"]["class_weight"] is None
    eligible_3 = [
        item["name"] for item in t3["dev_registry"] if item["eligible_for_adoption"]
    ]
    assert eligible_3 == ["text_plus_keyword"]
    for pair in t3["feature_pairs"]:
        isolated = next(
            item for item in t3["dev_registry"] if item["name"] == pair["isolated_model"]
        )
        incremental = next(
            item
            for item in t3["dev_registry"]
            if item["name"] == pair["incremental_model"]
        )
        assert len(isolated["feature_groups"]) == 1
        assert "text" in incremental["feature_groups"]
        assert len(incremental["feature_groups"]) == 2

    t4 = load_json("configs/ticket4_protocol.json")
    assert (
        t4["upstream_representation"]
        == "ticket2_url_normalization_plus_ticket3_no_shallow_features"
    )
    assert t4["baseline_model"] == "logreg_unweighted_c1"
    assert [
        item["name"] for item in t4["model_registry"]
    ] == ["logreg_unweighted_c1", "logreg_balanced_c1"]
    assert [
        item["class_weight"] for item in t4["model_registry"]
    ] == [None, "balanced"]
    assert {item["c"] for item in t4["model_registry"]} == {1.0}
    assert [
        item["preference_rank"] for item in t4["model_registry"]
    ] == [0, 1]
    assert (
        t4["threshold_grid_start"],
        t4["threshold_grid_stop"],
        t4["threshold_grid_step"],
    ) == (0.2, 0.8, 0.01)
    assert "On dev, evaluate every model-threshold pair" in t4["selection_rule"]
    assert "cannot enter an adoption gate" in t4["grouped_sensitivity_rule"]
    assert t4["grouped_sensitivity_resamples"] == 2000
    assert "Held-out cannot change" in t4["heldout_policy"]

    t5 = load_json("configs/ticket5_protocol.json")
    assert t5["upstream_model"] == "logreg_unweighted_c1"
    assert t5["upstream_model_params"] == {"c": 1.0, "class_weight": None}
    assert t5["upstream_threshold"] == 0.44
    assert t5["oof_audit_models"][0] == t5["upstream_model"]
    assert t5["primary_correction_rule"]["eligible_split"] == "train"
    assert not t5["primary_correction_rule"]["uses_dev_or_heldout_labels"]
    assert "No held-out label is edited" in t5["heldout_policy"]


def test_generated_interfaces_are_complete_and_unambiguous() -> None:
    summary = pd.read_csv(ROOT / "results" / "summary.csv")
    assert summary["ticket"].tolist() == [f"ticket_{number}" for number in range(1, 6)]
    assert summary["ticket"].is_unique
    assert summary.set_index("ticket").loc["ticket_1", "model_name"] == (
        "unweighted_controlled_baseline"
    )
    assert summary.set_index("ticket").loc["ticket_4", "model_name"] == (
        "logreg_unweighted_c1_threshold_0.44"
    )
    assert summary.set_index("ticket").loc["ticket_5", "model_name"] == (
        "logreg_unweighted_c1_threshold_0.44"
    )

    predictions = pd.read_csv(ROOT / "predictions" / "heldout_predictions.csv")
    assert list(predictions.columns) == [
        "id",
        "y_true",
        "y_pred",
        "score",
        "model_name",
        "ticket",
    ]
    assert len(predictions) == 1523
    assert predictions["id"].is_unique
    assert predictions["model_name"].nunique() == 1
    assert (
        predictions["model_name"].iloc[0]
        == "logreg_unweighted_c1_threshold_0.44"
    )

    manifest = load_json("results/run_manifest.json")
    assert manifest["dependency_status"] == {
        "ticket_1_complete": True,
        "ticket_2_complete": True,
        "ticket_3_complete": True,
        "ticket_4_complete": True,
        "ticket_5_complete": True,
    }
    assert "baseline_parameters" not in manifest
    assert manifest["controlled_baseline_parameters"]["class_weight"] is None
    assert manifest["ticket_4_fair_joint_dev_selection"]
    assert manifest["final_model_parameters"]["class_weight"] is None
    assert manifest["final_model_parameters"]["threshold"] == 0.44
    assert manifest["final_model_name"] == "logreg_unweighted_c1_threshold_0.44"
    assert manifest["selected_threshold_on_dev"] == 0.44
    assert manifest["ticket_5_inherits_frozen_ticket_4"]
    assert "ticket_5_rebased_on_ticket_4" not in manifest
    for ticket_number in range(1, 6):
        protocol = load_json(f"configs/ticket{ticket_number}_protocol.json")
        assert manifest[f"ticket_{ticket_number}_protocol"]["protocol_version"] == (
            protocol["protocol_version"]
        )
    ticket4_mechanism = load_json("results/ticket4_mechanism_summary.json")
    assert ticket4_mechanism["protocol_version"] == load_json(
        "configs/ticket4_protocol.json"
    )["protocol_version"]
    assert manifest["python"] == platform.python_version()
    assert isinstance(manifest["python_executable"], str)
    assert manifest["python_executable"]
    assert manifest["numpy"] == np.__version__
    assert manifest["pandas"] == pd.__version__
    assert manifest["scipy"] == scipy.__version__
    assert manifest["scikit_learn"] == sklearn.__version__
    assert manifest["pytest"] == pytest.__version__
    assert manifest["pip"] == run_ticket1.importlib.metadata.version("pip")
    assert manifest["environment_specification"] == "requirements-lock.txt"
    assert manifest["requirements_lock_sha256"] == run_ticket1.file_sha256(
        run_ticket1.LOCK_PATH
    )

def test_ticket1_manifest_refreshes_runtime_without_dropping_extensions(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    results_dir = tmp_path / "results"
    results_dir.mkdir()
    stale_manifest = {
        "python": "0.0.0",
        "python_executable": r"D:\stale\python.exe",
        "numpy": "0",
        "pandas": "0",
        "scipy": "0",
        "scikit_learn": "0",
        "legacy_extension": {"keep": True},
    }
    (results_dir / "run_manifest.json").write_text(
        json.dumps(stale_manifest), encoding="utf-8"
    )
    monkeypatch.setattr(run_ticket1, "RESULTS_DIR", results_dir)

    protocol = {
        "protocol_version": "manifest-refresh-test",
        "primary_baseline_model": "baseline",
        "downstream_baseline_model": "baseline",
        "default_tfidf_probe_model": "baseline",
        "random_state": 42,
    }
    matrix = pd.DataFrame(
        [
            {
                "model_name": "baseline",
                "dev_f1_target_1": 0.5,
                "heldout_f1_target_1": 0.5,
                "heldout_accuracy": 0.5,
                "contract_reference_f1": 0.6,
                "contract_tolerance": 0.001,
                "absolute_reference_gap": 0.1,
                "within_contract_tolerance": False,
            }
        ]
    )
    run_ticket1.update_interfaces(protocol, matrix, attribution={})

    manifest = json.loads(
        (results_dir / "run_manifest.json").read_text(encoding="utf-8")
    )
    assert manifest["python"] == platform.python_version()
    assert manifest["python_executable"] == sys.executable
    assert manifest["numpy"] == np.__version__
    assert manifest["pandas"] == pd.__version__
    assert manifest["scipy"] == scipy.__version__
    assert manifest["scikit_learn"] == sklearn.__version__
    assert manifest["pytest"] == pytest.__version__
    assert manifest["pip"] == run_ticket1.importlib.metadata.version("pip")
    assert manifest["environment_specification"] == "requirements-lock.txt"
    assert manifest["requirements_lock_sha256"] == run_ticket1.file_sha256(
        run_ticket1.LOCK_PATH
    )
    assert manifest["data_sha256"] == run_ticket1.file_sha256(
        run_ticket1.DATA_DIR / "train.csv"
    )
    assert manifest["split_sha256"] == run_ticket1.file_sha256(
        run_ticket1.SPLIT_PATH
    )
    assert manifest["legacy_extension"] == {"keep": True}


def test_ticket1_attributes_controlled_baseline_gap_without_model_levers() -> None:
    protocol = load_json("configs/ticket1_protocol.json")
    matrix = pd.read_csv(ROOT / "results" / "ticket1_model_matrix.csv").set_index(
        "model_name"
    )
    controlled = matrix.loc[protocol["primary_baseline_model"]]
    closest = matrix.loc["feature_cap_plus_sublinear"]

    assert len(matrix) == 8
    assert not bool(controlled["within_contract_tolerance"])
    assert controlled["absolute_reference_gap"] > controlled["contract_tolerance"]
    assert bool(closest["within_contract_tolerance"])
    assert closest["absolute_reference_gap"] <= closest["contract_tolerance"]
    assert controlled["feature_cap_5000"] == closest["feature_cap_5000"] == 1
    assert controlled["sublinear_tf"] == closest["sublinear_tf"] == 1
    assert controlled["english_stop_words"] == 1
    assert closest["english_stop_words"] == 0
    assert not matrix["pipeline_params"].str.contains("balanced", case=False).any()

    split_audit = load_json("results/ticket1_split_audit.json")
    assert split_audit["pairwise_overlap_count"] == 0
    assert split_audit["full_id_coverage"]
    assert all(
        item["declared_order_exact_match"]
        for item in split_audit["split_identity"].values()
    )

    reproducibility = pd.read_csv(ROOT / "results" / "ticket1_reproducibility.csv")
    assert set(reproducibility["model_name"]) == {"unweighted_controlled_baseline"}
    assert (reproducibility["prediction_changes_vs_canonical"] == 0).all()
    assert reproducibility["max_absolute_score_delta"].max() < 1e-10
    assert reproducibility["heldout_f1_target_1"].nunique() == 1

    statistics = pd.read_csv(ROOT / "results" / "ticket1_statistics.csv")
    assert set(statistics["split"]) == {"dev", "heldout"}
    assert (
        statistics["ci_2_5"]
        <= statistics["observed_f1_delta"]
    ).all()
    assert (
        statistics["observed_f1_delta"]
        <= statistics["ci_97_5"]
    ).all()

    effects = pd.read_csv(
        ROOT / "results" / "ticket1_preprocessing_factor_effects.csv"
    ).set_index("factor")
    stop_words = effects.loc["english_stop_words"]
    assert stop_words["mean_heldout_f1_effect"] < 0
    assert stop_words["gap_improved_strata"] == 0
    assert stop_words["gap_worsened_strata"] == 4

    attribution = load_json("results/ticket1_gap_attribution.json")
    assert attribution["split"]["status"].startswith("ruled_out")
    assert attribution["seed_and_fit_order"]["status"].startswith("ruled_out")
    assert attribution["version"]["status"].startswith("unresolved")
    assert (
        attribution["preprocessing"]["closest_nonbaseline_cell"]
        == "feature_cap_plus_sublinear"
    )
    assert attribution["preprocessing"]["closest_cell_differs_from_baseline_by"] == [
        "english_stop_words"
    ]
    assert (
        attribution["preprocessing"]["strongest_average_gap_influencing_factor"]
        == "english_stop_words"
    )
    assert attribution["downstream_decision"]["ticket2_anchor_unchanged"]


def test_ticket2_uses_controlled_anchor_and_freezes_before_heldout() -> None:
    protocol = load_json("configs/ticket2_protocol.json")
    upstream = load_json("results/ticket2_upstream_audit.json")
    assert upstream["expected_anchor"] == "unweighted_controlled_baseline"
    assert upstream["within_tolerance"]
    assert upstream["dev_max_absolute_score_difference"] < 1e-12
    assert upstream["heldout_max_absolute_score_difference"] < 1e-12

    ablation = pd.read_csv(ROOT / "results" / "ticket2_ablation.csv").set_index(
        "model_name"
    )
    baseline = ablation.loc[protocol["baseline_model"]]
    candidate = ablation.loc[protocol["candidate_model"]]
    assert candidate["dev_f1_target_1"] > baseline["dev_f1_target_1"]
    assert bool(candidate["heldout_evaluated_after_freeze"])
    exploratory_names = {
        item["name"]
        for item in protocol["dev_only_ablation_registry"]
        if item["name"]
        not in {protocol["baseline_model"], protocol["candidate_model"]}
    }
    exploratory = ablation.loc[sorted(exploratory_names)]
    assert exploratory["heldout_f1_target_1"].isna().all()
    assert not exploratory["heldout_evaluated_after_freeze"].astype(bool).any()

    stress = pd.read_csv(ROOT / "results" / "ticket2_stress_matrix.csv")
    for factor in protocol["factor_registry"]:
        baseline_row = stress.loc[
            (stress["model_name"] == protocol["baseline_model"])
            & (stress["stress_test"] == factor["matched_stress"])
        ].iloc[0]
        factor_row = stress.loc[
            (stress["model_name"] == factor["model_name"])
            & (stress["stress_test"] == factor["matched_stress"])
        ].iloc[0]
        assert baseline_row["prediction_changes_vs_identity"] > 0
        assert factor_row["prediction_changes_vs_identity"] == 0
        assert factor_row["max_absolute_score_delta"] == 0

    factor_stats = pd.read_csv(
        ROOT / "results" / "ticket2_statistics.csv"
    )
    heldout_estimand = factor_stats.loc[
        factor_stats["analysis"] == "candidate_minus_baseline_heldout",
        "estimand",
    ].iloc[0]
    assert heldout_estimand == (
        "post-freeze held-out paired F1 difference for the URL policy"
    )
    for factor in ("mention", "hashtag"):
        row = factor_stats.loc[
            factor_stats["analysis"] == f"factor_{factor}_minus_baseline_dev"
        ].iloc[0]
        assert row["ci_2_5"] <= 0
        assert row["ci_97_5"] >= 0

    selected = pd.read_csv(ROOT / "predictions" / "ticket_2_selected_heldout.csv")
    assert len(selected) == 1523
    assert selected["id"].is_unique
    assert selected["model_name"].iloc[0] == "url_only_normalization"


def test_ticket3_audits_isolated_and_incremental_shallow_signal() -> None:
    protocol = load_json("configs/ticket3_protocol.json")
    upstream = load_json("results/ticket3_upstream_audit.json")
    assert upstream["main_anchor"] == "unweighted_controlled_baseline"
    assert upstream["ticket2_sensitivity_anchor"] == "url_only_normalization"
    assert upstream["within_tolerance"]

    audit = pd.read_csv(ROOT / "results" / "ticket3_feature_audit.csv")
    assert len(audit) == len(protocol["feature_pairs"]) == 12
    assert audit["feature"].is_unique
    assert audit["isolated_model"].notna().all()
    assert audit["incremental_model"].notna().all()
    assert (
        audit["incremental_f1_ci_2_5"] <= 0
    ).all()
    assert (
        audit["incremental_f1_ci_97_5"] >= 0
    ).all()
    assert audit.set_index("feature").loc["keyword", "isolated_dev_f1"] > 0.6

    mechanism = load_json("results/ticket3_mechanism_summary.json")
    assert mechanism["controlled_anchor_dev_max_abs_diff"] < 1e-12
    assert mechanism["ticket2_url_sensitivity_dev_max_abs_diff"] < 1e-12
    assert mechanism["url_sensitivity_keyword_ci_97_5"] < 0
    assert mechanism["permuted_candidate_median_prediction_changes"] > 0
    assert mechanism["location_unseen_present_rate_heldout"] > 0.5

    manifest = load_json("results/run_manifest.json")
    ticket = manifest["ticket_3_protocol"]
    assert ticket["decision"] == "reject"
    assert ticket["selected_main_model"] == "controlled_text"
    assert ticket["selected_features"] == []

    ablation = pd.read_csv(ROOT / "results" / "ticket3_ablation.csv").set_index(
        "model_name"
    )
    assert bool(ablation.loc["controlled_text", "heldout_evaluated_after_freeze"])
    assert bool(ablation.loc["text_plus_keyword", "heldout_evaluated_after_freeze"])
    other = ablation.drop(index=["controlled_text", "text_plus_keyword"])
    assert other["heldout_f1_target_1"].isna().all()


def test_ticket4_jointly_selects_model_and_threshold_on_dev_only() -> None:
    protocol = load_json("configs/ticket4_protocol.json")
    upstream = load_json("results/ticket4_upstream_audit.json")
    assert upstream["ticket2_selected_normalization"] == "url_only_normalization"
    assert upstream["ticket3_selected_features"] == []
    assert upstream["within_tolerance"]

    sweep = pd.read_csv(ROOT / "results" / "ticket4_threshold_sweep.csv")
    expected_models = [item["name"] for item in protocol["model_registry"]]
    expected_thresholds = np.round(
        np.arange(
            protocol["threshold_grid_start"],
            protocol["threshold_grid_stop"]
            + protocol["threshold_grid_step"] / 2,
            protocol["threshold_grid_step"],
        ),
        10,
    )
    assert sweep["model_name"].drop_duplicates().tolist() == expected_models
    for model_name in expected_models:
        model_thresholds = (
            sweep.loc[sweep["model_name"] == model_name, "threshold"]
            .sort_values()
            .to_numpy()
        )
        np.testing.assert_allclose(model_thresholds, expected_thresholds)
    assert sweep.groupby("model_name").size().nunique() == 1

    canonical_sweep = pd.read_csv(ROOT / "results" / "threshold_sweep.csv")
    assert canonical_sweep.columns.tolist() == [
        "ticket",
        "threshold",
        "precision_target_1",
        "recall_target_1",
        "f1_target_1",
    ]
    assert canonical_sweep["ticket"].eq("ticket_4").all()
    selected_model_sweep = sweep.loc[
        sweep["model_name"] == "logreg_unweighted_c1",
        [
            "threshold",
            "precision_target_1",
            "recall_target_1",
            "f1_target_1",
        ],
    ].reset_index(drop=True)
    pd.testing.assert_frame_equal(
        canonical_sweep.drop(columns="ticket"),
        selected_model_sweep,
        check_dtype=False,
    )

    best = sweep.loc[sweep["per_model_dev_best"].astype(bool)].set_index(
        "model_name"
    )
    assert set(best.index) == set(expected_models)
    assert best.loc["logreg_unweighted_c1", "threshold"] == pytest.approx(0.44)
    assert best.loc[
        "logreg_unweighted_c1", "f1_target_1"
    ] == pytest.approx(0.749613601236476)
    assert best.loc["logreg_balanced_c1", "threshold"] == pytest.approx(0.46)
    assert best.loc[
        "logreg_balanced_c1", "f1_target_1"
    ] == pytest.approx(0.7456140350877193)
    assert (
        best.loc["logreg_unweighted_c1", "f1_target_1"]
        > best.loc["logreg_balanced_c1", "f1_target_1"]
    )

    proposal = sweep.loc[sweep["joint_dev_proposal"].astype(bool)]
    assert len(proposal) == 1
    assert proposal.iloc[0]["model_name"] == "logreg_unweighted_c1"
    assert proposal.iloc[0]["threshold"] == pytest.approx(0.44)

    # The declared tie-break prefers distance to 0.50, then the upstream model,
    # and finally the lower threshold (weakly higher recall) within one model.
    tied_models = pd.DataFrame(
        {
            "model_name": ["logreg_unweighted_c1", "logreg_balanced_c1"],
            "threshold": [0.51, 0.49],
            "f1_target_1": [0.75, 0.75],
            "recall_target_1": [0.70, 0.80],
        }
    )
    assert select_best_row(tied_models, protocol)["model_name"] == (
        "logreg_unweighted_c1"
    )
    tied_thresholds = pd.DataFrame(
        {
            "model_name": ["logreg_unweighted_c1", "logreg_unweighted_c1"],
            "threshold": [0.49, 0.51],
            "f1_target_1": [0.75, 0.75],
            "recall_target_1": [0.80, 0.80],
        }
    )
    assert select_best_row(tied_thresholds, protocol)["threshold"] == pytest.approx(
        0.49
    )

    mechanism = load_json("results/ticket4_mechanism_summary.json")
    assert mechanism["selection_uses_dev_for_model_variants"]
    assert mechanism["equal_threshold_grid_for_all_models"]
    assert mechanism["candidate_models"] == expected_models
    assert mechanism["proposed_model"] == "logreg_unweighted_c1"
    assert mechanism["proposed_threshold"] == pytest.approx(0.44)
    assert mechanism["proposed_model_selection_frequency"] >= protocol[
        "minimum_proposed_model_selection_frequency"
    ]
    assert 0 < mechanism["proposed_pair_selection_frequency"] < mechanism[
        "proposed_model_selection_frequency"
    ]
    assert 0 < mechanism[
        "proposed_threshold_frequency_conditional_on_model"
    ] < 1
    assert mechanism["oob_delta_median"] > 0
    assert mechanism["oob_fraction_delta_gt_zero"] >= protocol[
        "minimum_oob_fraction_positive"
    ]
    assert mechanism["balanced_minus_unweighted_oob_median"] < 0
    assert mechanism["balanced_minus_unweighted_oob_fraction_gt_zero"] < 0.5
    assert all(mechanism["adoption_gates"].values())
    assert mechanism["failed_adoption_gates"] == []
    assert mechanism["decision"] == "adopt"
    assert mechanism["class_weight_decision"] == "reject_balanced_class_weight"
    assert mechanism["threshold_decision"] == "adopt_dev_selected_threshold"
    assert mechanism["selected_model"] == "logreg_unweighted_c1"
    assert mechanism["selected_threshold"] == pytest.approx(0.44)
    assert not mechanism["grouped_sensitivity_influenced_selection"]
    assert mechanism["grouped_sensitivity_analysis_role"] == (
        "post_decision_non_selecting_dev_only"
    )
    assert mechanism["grouped_sensitivity_sampling_unit"] == (
        "url_canonical_strict_content_group"
    )
    assert mechanism["grouped_total_dev_groups"] == 1469
    assert mechanism["grouped_multirow_dev_groups"] == 35
    assert mechanism["grouped_rows_in_multirow_dev_groups"] == 89
    assert mechanism["dev_rows_with_strict_train_overlap"] == 142
    assert not any(key.startswith("grouped_") for key in mechanism["adoption_gates"])

    bootstrap = pd.read_csv(
        ROOT / "results" / "ticket4_selection_bootstrap.csv"
    )
    assert len(bootstrap) == protocol["selection_bootstrap_resamples"]
    assert set(bootstrap["selected_model"]) == set(expected_models)
    assert bootstrap["oob_rows"].gt(0).all()
    assert (
        bootstrap["selected_model"].eq(mechanism["proposed_model"]).mean()
        == pytest.approx(mechanism["proposed_model_selection_frequency"])
    )
    assert bootstrap["oob_f1_delta_vs_upstream"].median() == pytest.approx(
        mechanism["oob_delta_median"]
    )
    balanced_minus_unweighted = (
        bootstrap["oob_balanced_minus_unweighted_tuned_f1"]
    )
    assert balanced_minus_unweighted.median() == pytest.approx(
        mechanism["balanced_minus_unweighted_oob_median"]
    )
    assert (balanced_minus_unweighted > 0).mean() == pytest.approx(
        mechanism["balanced_minus_unweighted_oob_fraction_gt_zero"]
    )

    grouped = pd.read_csv(
        ROOT / "results" / "ticket4_grouped_selection_sensitivity.csv"
    )
    assert len(grouped) == protocol["grouped_sensitivity_resamples"]
    assert grouped["analysis_role"].eq(
        "post_decision_non_selecting_dev_only"
    ).all()
    assert grouped["sampling_unit"].eq(
        "url_canonical_strict_content_group"
    ).all()
    assert grouped["group_overlap_count"].eq(0).all()
    assert grouped["oob_groups"].gt(0).all()
    assert grouped["oob_rows"].gt(0).all()
    assert not any("heldout" in column for column in grouped.columns)
    assert grouped["selected_model"].eq(mechanism["proposed_model"]).mean() == (
        pytest.approx(mechanism["grouped_proposed_model_selection_frequency"])
    )
    assert grouped["oob_f1_delta_vs_upstream"].median() == pytest.approx(
        mechanism["grouped_oob_delta_median"]
    )

    pair_frequency = pd.read_csv(
        ROOT / "results" / "ticket4_pair_selection_frequency.csv"
    )
    assert len(pair_frequency) == len(expected_models) * len(expected_thresholds)
    assert pair_frequency["row_pair_selection_frequency"].sum() == pytest.approx(1)
    assert pair_frequency[
        "grouped_pair_selection_frequency"
    ].sum() == pytest.approx(1)
    proposed_pair = pair_frequency.loc[pair_frequency["full_dev_proposal"]]
    assert len(proposed_pair) == 1
    assert proposed_pair.iloc[0]["model_name"] == "logreg_unweighted_c1"
    assert proposed_pair.iloc[0]["threshold"] == pytest.approx(0.44)
    assert proposed_pair.iloc[0][
        "row_pair_selection_frequency"
    ] == pytest.approx(mechanism["proposed_pair_selection_frequency"])
    assert proposed_pair.iloc[0][
        "grouped_pair_selection_frequency"
    ] == pytest.approx(mechanism["grouped_proposed_pair_selection_frequency"])
    row_exact_count = int(
        (
            bootstrap["selected_model"].eq("logreg_unweighted_c1")
            & np.isclose(bootstrap["selected_threshold"], 0.44)
        ).sum()
    )
    grouped_exact_count = int(
        (
            grouped["selected_model"].eq("logreg_unweighted_c1")
            & np.isclose(grouped["selected_threshold"], 0.44)
        ).sum()
    )
    assert proposed_pair.iloc[0]["row_selected_replicates"] == row_exact_count
    assert proposed_pair.iloc[0][
        "grouped_selected_replicates"
    ] == grouped_exact_count
    default_pair = pair_frequency.loc[
        (pair_frequency["model_name"] == "logreg_unweighted_c1")
        & np.isclose(pair_frequency["threshold"], 0.50)
    ].iloc[0]
    assert proposed_pair.iloc[0][
        "grouped_pair_selection_frequency"
    ] > default_pair["grouped_pair_selection_frequency"]

    operating = pd.read_csv(
        ROOT / "results" / "ticket4_operating_points.csv"
    ).set_index("policy")
    assert set(operating.index) == {
        "upstream_default",
        "logreg_unweighted_c1_dev_optimum",
        "logreg_balanced_c1_dev_optimum",
    }
    selected = operating.loc["logreg_unweighted_c1_dev_optimum"]
    assert bool(selected["joint_dev_proposal"])
    assert bool(selected["selected_policy"])
    assert bool(selected["heldout_evaluated_after_freeze"])
    assert selected["heldout_f1_target_1"] == pytest.approx(
        mechanism["selected_heldout_f1"]
    )
    balanced = operating.loc["logreg_balanced_c1_dev_optimum"]
    assert not bool(balanced["joint_dev_proposal"])
    assert not bool(balanced["selected_policy"])
    assert not bool(balanced["heldout_evaluated_after_freeze"])
    assert pd.isna(balanced["heldout_f1_target_1"])

    selected_prediction = pd.read_csv(
        ROOT / "predictions" / "ticket_4_selected_heldout.csv"
    )
    recomputed = binary_metrics(
        selected_prediction["y_true"],
        selected_prediction["score"],
        threshold=mechanism["selected_threshold"],
    )
    assert selected_prediction["model_name"].nunique() == 1
    assert selected_prediction["model_name"].iloc[0] == (
        "logreg_unweighted_c1_threshold_0.44"
    )
    assert recomputed["f1_target_1"] == pytest.approx(
        mechanism["selected_heldout_f1"]
    )
    assert recomputed["fp"] == mechanism["selected_heldout_fp"]
    assert recomputed["fn"] == mechanism["selected_heldout_fn"]

    stale_artifacts = [
        "results/ticket4_cost_sensitivity.csv",
        "results/ticket4_grouped_oof_sensitivity.csv",
        "results/ticket4_invariance_audit.csv",
        "results/ticket4_model_audit.csv",
        "results/ticket4_oof_scores.csv",
        "results/ticket4_policy_metrics.csv",
        "results/ticket4_threshold_bootstrap.csv",
        "predictions/ticket_4_decision_rule_heldout.csv",
    ]
    assert all(not (ROOT / path).exists() for path in stale_artifacts)


def test_ticket5_audit_never_changes_heldout_and_rejects_unstable_relabeling() -> None:
    protocol = load_json("configs/ticket5_protocol.json")
    upstream = load_json("results/ticket5_upstream_audit.json")
    assert upstream["ticket4_manifest_model"] == (
        "logreg_unweighted_c1_threshold_0.44"
    )
    assert upstream["upstream_model"] == "logreg_unweighted_c1_threshold_0.44"
    assert upstream["family"] == "logistic_regression"
    assert upstream["class_weight"] is None
    assert upstream["threshold"] == pytest.approx(0.44)
    assert upstream["within_tolerance"]

    candidates = pd.read_csv(ROOT / "results" / "ticket5_correction_candidates.csv")
    assert len(candidates) > 0
    assert {
        "original_label",
        "proposed_label",
        "modification_reason",
        "used_in_selected_training",
    }.issubset(candidates.columns)
    assert (candidates["original_label"] != candidates["proposed_label"]).all()
    assert not candidates["used_in_selected_training"].astype(bool).any()

    audit = pd.read_csv(ROOT / "results" / "ticket5_audit_table.csv")
    required = {
        "original_label",
        "proposed_label",
        "evidence",
        "disposition",
        "audit_confidence",
        "confidence_basis",
        "used_in_selected_training",
    }
    assert required.issubset(audit.columns)
    assert set(audit["disposition"]).issubset(protocol["audit_dispositions"])
    assert (audit.loc[audit["disposition"] == "fix", "split"] == "train").all()
    assert audit.loc[audit["split"] != "train", "proposed_label"].isna().all()
    assert not audit["used_in_selected_training"].astype(bool).any()
    assert set(audit["audit_confidence"]) <= {"high", "moderate", "low"}
    canonical_audit = pd.read_csv(ROOT / "results" / "data_quality_audit.csv")
    assert canonical_audit.columns.tolist() == [
        "id",
        "issue_type",
        "evidence",
        "disposition",
        "confidence",
    ]
    expected_canonical_audit = audit.rename(
        columns={"audit_confidence": "confidence"}
    )[canonical_audit.columns]
    pd.testing.assert_frame_equal(
        canonical_audit,
        expected_canonical_audit,
        check_dtype=False,
    )
    for candidate in candidates.itertuples(index=False):
        group = audit.loc[
            (audit["group_id"] == candidate.group_id)
            & (audit["split"] == "train")
        ]
        candidate_row = group.loc[group["id"] == candidate.id]
        peers = group.loc[group["id"] != candidate.id]
        assert len(candidate_row) == 1
        assert candidate_row.iloc[0]["disposition"] == "fix"
        assert candidate_row.iloc[0]["audit_confidence"] == "high"
        assert len(peers) == candidate.unanimous_peer_count
        assert (peers["original_label"] == candidate.proposed_label).all()
        assert (
            peers["issue_type"] == "training_strict_duplicate_consensus_peer"
        ).all()
        assert (peers["disposition"] == "keep_but_flag").all()
        assert (peers["audit_confidence"] == "high").all()
        assert peers["proposed_label"].isna().all()

    oof = pd.read_csv(ROOT / "results" / "ticket5_oof_audit.csv")
    assert oof["oof_scheme"].nunique() == 1
    assert oof["oof_max_train_validation_group_overlap"].max() == 0
    assert {
        "logreg_label_disagreement_score",
        "complement_nb_label_disagreement_score",
    }.issubset(oof.columns)

    mechanism = load_json("results/ticket5_mechanism_summary.json")
    assert mechanism["decision"] == "reject"
    assert set(mechanism["failed_adoption_gates"]) == {
        gate for gate, passed in mechanism["adoption_gates"].items() if not passed
    }
    assert not any(mechanism["adoption_gates"].values())
    assert mechanism["dev_delta_f1"] < 0
    assert mechanism["jackknife_median_delta"] < 0
    assert mechanism["jackknife_probability_positive"] < 0.60
    assert mechanism["dev_ci_2_5"] < 0 < mechanism["dev_ci_97_5"]
    assert mechanism["heldout_ci_2_5"] < 0 < mechanism["heldout_ci_97_5"]
    assert mechanism["dev_strict_overlap_minus_novel_f1"] > 0.1
    assert mechanism["heldout_strict_overlap_minus_novel_f1"] > 0.1

    overlap = pd.read_csv(ROOT / "results" / "ticket5_overlap_statistics.csv")
    assert (overlap["ci_2_5"] > 0).all()
    assert (overlap["bootstrap_sampling_unit"] == "within_stratum_strict_duplicate_group").all()
    weighting = pd.read_csv(ROOT / "results" / "ticket5_duplicate_weighting.csv")
    assert (weighting["cluster_balanced_f1"] < weighting["row_level_f1"]).all()

    errors = pd.read_csv(ROOT / "results" / "ticket5_error_attribution.csv")
    assert set(errors["error_type"]) == {"false_positive", "false_negative"}
    assert errors["hard_error"].astype(bool).sum() < len(errors)
    assert (
        errors.loc[errors["error_type"] == "false_positive", "y_true"] == 0
    ).all()

    ticket4 = pd.read_csv(ROOT / "predictions" / "ticket_4_selected_heldout.csv")
    final = pd.read_csv(ROOT / "predictions" / "heldout_predictions.csv")
    merged = ticket4[["id", "score", "y_pred"]].merge(
        final[["id", "score", "y_pred"]],
        on="id",
        suffixes=("_ticket4", "_final"),
        validate="one_to_one",
    )
    assert np.max(np.abs(merged["score_ticket4"] - merged["score_final"])) < 1e-12
    assert (merged["y_pred_ticket4"] == merged["y_pred_final"]).all()
