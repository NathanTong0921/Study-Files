"""Shared data, modelling, and evaluation utilities.

All experiment scripts import this module so the fixed split and metric definitions
cannot silently diverge between tickets.
"""

from __future__ import annotations

import html
import json
import re
import unicodedata
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Iterable

import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score, precision_score, recall_score
from sklearn.pipeline import Pipeline


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = PROJECT_ROOT / "starter" / "data"
CONTRACT_PATH = PROJECT_ROOT / "starter" / "configs" / "project_contract.json"
RANDOM_STATE = 3102


@dataclass(frozen=True)
class ProjectData:
    full: pd.DataFrame
    train: pd.DataFrame
    dev: pd.DataFrame
    heldout: pd.DataFrame
    contract: dict


def load_project_data(data_dir: Path = DATA_DIR) -> ProjectData:
    """Load the public CSV and apply the assignment's id-based split with checks."""
    frame = pd.read_csv(data_dir / "train.csv")
    with (data_dir / "split_indices.json").open(encoding="utf-8") as handle:
        split_ids = json.load(handle)
    with CONTRACT_PATH.open(encoding="utf-8") as handle:
        contract = json.load(handle)

    expected_columns = {"id", "keyword", "location", "text", "target"}
    if not expected_columns.issubset(frame.columns):
        missing = sorted(expected_columns - set(frame.columns))
        raise ValueError(f"train.csv is missing required columns: {missing}")
    if frame["id"].duplicated().any():
        raise ValueError("The public dataset contains duplicate ids.")
    if not frame["target"].isin([0, 1]).all():
        raise ValueError("target must be binary (0 or 1).")

    names = ("train_ids", "dev_ids", "heldout_ids")
    id_sets = {name: set(map(int, split_ids[name])) for name in names}
    if any(id_sets[a] & id_sets[b] for a, b in ((names[0], names[1]), (names[0], names[2]), (names[1], names[2]))):
        raise ValueError("Fixed split id lists overlap.")
    all_split_ids = set().union(*id_sets.values())
    data_ids = set(frame["id"].astype(int))
    if all_split_ids != data_ids:
        raise ValueError("Fixed split ids do not exactly cover train.csv ids.")

    by_id = frame.set_index("id", drop=False)

    def select(name: str) -> pd.DataFrame:
        # Preserve the order supplied in the contract rather than CSV row order.
        return by_id.loc[list(map(int, split_ids[name]))].reset_index(drop=True).copy()

    parts = {name: select(name) for name in names}
    expected_sizes = {"train_ids": 4567, "dev_ids": 1523, "heldout_ids": 1523}
    actual_sizes = {name: len(part) for name, part in parts.items()}
    if actual_sizes != expected_sizes:
        raise ValueError(f"Unexpected fixed split sizes: {actual_sizes}")

    return ProjectData(
        full=frame.copy(),
        train=parts["train_ids"],
        dev=parts["dev_ids"],
        heldout=parts["heldout_ids"],
        contract=contract,
    )


def identity_text(text: str) -> str:
    return str(text)


_URL_RE = re.compile(r"(?:https?://|www\.)\S+", flags=re.IGNORECASE)
_MENTION_RE = re.compile(r"(?<!\w)@[A-Za-z0-9_]+")
_HASHTAG_RE = re.compile(r"(?<!\w)#([A-Za-z0-9_]+)")
_SPACE_RE = re.compile(r"\s+")


def strict_content_key(text: str) -> str:
    """Return the URL-canonical exact-content key shared by Tickets 4 and 5."""
    value = unicodedata.normalize("NFKC", html.unescape(str(text))).lower()
    value = _URL_RE.sub(" url ", value)
    return _SPACE_RE.sub(" ", value).strip()


def normalize_social_text(text: str) -> str:
    """Normalize volatile social-media markup while retaining hashtag words."""
    # A custom sklearn preprocessor replaces its built-in lowercasing, so case
    # folding is explicit here to keep casing constant relative to the baseline.
    value = str(text).lower()
    value = _URL_RE.sub(" url ", value)
    value = _MENTION_RE.sub(" user ", value)
    value = _HASHTAG_RE.sub(r" \1 ", value)
    return _SPACE_RE.sub(" ", value).strip()


def make_text_pipeline(
    *,
    preprocessor: Callable[[str], str] | None = None,
    lowercase: bool = True,
    ngram_range: tuple[int, int] = (1, 1),
    min_df: int | float = 1,
    max_df: int | float = 1.0,
    sublinear_tf: bool = False,
    c: float = 1.0,
    class_weight: str | dict | None = None,
    max_features: int | None = None,
    stop_words: str | list[str] | None = None,
    random_state: int = RANDOM_STATE,
) -> Pipeline:
    """Create the CPU-only word TF-IDF + logistic-regression model."""
    return Pipeline(
        [
            (
                "tfidf",
                TfidfVectorizer(
                    preprocessor=preprocessor,
                    lowercase=lowercase,
                    ngram_range=ngram_range,
                    min_df=min_df,
                    max_df=max_df,
                    sublinear_tf=sublinear_tf,
                    max_features=max_features,
                    stop_words=stop_words,
                ),
            ),
            (
                "classifier",
                LogisticRegression(
                    C=c,
                    class_weight=class_weight,
                    max_iter=1000,
                    random_state=random_state,
                ),
            ),
        ]
    )


def predict_scores(model: Pipeline, frame: pd.DataFrame) -> np.ndarray:
    return np.asarray(model.predict_proba(frame["text"].fillna(""))[:, 1], dtype=float)


def binary_metrics(y_true: Iterable[int], score: Iterable[float], threshold: float = 0.5) -> dict[str, float | int]:
    y_true_array = np.asarray(list(y_true), dtype=int)
    score_array = np.asarray(list(score), dtype=float)
    prediction = (score_array >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true_array, prediction, labels=[0, 1]).ravel()
    return {
        "precision_target_1": float(precision_score(y_true_array, prediction, zero_division=0)),
        "recall_target_1": float(recall_score(y_true_array, prediction, zero_division=0)),
        "f1_target_1": float(f1_score(y_true_array, prediction, zero_division=0)),
        "accuracy": float(accuracy_score(y_true_array, prediction)),
        "tn": int(tn),
        "fp": int(fp),
        "fn": int(fn),
        "tp": int(tp),
    }


def prediction_frame(
    frame: pd.DataFrame,
    score: np.ndarray,
    *,
    model_name: str,
    ticket: str,
    threshold: float = 0.5,
) -> pd.DataFrame:
    return pd.DataFrame(
        {
            "id": frame["id"].astype(int),
            "y_true": frame["target"].astype(int),
            "y_pred": (np.asarray(score) >= threshold).astype(int),
            "score": np.asarray(score, dtype=float),
            "model_name": model_name,
            "ticket": ticket,
        }
    )
