"""Reproducible text-classification pipeline for the project."""

