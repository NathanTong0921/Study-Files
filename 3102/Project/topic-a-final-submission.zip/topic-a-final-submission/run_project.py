"""Small command-line entry point for reproducible project regeneration."""

from __future__ import annotations

import argparse
import os
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent
PROJECT_ENV = os.environ.copy()
# Ignore user-site packages so child processes use only the active environment;
# the final reproducible environment is defined by requirements-lock.txt.
PROJECT_ENV["PYTHONNOUSERSITE"] = "1"


def run(relative_path: str, *arguments: str) -> None:
    subprocess.run(
        [sys.executable, str(ROOT / relative_path), *arguments],
        cwd=ROOT,
        env=PROJECT_ENV,
        check=True,
    )


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "command",
        choices=(
            "ticket1",
            "ticket2",
            "ticket3",
            "ticket4",
            "ticket5",
            "experiments",
            "test",
            "all",
        ),
        nargs="?",
        default="all",
    )
    args = parser.parse_args()
    if args.command == "ticket1":
        run("experiments/run_ticket1.py")
    if args.command == "ticket2":
        run("experiments/run_ticket1.py")
        run("experiments/run_ticket2.py")
    if args.command == "ticket3":
        # Ticket 3 asserts exact agreement with Ticket 2's frozen predictions.
        run("experiments/run_ticket1.py")
        run("experiments/run_ticket2.py")
        run("experiments/run_ticket3.py")
    if args.command == "ticket4":
        # Ticket 4 asserts exact agreement with the representation retained by
        # Tickets 2 and 3 before jointly selecting model and threshold on dev.
        run("experiments/run_ticket1.py")
        run("experiments/run_ticket2.py")
        run("experiments/run_ticket3.py")
        run("experiments/run_ticket4.py")
    if args.command == "ticket5":
        # Ticket 5 rebuilds every frozen upstream interface before proposing
        # any training-only label correction.
        run("experiments/run_ticket1.py")
        run("experiments/run_ticket2.py")
        run("experiments/run_ticket3.py")
        run("experiments/run_ticket4.py")
        run("experiments/run_ticket5.py")
    if args.command in ("experiments", "all"):
        # Rebuild the current staged causal chain from its first dependency.
        run("experiments/run_ticket1.py")
        run("experiments/run_ticket2.py")
        run("experiments/run_ticket3.py")
        run("experiments/run_ticket4.py")
        run("experiments/run_ticket5.py")
    if args.command in ("test", "all"):
        subprocess.run(
            [sys.executable, "-m", "pytest", "-q"],
            cwd=ROOT,
            env=PROJECT_ENV,
            check=True,
        )


if __name__ == "__main__":
    main()
