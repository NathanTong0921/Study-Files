# Ticket 1 — Controlled baseline gap attribution

## Answer in one sentence

The explicitly frozen `unweighted_controlled_baseline` does **not** match the reference contract (held-out F1 0.747253 versus 0.757422; absolute gap 0.010169 > tolerance 0.001): the supplied split and within-environment seed/fit-order variation are ruled out as local causes, the unpublished reference version remains unresolved, and the complete TF-IDF grid supports removing English stop-word filtering as the strongest tested explanation without claiming unique identification of the reference pipeline.

## Primary baseline and ticket boundary

| component | configuration |
| --- | --- |
| TF-IDF | raw text; lowercase=True; word unigrams; max_features=5000; stop_words=english; sublinear_tf=True; L2-normalized smoo… |
| Logistic Regression | C=1.0; class_weight=None; solver=lbfgs; max_iter=1000; random_state=3102 |
| Decision and data | threshold=0.5; supplied train/dev/held-out IDs |

This controlled model is the only Ticket 1 baseline and was fixed independently of closeness to the reference score. It remains the common Ticket 2 and Ticket 3 anchor regardless of every diagnostic result. Every Ticket 1 grid cell fixes Logistic Regression at `C=1.0`, `class_weight=None`, `max_iter=1000` and threshold 0.5. No class weighting, regularization or alternative classifier is studied here. URL, mention, hashtag and other social-text normalization choices remain in Ticket 2.

**Intended diagnostic lever:** TF-IDF representation; the split, seed/fit-order and version checks are Ticket 1 attribution probes, not competing downstream model levers.

`results/ticket1_resolved_baseline.json` records the estimator's resolved parameters under Python 3.9.6 and scikit-learn 1.6.1.

## Hypotheses and held-out discipline

- **H-split:** a wrong or reconstructed split could create the gap.
- **H-seed:** optimizer randomness or training-row order could create the gap.
- **H-version:** an unpublished reference software environment could differ.
- **H-preprocessing:** TF-IDF representation choices could move the contract score.

The eight preprocessing cells form the complete 2^3 design before comparison: feature cap on/off, English stop-word removal on/off and sublinear TF on/off. All models are fitted before the reference-distance table is interpreted. Held-out is used for the handout-required diagnosis of the frozen baseline's reference-contract gap, never to choose a downstream model.

## Split attribution

- Declared policy: `stratified 60/20/20 over Kaggle train.csv rows; IDs preserve Kaggle id column` with seed 3102.
- Pairwise ID overlap: 0; full source-ID coverage: True; source IDs unique: True.
- Every loaded split exactly matches the supplied ID order: True.
- Train/dev/held-out rows: 4567/1523/1523; positives: 1962/655/654.
- Data SHA-256: `61111c6dc31eaffa34d1e1fa62e2395325c9bc3b38bba1941a5f1ed9b3fa60df`; split SHA-256: `db2fd1fdcc24043dd40ed202efe2c6cc19183d75de2becb2bb8645e99d8988f1`.

This rules out split reconstruction, positional indexing, overlap, omission and order mismatch **in this implementation**. It relies on the assignment contract that the published score corresponds to the supplied split.

## Seed and fit-order attribution on the actual controlled baseline

| probe | random_state | fit_order | prediction_changes_vs_canonical | max_absolute_score_delta | heldout_f1_target_1 |
| --- | --- | --- | --- | --- | --- |
| canonical | 3102 | fixed | 0 | 0.000e+00 | 0.747253 |
| repeat_same_configuration | 3102 | fixed | 0 | 0.000e+00 | 0.747253 |
| seed_0 | 0 | fixed | 0 | 0.000e+00 | 0.747253 |
| seed_1 | 1 | fixed | 0 | 0.000e+00 | 0.747253 |
| seed_42 | 42 | fixed | 0 | 0.000e+00 | 0.747253 |
| seed_9999 | 9999 | fixed | 0 | 0.000e+00 | 0.747253 |
| reversed_fit_order | 3102 | reversed | 0 | 2.476e-14 | 0.747253 |
| shuffled_fit_order_99 | 3102 | shuffled_seed_99 | 0 | 1.554e-15 | 0.747253 |

Across 8 probes, the maximum hard-prediction change is 0, the maximum probability difference is 2.476e-14, and held-out F1 ranges from 0.747253 to 0.747253. Thus seed and row order cannot explain the controlled baseline's 0.010169 gap in the recorded environment. This conclusion is model- and environment-specific, not a general claim about all classifiers.

## Version attribution

The run records Python 3.9.6, NumPy 1.26.4, pandas 2.3.3, scikit-learn 1.6.1 and SciPy 1.13.1, plus resolved estimator settings. Repeated fits establish deterministic behavior **inside this environment**. The reference environment is unpublished, so a version-induced discrepancy cannot be tested causally or ruled out. Version is therefore **unresolved**, not silently assigned to preprocessing.

## Complete 2^3 TF-IDF preprocessing diagnostic

| model_name | feature_cap_5000 | english_stop_words | sublinear_tf | feature_count | dev_f1_target_1 | heldout_f1_target_1 | absolute_reference_gap | within_contract_tolerance |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| default_tfidf_sanity_check | 0 | 0 | 0 | 15269 | 0.738812 | 0.749186 | 0.008236 | False |
| sublinear_only | 0 | 0 | 1 | 15269 | 0.739236 | 0.751831 | 0.005591 | False |
| english_stop_words_only | 0 | 1 | 0 | 14998 | 0.730769 | 0.734558 | 0.022865 | False |
| stop_words_plus_sublinear | 0 | 1 | 1 | 14998 | 0.730609 | 0.742285 | 0.015137 | False |
| feature_cap_only | 1 | 0 | 0 | 5000 | 0.743333 | 0.756219 | 0.001203 | False |
| feature_cap_plus_sublinear | 1 | 0 | 1 | 5000 | 0.745847 | 0.758051 | 0.000629 | True |
| feature_cap_plus_stop_words | 1 | 1 | 0 | 5000 | 0.734177 | 0.747885 | 0.009537 | False |
| unweighted_controlled_baseline | 1 | 1 | 1 | 5000 | 0.731255 | 0.747253 | 0.010169 | False |

The grid's held-out F1 range is 0.023494. The closest nonbaseline cell is `feature_cap_plus_sublinear`, with absolute gap 0.000629; reference-compatible nonbaseline cells within tolerance: **feature_cap_plus_sublinear**. It differs from the controlled baseline only by `english_stop_words`. Removing that controlled setting changes dev F1 by +0.014592 and held-out F1 by +0.010798, so the direction is not held-out-only. These are diagnostic compatibility results, not model selection. The controlled model remains downstream even though this cell is numerically closer.

### Paired factor effects across all four opposing strata

| factor | paired_strata | mean_dev_f1_effect | mean_heldout_f1_effect | min_heldout_f1_effect | max_heldout_f1_effect | mean_absolute_gap_reduction | gap_improved_strata | gap_worsened_strata |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| english_stop_words | 4 | -0.010105 | -0.010827 | -0.014628 | -0.008334 | -0.010512 | 0 | 4 |
| feature_cap_5000 | 4 | +0.003797 | +0.007887 | +0.004968 | +0.013327 | +0.007573 | 4 | 0 |
| sublinear_tf | 4 | -0.000036 | +0.002893 | -0.000632 | +0.007728 | +0.002579 | 3 | 1 |

Positive `mean_absolute_gap_reduction` means turning the factor on moves F1 closer to the reference on average. The min/max effects show that a factor's direction can depend on the other preprocessing settings; therefore no single endpoint comparison is used as causal proof.

### Pairwise interactions

| factor_a | factor_b | conditioned_factor | conditioned_level | heldout_f1_difference_in_differences | gap_reduction_difference_in_differences |
| --- | --- | --- | --- | --- | --- |
| feature_cap_5000 | english_stop_words | sublinear_tf | 0 | +0.006294 | +0.006294 |
| feature_cap_5000 | english_stop_words | sublinear_tf | 1 | -0.001253 | +0.000005 |
| feature_cap_5000 | sublinear_tf | english_stop_words | 0 | -0.000813 | -0.002071 |
| feature_cap_5000 | sublinear_tf | english_stop_words | 1 | -0.008360 | -0.008360 |
| english_stop_words | sublinear_tf | feature_cap_5000 | 0 | +0.005083 | +0.005083 |
| english_stop_words | sublinear_tf | feature_cap_5000 | 1 | -0.002464 | -0.001206 |

The complete grid exposes interactions instead of bundling three TF-IDF choices into one opaque switch. These effects establish sensitivity of this implementation, not the hidden reference configuration.

## Prediction-level and paired uncertainty evidence

For the closest nonbaseline cell versus the controlled baseline, the observed held-out F1 difference is +0.010798, with paired bootstrap interval [-0.007162, +0.029467]. All seven comparisons and all changed IDs are retained; balanced examples from the closest cell include improvements and regressions:

| id | y_true | change_type | baseline_score | candidate_score | text |
| --- | --- | --- | --- | --- | --- |
| 6232 | 0 | fixed_fp | 0.5002 | 0.4812 | Remove the http://t.co/7IEiZ619h0 and Linkury Browser Hijacker http://t.co/tFeaNwhH2h http://t.co/SjicbhzFo4 |
| 5634 | 0 | fixed_fp | 0.5004 | 0.4478 | The Chinese are flooding NYC market like never before http://t.co/9z9HsmiaVD |
| 6400 | 1 | fixed_fn | 0.4989 | 0.5208 | Hurricane 30STM quem lembra |
| 6299 | 1 | fixed_fn | 0.4978 | 0.5231 | quoted here--&gt;CNN: Purported ISIS video threatens Croatian hostage http://t.co/swVuZxi6gT |
| 6979 | 0 | new_fp | 0.4616 | 0.5005 | Review: Dude Bro Party Massacre III http://t.co/f0WQlobOoy by Patrick BromleyThe title sa http://t.co/THpBDPdj35 |
| 5466 | 0 | new_fp | 0.3640 | 0.5010 | Vampiro going through the table of flames #UltimaLucha #LuchaUnderground @Elreynetwork http://t.co/Ox6OUw3Yut |
| 1796 | 1 | new_fn | 0.6011 | 0.4992 | shootings explosions hand grenades thrown at cars and houses &amp; vehicles and buildings set on fire. It all just ba… |
| 9404 | 1 | new_fn | 0.5013 | 0.4840 | RT @kotowsa: South SudanÛªs war on women: survivors say rape has become 'just a normal thing' https://t.co/MexwoHd3T… |

Matching or approaching one scalar F1 is not proof of internal reproduction. Prediction changes and uncertainty are reported precisely to prevent that inference.

## Final attribution

| candidate_cause | status | evidence |
| --- | --- | --- |
| split | ruled_out_as_a_local_implementation_discrepancy | overlap=0; coverage=True; declared order exact=True |
| seed / fit order | ruled_out_for_the_controlled_baseline_in_this_environment | max prediction changes=0; max score delta=2.476e-14 |
| version | unresolved_reference_environment_not_published | local environment recorded; reference environment unpublished |
| TF-IDF preprocessing | supported_as_the_primary_tested_explanation_but_reference_pipeline_not_uniquely_identified | grid F1 range=0.023494; closest nonbaseline gap=0.000629; changed factor=english_stop_words |

The strongest defensible conclusion is:

1. the controlled baseline genuinely misses the contract;
2. a local split implementation error is ruled out;
3. seed and fit order are ruled out for this controlled model in this environment;
4. reference-version influence remains unidentified because the reference environment is unavailable;
5. TF-IDF preprocessing is the strongest tested explanation: removing English stop-word filtering from the otherwise identical controlled pipeline moves both dev and held-out in the same direction and enters contract tolerance, while English stop-word filtering worsens the reference gap in all four factorial strata. However, its held-out paired interval crosses zero and the scalar contract cannot uniquely reveal the hidden reference pipeline.

## Decision and limitation

`unweighted_controlled_baseline` remains frozen for Tickets 2 and 3. No Ticket 1 diagnostic arm is adopted by reference-score proximity. The exhaustive grid is retrospective discrepancy analysis because the reference mismatch was already observed; it should not be described as prospective model selection. Ticket 1 does not test URL/mention/hashtag normalization and does not test model-side parameters.

## Artifacts

- `configs/ticket1_protocol.json`
- `results/ticket1_model_matrix.csv`
- `results/ticket1_preprocessing_factor_pairs.csv`
- `results/ticket1_preprocessing_factor_effects.csv`
- `results/ticket1_preprocessing_interactions.csv`
- `results/ticket1_reproducibility.csv`
- `results/ticket1_statistics.csv`
- `results/ticket1_prediction_changes.csv`
- `results/ticket1_split_audit.json`
- `results/ticket1_resolved_baseline.json`
- `results/ticket1_gap_attribution.json`
- `predictions/ticket_1_controlled_baseline_heldout.csv`
- `predictions/ticket_1_default_tfidf_probe_heldout.csv`
