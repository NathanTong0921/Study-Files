# Ticket 4 — Fair model and decision-rule selection

## Answer in one sentence

The fair dev model-by-threshold comparison **rejects balanced class weighting and adopts threshold tuning**: the joint proposal is `logreg_unweighted_c1` at 0.44, selected on full dev with F1 0.749614; its model wins 76.3% of row bootstraps, while the exact pair wins 46.0%, and its OOB F1 delta versus the frozen upstream has median +0.005808 with 69.0% above zero.

## Frozen question and controlled design

The ticket hypothesis is that balanced class weighting may improve the precision-recall operating point, but it is supported only if it wins a fair development model-by-threshold comparison; otherwise the unweighted model is retained and threshold tuning is adopted only when the development OOB evidence meets the stated stability gates.

Ticket 4 inherits Ticket 2's URL canonicalization and Ticket 3's no-shallow-feature decision. The intended policy-level lever is joint model-by-threshold operating-point selection: `class_weight` is the sole model-side change, and threshold is the decision-rule coordinate. Both model variants use the same word TF-IDF representation, `C=1`, training rows, and 0.20–0.80 threshold grid. **Dev chooses the model variant and threshold jointly**, ensuring equal operating-point opportunity.

Every selection bootstrap repeats the complete model-by-threshold search on in-bag dev rows and evaluates the selected pair out of bag against the frozen unweighted model at threshold 0.50. Adoption requires a positive full-dev delta, positive OOB median delta, at least 60% positive OOB deltas, and at least 60% selection frequency for the proposed model. After that decision is fixed, a separate strict-content grouped bootstrap checks duplicate sensitivity without entering any gate or changing the pair. Held-out is not scored until both dev analyses finish.

The upstream refit matches Ticket 2 probabilities within 1.11e-16 on dev and 1.11e-16 on held-out.

## Equal threshold opportunity on development

| policy | model_name | threshold | dev_precision_target_1 | dev_recall_target_1 | dev_f1_target_1 | heldout_precision_target_1 | heldout_recall_target_1 | heldout_f1_target_1 | selected_policy |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| upstream_default | logreg_unweighted_c1 | 0.5000 | 0.8187 | 0.6687 | 0.7361 | 0.8416 | 0.6743 | 0.7487 | False |
| logreg_unweighted_c1_dev_optimum | logreg_unweighted_c1 | 0.4400 | 0.7590 | 0.7405 | 0.7496 | 0.7814 | 0.7431 | 0.7618 | True |
| logreg_balanced_c1_dev_optimum | logreg_balanced_c1 | 0.4600 | 0.7153 | 0.7786 | 0.7456 |  |  |  | False |

The balanced model's own best dev threshold is 0.46 with F1 0.745614; the unweighted model reaches 0.749614 at 0.44. A fixed-0.50 comparison alone is not treated as model improvement: after equal threshold opportunity, unweighted is better on the declared dev estimand. In the nested bootstrap, each model also tunes its own threshold on the same in-bag rows before both are compared on the same OOB rows. Balanced minus unweighted tuned OOB F1 has median -0.005166, interval [-0.020746, +0.011206], and is positive in only 23.9% of replicates.

## Joint-selection stability

| model_name | selected_replicates | selection_frequency | threshold_2_5 | threshold_median | threshold_97_5 |
| --- | --- | --- | --- | --- | --- |
| logreg_unweighted_c1 | 1527 | 0.7635 | 0.3800 | 0.4400 | 0.5000 |
| logreg_balanced_c1 | 473 | 0.2365 | 0.4300 | 0.4600 | 0.5400 |

Across 2000 row bootstraps, the OOB delta distribution has central interval [-0.023872, +0.026965]. The interval crosses zero, so the result is not presented as a certain improvement in every resample. The adoption gates use the positive median and positive-resample fraction, while model-selection frequency directly tests whether the class-weight choice is stable. These OOB deltas evaluate an adaptive retuning procedure, not a fixed @0.44 policy. The exact `logreg_unweighted_c1@0.44` pair appears in 46.0% of all replicates and 60.2% of replicates selecting that model, while its conditional full-dev paired interval [-0.002889, +0.029838] crosses zero. Thus 0.44 is the frozen full-dev point choice and the selected model's median bootstrap threshold, not a uniquely stable cutoff.

### Non-selecting strict-content group sensitivity

The 2000 grouped replicates treat each URL-canonical strict-content key as one indivisible sampling unit, so no group can cross their in-bag/OOB boundary. Dev contains 1469 groups; 35 multirow groups cover 89 rows. The proposed model is selected in 75.6% of grouped replicates, the exact @0.44 pair in 43.4%, and the unweighted @0.50 pair in only 1.8%. Grouped OOB delta has median +0.005451, interval [-0.024782, +0.026844], and 67.0% positive replicates. This post-decision dev-only sensitivity did not influence selection. It also does not remove the 142 dev rows whose strict key occurs in train; Ticket 5 audits that cross-split repetition separately.

## Precision-recall trade-off and final held-out evidence

At the frozen selected policy, dev precision/recall/F1 are 0.758998/0.740458/0.749614. Relative to upstream at 0.50, the dev F1 delta is +0.013479 with conditional paired interval [-0.002889, +0.029838]. The selection-aware OOB evidence above, not this conditional interval, drives adoption.

After freeze, held-out precision/recall/F1 are 0.781350/0.743119/0.761755. The held-out F1 delta is +0.013029, interval [-0.002533, +0.028906]. It fixes 0 FP and 45 FN while creating 53 FP and 0 FN. Lowering the threshold raises recall and false positives; it is not a free accuracy gain.

| id | y_true | change_type | old_pred | new_pred | baseline_threshold | candidate_threshold | baseline_score | candidate_score | text |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 17 | 1 | fixed_fn | 0 | 1 | 0.5000 | 0.4400 | 0.4458 | 0.4458 | Haha South Tampa is getting flooded hah- WAIT A SECOND I LIVE IN SOUTH TAMPA WHAT AM I GONNA DO WHAT AM I GONNA DO FV… |
| 302 | 1 | fixed_fn | 0 | 1 | 0.5000 | 0.4400 | 0.4617 | 0.4617 | Annihilated Abs . ?? http://t.co/1xPw292tJe |
| 552 | 0 | new_fp | 0 | 1 | 0.5000 | 0.4400 | 0.4663 | 0.4663 | Add Familia to the arson squad. |
| 687 | 0 | new_fp | 0 | 1 | 0.5000 | 0.4400 | 0.4813 | 0.4813 | Heart disease prevention: What about secondhand smoke? http://t.co/YdgMGBrYL2 |

## Decision

**ADOPT the joint dev proposal; use the unweighted C=1 logistic model at threshold 0.44.** Balanced class weighting is rejected because it loses the equal-opportunity dev comparison. Threshold tuning is adopted because the full-dev and adaptive OOB gates pass; 0.44 is retained as the frozen full-dev operating point, not as a universal or uniquely stable cutoff. Ticket 5 must inherit this exact frozen pair.

## Limitations

The selected threshold is conditional on one development split and may drift with prevalence or calibration. Both row and grouped OOB bootstraps reuse the same finite dev set and do not simulate temporal or platform shift; the grouped sensitivity prevents within-dev duplicate splitting but does not remove train--dev content overlap. The paired dev interval is conditional on the chosen pair; the joint OOB procedures expose selection uncertainty without making 0.44 uniquely optimal. Final held-out evidence is reported only after the dev decision is frozen and cannot alter the selected model or threshold.

Artifacts: `configs/ticket4_protocol.json`, canonical `results/threshold_sweep.csv`, detailed `results/ticket4_threshold_sweep.csv`, `results/ticket4_operating_points.csv`, `results/ticket4_selection_bootstrap.csv`, `results/ticket4_grouped_selection_sensitivity.csv`, `results/ticket4_pair_selection_frequency.csv`, `results/ticket4_statistics.csv`, `results/ticket4_prediction_changes.csv`, `results/ticket4_upstream_audit.json`, `results/ticket4_mechanism_summary.json`, `predictions/ticket_4_selected_dev.csv`, and `predictions/ticket_4_selected_heldout.csv`.
