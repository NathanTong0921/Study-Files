# Ticket 3 — Feature and shortcut audit

## Answer in one sentence

The `keyword` field contains substantial but mixed signal—85.9% of dev rows repeat it in the tweet text, yet counterfactual permutation changes a median 413 candidate decisions. Adding it to the common unweighted controlled text anchor changes dev F1 from 0.731255 to 0.717657; because the paired interval required by the frozen decision rule [-0.033186, +0.006957] does not establish a positive gain, the feature decision is **REJECT** and keyword remains an audit signal.

## Frozen protocol and leakage control

The ticket hypothesis is that `keyword` can contain legitimate event semantics while also potentially encoding dataset construction, and that other shallow fields may predict labels without adding stable information beyond the same text anchor.

`configs/ticket3_protocol.json` fixes the controlled representation, unweighted classifier, individual model registry, threshold, seeds, intervention count, and decision rule. Only `text_plus_keyword` is eligible: it must beat `controlled_text` on dev **and** have a paired-bootstrap lower bound above zero. All other isolated and one-feature incremental probes are dev-only and therefore have blank held-out cells. After that decision is frozen, only baseline and candidate are scored on held-out; those scores cannot reverse the decision. Class weighting remains `None` throughout Ticket 3 and is deferred to Ticket 4.

The independently refitted main baseline matches Ticket 1's controlled prediction artifacts with maximum score differences 1.11e-16 on dev and 1.11e-16 on held-out. The separate URL-normalized sensitivity anchor matches Ticket 2 on dev within 1.11e-16.

## Component-separated dev audit

| model_name | feature_groups | role | dev_f1_target_1 | heldout_f1_target_1 | heldout_evaluated_after_freeze |
| --- | --- | --- | --- | --- | --- |
| controlled_text | text | Ticket 1 unweighted controlled common anchor | 0.731255 | 0.747253 | True |
| keyword_only | keyword | isolated keyword predictive signal | 0.659859 |  | False |
| text_plus_keyword | text+keyword | protocol-designated one-feature incremental candidate | 0.717657 | 0.749004 | True |
| char_len_only | char_len | isolated character-length signal | 0.434477 |  | False |
| text_plus_char_len | text+char_len | character-length increment beyond text | 0.724396 |  | False |
| word_len_only | word_len | isolated word-length signal | 0.000000 |  | False |
| text_plus_word_len | text+word_len | word-length increment beyond text | 0.727578 |  | False |
| url_presence_only | url_presence | isolated URL-presence signal | 0.585091 |  | False |
| text_plus_url_presence | text+url_presence | URL-presence increment beyond text | 0.726039 |  | False |
| mention_presence_only | mention_presence | isolated mention-presence signal | 0.000000 |  | False |
| text_plus_mention_presence | text+mention_presence | mention-presence increment beyond text | 0.736931 |  | False |
| hashtag_presence_only | hashtag_presence | isolated hashtag-presence signal | 0.000000 |  | False |
| text_plus_hashtag_presence | text+hashtag_presence | hashtag-presence increment beyond text | 0.731419 |  | False |
| exclamation_count_only | exclamation_count | isolated exclamation-count signal | 0.000000 |  | False |
| text_plus_exclamation_count | text+exclamation_count | exclamation-count increment beyond text | 0.729412 |  | False |
| question_count_only | question_count | isolated question-count signal | 0.000000 |  | False |
| text_plus_question_count | text+question_count | question-count increment beyond text | 0.734283 |  | False |
| uppercase_ratio_only | uppercase_ratio | isolated casing-style signal | 0.000000 |  | False |
| text_plus_uppercase_ratio | text+uppercase_ratio | casing-style increment beyond text | 0.727735 |  | False |
| keyword_presence_only | keyword_presence | isolated keyword-missingness artifact | 0.027027 |  | False |
| text_plus_keyword_presence | text+keyword_presence | keyword-missingness increment beyond text | 0.732037 |  | False |
| location_presence_only | location_presence | isolated location-missingness artifact | 0.000000 |  | False |
| text_plus_location_presence | text+location_presence | location-missingness increment beyond text | 0.730185 |  | False |
| exact_location_only | location | isolated high-cardinality location shortcut | 0.243728 |  | False |
| text_plus_exact_location | text+location | exact-location increment beyond text | 0.730479 |  | False |
| url_sensitivity_text | text | Ticket 2 URL-normalized dev sensitivity anchor | 0.736134 |  | False |
| url_sensitivity_text_plus_keyword | text+keyword | keyword increment under Ticket 2 URL normalization; sensitivity only | 0.715102 |  | False |

Keyword alone quantifies association, while `text_plus_keyword` tests incremental information beyond the tweet. Character length, word length, URL/mention/hashtag presence, punctuation counts, uppercase ratio, field missingness, and exact location each receive their own isolated and incremental row. No bundled result is used for causal attribution.

Every incremental exploratory control is compared with the same controlled baseline using paired dev resampling and a familywise interval:

| analysis | observed_delta | comparison_family_size | bonferroni_ci_lower | bonferroni_ci_upper | positive_bootstrap_fraction |
| --- | --- | --- | --- | --- | --- |
| text plus char len | -0.006859 | 11 | -0.029584 | +0.014018 | 0.184 |
| text plus word len | -0.003678 | 11 | -0.017795 | +0.011422 | 0.219 |
| text plus url presence | -0.005216 | 11 | -0.031141 | +0.017856 | 0.278 |
| text plus mention presence | +0.005676 | 11 | -0.005809 | +0.017291 | 0.921 |
| text plus hashtag presence | +0.000164 | 11 | -0.012673 | +0.012735 | 0.508 |
| text plus exclamation count | -0.001844 | 11 | -0.011460 | +0.007558 | 0.277 |
| text plus question count | +0.003028 | 11 | -0.005308 | +0.012281 | 0.845 |
| text plus uppercase ratio | -0.003520 | 11 | -0.012828 | +0.004687 | 0.115 |
| text plus keyword presence | +0.000782 | 11 | -0.005826 | +0.007103 | 0.631 |
| text plus location presence | -0.001070 | 11 | -0.006249 | +0.003111 | 0.234 |
| text plus exact location | -0.000777 | 11 | -0.018774 | +0.016874 | 0.455 |

These comparisons are not eligible to replace the confirmatory candidate. They distinguish how much a shallow feature predicts alone from how much, if anything, it adds after TF-IDF.

## Paired uncertainty and frozen held-out evidence

The dev F1 difference is -0.013599, with 5,000-resample paired 95% interval [-0.033186, +0.006957], positive-bootstrap fraction=0.094, and exact paired-correctness p=0.0261. This fails the protocol-specified adoption rule.

After freezing the decision, candidate held-out precision/recall/F1 are 0.782030/0.718654/0.749004, versus baseline 0.835539/0.675841/0.747253. The held-out F1 difference is +0.001751, paired interval [-0.016261, +0.020586], and exact p=0.1847; this is final held-out benchmark evidence and cannot reopen selection. Under Ticket 2 URL normalization, the development keyword increment is -0.021032 with interval [-0.040614, -0.001591], so representation sensitivity is reported without changing the main decision rule.

## Counterfactual reliance tests

| model_name | stress_test | replicates | dev_f1_median | dev_f1_2_5 | dev_f1_97_5 | prediction_changes_median |
| --- | --- | --- | --- | --- | --- | --- |
| controlled_text | identity | 1 | 0.731255 | 0.731255 | 0.731255 | 0.0 |
| controlled_text | keyword_masked | 1 | 0.731255 | 0.731255 | 0.731255 | 0.0 |
| controlled_text | keyword_counter_association | 1 | 0.731255 | 0.731255 | 0.731255 | 0.0 |
| controlled_text | location_masked_negative_control | 1 | 0.731255 | 0.731255 | 0.731255 | 0.0 |
| controlled_text | keyword_permuted | 200 | 0.731255 | 0.731255 | 0.731255 | 0.0 |
| text_plus_keyword | identity | 1 | 0.717657 | 0.717657 | 0.717657 | 0.0 |
| text_plus_keyword | keyword_masked | 1 | 0.693317 | 0.693317 | 0.693317 | 475.0 |
| text_plus_keyword | keyword_counter_association | 1 | 0.435161 | 0.435161 | 0.435161 | 690.0 |
| text_plus_keyword | location_masked_negative_control | 1 | 0.717657 | 0.717657 | 0.717657 | 0.0 |
| text_plus_keyword | keyword_permuted | 200 | 0.604575 | 0.581548 | 0.626046 | 413.0 |

Keyword masking and permutation leave the controlled text-only model exactly unchanged, an internal negative control. For `text_plus_keyword`, masking produces F1 0.693317; 200 seeded permutations preserve keyword prevalence and its marginal category distribution but break alignment with each tweet, yielding median F1 0.604575 and interval [0.581548, 0.626046]. These interventions establish model reliance, not real-world causal effects. The baseline's permutation median is 0.731255 with zero changed decisions.

## Is the signal task information, artifact, or mixed?

- **Keyword: mixed.** Coverage is 99.3%, no present dev keyword is unseen from train, and 85.9% of rows literally contain the decoded keyword in the tweet. For 188 sufficiently represented categories, train-versus-dev positive-rate Spearman correlation is 0.759. These support real event-type semantics. However, the field is supplied separately by the benchmark, strongly predictive by itself, redundant beyond text, and counterfactually influential, so it is also a benchmark-construction shortcut.
- **Exact location: artifact-prone.** Among non-missing locations, 57.8% of dev and 58.6% of held-out values are unseen in train. Exact strings behave like sparse identities rather than a portable geographic representation and are ineligible for adoption.
- **Surface form: mixed but weak.** Length, punctuation, casing, URL, mention, and hashtag counts come from the tweet itself, so they can reflect legitimate reporting style; they are also sensitive to platform and formatting changes. Their isolated and incremental rows quantify signal without treating it as stable semantics.
- **Missingness: collection-process evidence.** Keyword/location presence can describe how records were assembled. It is audited separately and not interpreted as disaster content.

Top train-supported keyword coefficients illustrate semantic association while the train/dev rates prevent a coefficient-only story:

| keyword | train_count | train_positive_rate | dev_positive_rate | train_text_overlap_rate | text_plus_keyword_coefficient |
| --- | --- | --- | --- | --- | --- |
| derailment | 27 | 1.0000 | 1.0000 | 0.9259 | 1.9964 |
| oil spill | 20 | 1.0000 | 0.9091 | 1.0000 | 1.7813 |
| rescuers | 21 | 1.0000 | 0.6000 | 1.0000 | 1.7485 |
| outbreak | 22 | 0.9545 | 1.0000 | 1.0000 | 1.6377 |
| typhoon | 23 | 0.9565 | 1.0000 | 1.0000 | 1.6109 |
| aftershock | 23 | 0.0000 | 0.0000 | 0.4783 | -1.6624 |
| body bags | 23 | 0.0000 | 0.0000 | 0.5217 | -1.6404 |
| blazing | 18 | 0.0000 | 0.0000 | 0.8333 | -1.4818 |
| bloody | 19 | 0.0000 | 0.0000 | 0.9474 | -1.4553 |
| wrecked | 26 | 0.0385 | 0.1429 | 1.0000 | -1.4089 |

## Redundancy subgroup check

| model_name | subgroup | rows | f1_target_1 |
| --- | --- | --- | --- |
| controlled_text | keyword_in_text | 1309 | 0.728898 |
| controlled_text | keyword_not_in_text | 214 | 0.744444 |
| text_plus_keyword | keyword_in_text | 1309 | 0.714697 |
| text_plus_keyword | keyword_not_in_text | 214 | 0.734043 |

The lexical-overlap split is a protocol-specified, non-selecting subgroup diagnostic. It distinguishes rows where keyword repeats visible text from the minority where it contributes metadata not literally present. Subgroup differences remain descriptive because the groups are not randomized and some are much smaller.

## All held-out prediction movements

Relative to the frozen text baseline, the rejected candidate fixes 13 false positives and 43 false negatives while creating 57 false positives and 15 false negatives. 22.7% of changed predictions occur where the keyword is not literally in text, compared with 13.8% of all held-out rows; this enrichment is consistent with incremental metadata reliance.

| id | y_true | change_type | keyword | keyword_in_text | baseline_score | candidate_score | text |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 4262 | 0 | fixed_fp | drowning | False | 0.5012 | 0.4637 | #ICYMI #Annoucement from Al Jackson... http://t.co/7BevuJE5eP |
| 6085 | 0 | fixed_fp | hellfire | False | 0.5616 | 0.2603 | Orchid - Sign Of The Witch http://t.co/YtkXwPyIHg |
| 7260 | 1 | fixed_fn | nuclear disaster | False | 0.4898 | 0.7313 | #Obama signed up to a deal that far from making the world a safer place http://t.co/E0luGBL6pb via @upi #Iran #Nuclea… |
| 5789 | 1 | fixed_fn | hail | False | 0.4649 | 0.5426 | GREAT MICHIGAN TECHNIQUE CAMP B1G THANKS TO @bmurph1019 @hail_Youtsey . @termn8r13 #GoBlue #WrestleOn http://t.co/Oas… |
| 687 | 0 | new_fp | attack | False | 0.4964 | 0.7169 | Heart disease prevention: What about secondhand smoke? http://t.co/YdgMGBrYL2 |
| 6410 | 0 | new_fp | hurricane | False | 0.3563 | 0.5085 | @Freegeezy17 you stay in Houston? |
| 77 | 1 | new_fn | ablaze | False | 0.5666 | 0.4840 | Police: Arsonist Deliberately Set Black Church In North CarolinaåÊAblaze http://t.co/pcXarbH9An |
| 5345 | 1 | new_fn | fire | True | 0.5020 | 0.4131 | California been shaking...catching on fire....and overcharging ppl on rent for the past 150+ years it ain't going now… |

Examples are balanced by movement type where available and keyed by stable IDs. They illustrate mechanisms; the complete CSV, not these examples, supports the aggregate counts.

## Decision

**REJECT `text_plus_keyword` on the controlled main audit.** Keyword remains useful for auditing dataset construction and error slices. The downstream Ticket 4 pipeline combines Ticket 2's frozen URL normalization with only the features accepted here; when keyword is rejected, that means URL-normalized text without shallow additions.

## Limitations

Permutation and rank-reversal are artificial interventions and do not identify the performance of a particular deployment population. Lexical overlap is a conservative exact-phrase measure and misses paraphrases. Label-rate correlations do not prove causality. Location could become legitimate with a separately designed geographic normalization, but exact user strings cannot support that claim here. Results remain conditional on one fixed benchmark split.

Artifacts: `configs/ticket3_protocol.json`, `results/ticket3_ablation.csv`, `results/ticket3_feature_audit.csv`, `results/ticket3_statistics.csv`, `results/ticket3_stress_summary.csv`, `results/ticket3_stress_replicates.csv`, `results/ticket3_shift_audit.csv`, `results/ticket3_keyword_audit.csv`, `results/ticket3_subgroup_metrics.csv`, `results/ticket3_prediction_changes.csv`, `results/ticket3_mechanism_summary.json`, and `predictions/ticket_3_selected_heldout.csv`.
