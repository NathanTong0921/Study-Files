# Ticket 5 — Data-quality and error audit

## Answer in one sentence

The frozen training-only duplicate rule identifies 9 label-consistency fixes, but their corrected model is **REJECTED**: although dev F1 changes by -0.001166 and 11.1% of group-jackknife deltas are positive, the strict-group bootstrap interval [-0.006099, +0.003632] crosses zero; the final through-Ticket-5 model therefore remains `logreg_unweighted_c1` at threshold 0.44.

## Frozen protocol and intended lever

**Hypothesis.** A small number of training labels are internally inconsistent with conservative duplicate evidence, but correcting them should enter the predictive pipeline only if the change improves development F1 with paired uncertainty and group-level stability. Model disagreement alone is insufficient evidence of a mislabel.

The intended lever is **training-label correction supported by URL-canonical strict duplicate consensus**. A training row is eligible only when at least three other training rows share its strict key, every peer has the same label, and that unanimous label opposes the row. Dev and held-out labels never enter a proposal. The relaxed key masks mentions and punctuation and is audit-only. A five-fold strict-group-isolated OOF logistic/CNB consensus flag is also audit-only: without duplicate corroboration it is assigned `reject_false_positive`, not `fix`.

Adoption requires all four dev conditions: positive point F1 delta, a positive strict-group-bootstrap lower bound, a positive leave-one-correction-group-out median, and at least 60% positive group-jackknife deltas. The upstream refit matches Ticket 4 probabilities within 1.11e-16 on dev and 1.11e-16 on held-out.

## Duplicate structure and correction evidence

The strict audit finds 292 duplicate groups covering 932 row memberships; 64 groups have conflicting labels and 194 cross split boundaries. The relaxed audit finds 323 groups covering 1037 memberships, including 77 conflicts. The larger relaxed counts are evidence about sensitivity, not permission to broaden the correction rule.

| id | original_label | proposed_label | unanimous_peer_count | logreg_oof_score | complement_nb_oof_score | text |
| --- | --- | --- | --- | --- | --- | --- |
| 360 | 1 | 0 | 4 | 0.5478 | 0.6490 | U.S National Park Services Tonto National Forest: Stop the Annihilation of the Salt River Wild Hors… |
| 4076 | 0 | 1 | 3 | 0.5979 | 0.6229 | .POTUS #StrategicPatience is a strategy for #Genocide; refugees; IDP Internally displaced people; h… |
| 5564 | 1 | 0 | 3 | 0.3178 | 0.2439 | Spot Flood Combo 53inch 300W Curved Cree LED Work Light Bar 4X4 Offroad Fog Lamp - Full reÛ_ http:… |
| 6097 | 1 | 0 | 3 | 0.3064 | 0.3269 | The Prophet (peace be upon him) said 'Save yourself from Hellfire even if it is by giving half a da… |
| 7415 | 1 | 0 | 3 | 0.4030 | 0.4713 | Drunk Meals 101: What To Cook When You're Totally Obliterated http://t.co/m19iVWrdkk |
| 7860 | 1 | 0 | 4 | 0.2155 | 0.0898 | Reddit's new content policy goes into effect many horrible subreddits banned or quarantined http://… |
| 7862 | 1 | 0 | 3 | 0.1891 | 0.0897 | #hot Reddit's new content policy goes into effect many horrible subreddits banned or quarantined ht… |
| 9445 | 0 | 1 | 4 | 0.5761 | 0.7026 | Truth... https://t.co/h6amECX5K7 #News #BBC #CNN #Islam #Truth #god #ISIS #terrorism #Quran #Lies h… |
| 9783 | 1 | 0 | 4 | 0.4257 | 0.4939 | Hollywood Movie About Trapped Miners Released in Chile http://t.co/qkrLtrd39B |

Every proposed label is preserved beside its original label. OOF scores are secondary evidence only; they do not define the fix. Their grouped folds have maximum strict-group train/validation overlap 0.

## Controlled correction and stability

| model_name | operation | correction_rows | dev_f1_target_1 | dev_delta_f1_vs_upstream | heldout_f1_target_1 | heldout_evaluated_after_freeze |
| --- | --- | --- | --- | --- | --- | --- |
| original_upstream | none | 0 | 0.7496 | 0.0000 | 0.7618 | True |
| strict_min3_unanimous_peer_relabel | relabel | 9 | 0.7484 | -0.0012 | 0.7606 | True |
| strict_min2_unanimous_peer_relabel | relabel | 14 | 0.7465 | -0.0031 |  | False |
| strict_min4_unanimous_peer_relabel | relabel | 4 | 0.7457 | -0.0039 |  | False |
| relaxed_min3_unanimous_peer_relabel | relabel | 9 | 0.7484 | -0.0012 |  | False |
| strict_min3_unanimous_peer_drop | drop | 9 | 0.7488 | -0.0008 |  | False |

The primary corrected model changes dev F1 by -0.001166; the strict-group bootstrap interval is [-0.006099, +0.003632], with 31.8% of resamples above zero. A row-bootstrap sensitivity is retained in the statistics artifact but does not drive adoption. Across 9 leave-one-correction-group-out fits, median delta is -0.001166 and 11.1% are positive. Thus a plausible data-consistency repair is not automatically a supported predictive improvement.

| omitted_correction_ids | omitted_label_change | dev_delta_f1_vs_upstream | prediction_changes_vs_upstream | omitted_text |
| --- | --- | --- | --- | --- |
| 4076 | 0->1 | -0.0027 | 12 | .POTUS #StrategicPatience is a strategy for #Genocide; refugees; IDP Internally displaced people; h… |
| 5564 | 1->0 | -0.0023 | 12 | Spot Flood Combo 53inch 300W Curved Cree LED Work Light Bar 4X4 Offroad Fog Lamp - Full reÛ_ http:… |
| 9783 | 1->0 | -0.0012 | 12 | Hollywood Movie About Trapped Miners Released in Chile http://t.co/qkrLtrd39B |
| 6097 | 1->0 | -0.0012 | 8 | The Prophet (peace be upon him) said 'Save yourself from Hellfire even if it is by giving half a da… |
| 7415 | 1->0 | -0.0012 | 12 | Drunk Meals 101: What To Cook When You're Totally Obliterated http://t.co/m19iVWrdkk |
| 9445 | 0->1 | -0.0012 | 10 | Truth... https://t.co/h6amECX5K7 #News #BBC #CNN #Islam #Truth #god #ISIS #terrorism #Quran #Lies h… |
| 360 | 1->0 | -0.0012 | 10 | U.S National Park Services Tonto National Forest: Stop the Annihilation of the Salt River Wild Hors… |
| 7860 | 1->0 | -0.0006 | 9 | Reddit's new content policy goes into effect many horrible subreddits banned or quarantined http://… |
| 7862 | 1->0 | 0.0004 | 8 | #hot Reddit's new content policy goes into effect many horrible subreddits banned or quarantined ht… |

The leave-one-group table reveals whether the apparent gain is distributed or driven by particular correction groups; both negative and positive deltas are retained rather than summarized away.

After rejection was frozen, the candidate held-out delta is -0.001126, interval [-0.005977, +0.003428]. It fixes 3 FP and 1 FN while creating 0 FP and 4 FN. This post-freeze result cannot reverse the dev decision.

## Cross-split repetition and score limitation

| split | stratum | rows | precision_target_1 | recall_target_1 | f1_target_1 |
| --- | --- | --- | --- | --- | --- |
| dev | all | 1523 | 0.7590 | 0.7405 | 0.7496 |
| dev | strict_train_overlap | 142 | 0.8681 | 0.9186 | 0.8927 |
| dev | relaxed_only_train_overlap | 18 | 0.3333 | 0.6000 | 0.4286 |
| dev | novel_to_train | 1363 | 0.7477 | 0.7145 | 0.7307 |
| heldout | all | 1523 | 0.7814 | 0.7431 | 0.7618 |
| heldout | strict_train_overlap | 148 | 0.9368 | 0.8558 | 0.8945 |
| heldout | relaxed_only_train_overlap | 16 | 1.0000 | 0.6667 | 0.8000 |
| heldout | novel_to_train | 1359 | 0.7505 | 0.7227 | 0.7363 |

| split | observed_f1_difference | ci_2_5 | ci_97_5 | resampling_fraction_difference_gt_zero |
| --- | --- | --- | --- | --- |
| dev | 0.1619 | 0.0899 | 0.2210 | 1.0000 |
| heldout | 0.1581 | 0.0926 | 0.2123 | 1.0000 |

| split | key_type | unique_content_groups | row_level_f1 | cluster_balanced_f1 |
| --- | --- | --- | --- | --- |
| dev | strict | 1469 | 0.7496 | 0.7390 |
| dev | relaxed | 1462 | 0.7496 | 0.7407 |
| heldout | strict | 1477 | 0.7618 | 0.7505 |
| heldout | relaxed | 1470 | 0.7618 | 0.7503 |

The overlap table keeps every fixed-split row and reports performance by content provenance. Cluster-balanced F1 gives each within-split duplicate key total weight one; it is a sensitivity estimand, not a replacement score and does not delete held-out examples. The overlap gap is descriptive rather than causal because the strata also differ in class mix and difficulty.

## Ambiguity, hard negatives, and model-only findings

Disposition counts are: fix=9, keep-but-flag=851, ambiguous=177, and rejected model-only findings=39. Here, `fix` is an audit/human-review disposition, not automatic model adoption; the separate `used_in_selected_training` field records the dev-gated pipeline decision. Within each eligible correction group, the minority candidate is `fix/high`, while its unanimous supporting training peers are `keep_but_flag/high`; they are evidence for the correction candidate, not ambiguous rows. Other conflicting duplicate labels remain policy/data ambiguity unless the training-only strict rule supplies consensus evidence. Consistent duplicates are kept but flagged because repetition changes evaluation weighting.

| id | split | original_label | proposed_label | used_in_selected_training | disposition | audit_confidence | confidence_basis | issue_type | evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 353 | dev | 0 |  | False | ambiguous | low | conflicting duplicate labels without eligible training-only consensus | conflicting_strict_duplicate | strict group labels are 0:1, 1:1; training labels are 0:0, 1:0. No dev or held-out label is propose… |
| 355 | heldout | 0 |  | False | ambiguous | low | conflicting duplicate labels without eligible training-only consensus | conflicting_strict_duplicate | strict group labels are 0:5, 1:3; training labels are 0:4, 1:1. No dev or held-out label is propose… |
| 360 | train | 1 | 0.0000 | False | fix | high | training-only strict key with at least three unanimous opposing peers | training_strict_duplicate_consensus_minority | Training-only strict group has 4 other unanimous peers with label 0; row label is 1. |
| 4076 | train | 0 | 1.0000 | False | fix | high | training-only strict key with at least three unanimous opposing peers | training_strict_duplicate_consensus_minority | Training-only strict group has 3 other unanimous peers with label 1; row label is 0. |
| 59 | heldout | 0 |  | False | keep_but_flag | moderate | repeated content has consistent labels but alters evaluation weighting | consistent_strict_duplicate | strict duplicate group has 2 rows with consistent label 0; retain but flag repeated-content weighti… |
| 68 | train | 0 |  | False | keep_but_flag | moderate | repeated content has consistent labels but alters evaluation weighting | consistent_strict_duplicate | strict duplicate group has 2 rows with consistent label 0; retain but flag repeated-content weighti… |
| 1085 | train | 1 |  | False | reject_false_positive | low | model disagreement only; no duplicate or human-label evidence | model_only_oof_consensus_disagreement | Two strict-group-isolated OOF models oppose label 1 with disagreement scores 0.817 and 0.857, but n… |
| 1122 | train | 1 |  | False | reject_false_positive | low | model disagreement only; no duplicate or human-label evidence | model_only_oof_consensus_disagreement | Two strict-group-isolated OOF models oppose label 1 with disagreement scores 0.841 and 0.831, but n… |

`error_type` records only `false_positive` or `false_negative`; the independent Boolean `hard_error` records whether the score is at least 0.25 beyond the decision boundary. Hard negatives—target-0 false positives satisfying this margin—number 14 on dev and 12 on held-out (26 total); hard false negatives number 15 and 27, respectively (42 total). Feature contributions come from the frozen linear model and explain model behavior, not label correctness.

| id | split | y_true | score | error_type | hard_error | duplicate_stratum | top_positive_contributors | top_negative_contributors | text |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 6879 | dev | 0 | 0.8030 | false_positive | True | novel_to_train | mass:0.617; murder:0.560; stops:0.438 |  | http://t.co/FhI4qBpwFH @FredOlsenCruise Please take the #FaroeIslands off your itinerary until the … |
| 5247 | dev | 0 | 0.7812 | false_positive | True | novel_to_train | train:0.778; police:0.582; url:0.239 | fatality:-0.149 | Kosciusko police investigating pedestrian fatality hit by a train Thursday http://t.co/m5djLLxoZP |
| 9738 | dev | 1 | 0.1048 | false_negative | True | novel_to_train | tragedy:0.055 | ass:-0.517; lol:-0.402; beautiful:-0.377 | @itss_selenaluna like a beautiful ass tragedy lol |
| 7722 | dev | 1 | 0.1073 | false_negative | True | novel_to_train |  | panicking:-0.552; want:-0.449; tired:-0.251 | all that panicking made me tired ;__; i want to sleep in my bed |
| 7754 | heldout | 0 | 0.8597 | false_positive | True | novel_to_train | police:0.749; charged:0.534; url:0.521 |  | Maid charged with stealing Dh30000 from police officer sponsor http://t.co/y35qtVDSOH \| https://t.… |
| 9106 | heldout | 0 | 0.8484 | false_positive | True | novel_to_train | suicide:1.717; bomb:0.667 |  | she's a suicide bomb |
| 3607 | heldout | 1 | 0.0862 | false_negative | True | novel_to_train | returned:0.136; tomorrow:0.081 | song:-0.500; new:-0.466; wait:-0.283 | Just came back from camping and returned with a new song which gets recorded tomorrow. Can't wait! … |
| 1409 | heldout | 1 | 0.0906 | false_negative | True | strict_train_overlap | url:0.301 | new:-0.373; body:-0.271; bag:-0.251 | ?? New Ladies Shoulder Tote #Handbag Faux Leather Hobo Purse Cross Body Bag #Womens http://t.co/zuj… |

| split | error_type | direction | feature | rows | mean_contribution |
| --- | --- | --- | --- | --- | --- |
| dev | false_negative | negative | like | 12 | -0.2029 |
| dev | false_negative | negative | just | 11 | -0.2405 |
| dev | false_negative | positive | url | 55 | 0.2918 |
| dev | false_negative | positive | amp | 6 | 0.0529 |
| dev | false_positive | negative | like | 8 | -0.1863 |
| dev | false_positive | negative | life | 4 | -0.0879 |
| dev | false_positive | positive | url | 89 | 0.3579 |
| dev | false_positive | positive | attack | 6 | 0.3046 |
| heldout | false_negative | negative | going | 9 | -0.2698 |
| heldout | false_negative | negative | new | 9 | -0.5018 |
| heldout | false_negative | positive | url | 57 | 0.2855 |
| heldout | false_negative | positive | amp | 4 | 0.0436 |
| heldout | false_positive | negative | just | 4 | -0.2985 |
| heldout | false_positive | negative | look | 4 | -0.1597 |
| heldout | false_positive | positive | url | 76 | 0.3575 |
| heldout | false_positive | positive | police | 7 | 0.6132 |

The complete error and feature tables retain every error. Frequent contributors can identify lexical mechanisms, but no token is treated as proof that a label is wrong.

## Decision

**REJECT the training-label correction candidate; retain `logreg_unweighted_c1` at threshold 0.44.** Final dev F1 is 0.749614; held-out precision/recall/F1 are 0.781350/0.743119/0.761755. The 9 rows remain explicit human-review and dataset-consistency candidates; `used_in_selected_training` records whether they entered the frozen training labels. No held-out label was modified and no held-out row was removed.

## Limitations

Duplicate agreement establishes internal consistency, not ground-truth semantics; copied messages can still be assigned different labels under an unstated annotation policy. Relaxed matching can merge distinct messages. OOF consensus remains correlated model evidence, and linear token contributions omit pragmatic context, sarcasm, images, and linked-page content. The fixed split cannot establish how duplication or ambiguity behaves in future data, so production repair requires human reannotation under an explicit rubric.

Artifacts: `configs/ticket5_protocol.json`, `results/ticket5_correction_candidates.csv`, `results/ticket5_correction_ablation.csv`, `results/ticket5_statistics.csv`, `results/ticket5_group_jackknife.csv`, `results/ticket5_duplicate_groups.csv`, canonical `results/data_quality_audit.csv`, detailed `results/ticket5_audit_table.csv`, `results/ticket5_oof_audit.csv`, `results/ticket5_overlap_metrics.csv`, `results/ticket5_overlap_statistics.csv`, `results/ticket5_duplicate_weighting.csv`, `results/ticket5_error_attribution.csv`, `results/ticket5_error_slices.csv`, `results/ticket5_error_feature_summary.csv`, `results/ticket5_prediction_changes.csv`, and `predictions/ticket_5_data_quality_heldout.csv`.
