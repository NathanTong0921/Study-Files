# Ticket 2 — Multi-factor text normalization audit

## Answer in one sentence

On the explicit unweighted controlled baseline, URL canonicalization is adopted (0.731255 to 0.736134) because it removes severe, treatment-localized URL-identity sensitivity; mention canonicalization has the largest exploratory point estimate (0.739057) but its interval crosses zero and most boundary changes occur outside mention rows, while hashtag decomposition is effectively neutral (0.732657).

## Scope chosen from data, not from a checklist

| factor | affected_rows | rows | prevalence |
| --- | --- | --- | --- |
| url | 767 | 1523 | 50.4% |
| mention | 399 | 1523 | 26.2% |
| hashtag_any | 330 | 1523 | 21.7% |
| hashtag_decomposable | 96 | 1523 | 6.3% |
| emoji | 0 | 1523 | 0.0% |

Mention and hashtag were selected for deeper study because they occur in 26.2% and 21.7% of development rows and have falsifiable mechanisms. Case is already folded by the baseline vectorizer, punctuation is largely discarded by its word tokenizer, and only 0 development rows meet the recorded emoji detector, so those factors are not promoted to fitted strategies.

## Hypotheses

- **H-URL:** Canonicalizing volatile URL strings to one token should preserve link presence while making predictions invariant to arbitrary URL spelling.
- **H-mention:** Account identity is volatile. Canonicalization preserves mention presence, whereas removal treats both identity and presence as nuisance; compare both rather than assuming URL-style presence preservation is optimal.
- **H-hashtag:** Hashtag words can contain event semantics. Compare destructive generic replacement with conservative underscore/CamelCase decomposition; prefer a strategy that exposes components without discarding content.

## Provenance and leakage control

The frozen Ticket 2 normalization protocol anchors every comparison to Ticket 1's explicit unweighted controlled baseline. Its URL adoption rule is fixed before held-out scoring. Mention and hashtag strategies are fitted on train and evaluated on development only; their held-out cells are deliberately blank. All six representations share 5,000-feature English-stop-word sublinear TF--IDF, unweighted C=1 logistic regression, threshold 0.5, the fixed split, and 5,000 paired resamples. Each normalization arm independently refits its training vocabulary and IDF. Performance intervals use a Bonferroni family size of five, covering every fitted non-baseline strategy rather than only favorable results.

## Factor-specific development strategy ablation

| model_name | role | dev_precision_target_1 | dev_recall_target_1 | dev_f1_target_1 | heldout_f1_target_1 |
| --- | --- | --- | --- | --- | --- |
| unweighted_controlled_baseline | frozen explicit Ticket 1 unweighted controlled baseline | 0.815789 | 0.662595 | 0.731255 | 0.747253 |
| url_only_normalization | confirmatory URL-normalization candidate | 0.818692 | 0.668702 | 0.736134 | 0.748727 |
| mention_canonicalization | mention-family strategy preserving mention presence | 0.823640 | 0.670229 | 0.739057 |  |
| mention_removal | mention-family strategy removing identity and presence | 0.818182 | 0.659542 | 0.730347 |  |
| hashtag_generic_token | hashtag-family destructive content-loss control | 0.812734 | 0.662595 | 0.730025 |  |
| hashtag_decomposition | hashtag-family conservative semantic strategy | 0.821632 | 0.661069 | 0.732657 |  |

| factor | strategy | model_name | selected_within_factor | observed_delta | ci_2_5 | ci_97_5 | bonferroni_ci_lower | bonferroni_ci_upper |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| url | generic token | url_only_normalization | True | +0.004879 | -0.004540 | +0.014364 | -0.007534 | +0.018115 |
| mention | canonicalize to user | mention_canonicalization | True | +0.007802 | -0.000634 | +0.016827 | -0.003534 | +0.019630 |
| mention | remove handle | mention_removal | False | -0.000909 | -0.007758 | +0.005301 | -0.009735 | +0.007190 |
| hashtag | replace full hashtag by generic token | hashtag_generic_token | False | -0.001230 | -0.010373 | +0.008125 | -0.012787 | +0.010894 |
| hashtag | conservative underscore and CamelCase decomposition | hashtag_decomposition | True | +0.001401 | -0.006437 | +0.009442 | -0.009168 | +0.011915 |

Mention canonicalization moves dev F1 by +0.007802; removal moves it by -0.000909. The canonicalization point estimate is promising, but its ordinary 95% interval [-0.000634, +0.016827] and Bonferroni interval [-0.003534, +0.019630] cross zero. It is protocol-designated as a development-only mechanism audit, so it cannot be promoted after inspection. Generic hashtag replacement moves F1 by -0.001230, whereas conservative decomposition moves it by +0.001401. The latter preserves content and is the within-factor intervention winner, but its ordinary 95% interval [-0.006437, +0.009442] also crosses zero.

| factor | observed_delta | ci_2_5 | ci_97_5 | bonferroni_ci_lower | bonferroni_ci_upper | probability_delta_gt_zero | baseline_correct_candidate_wrong | baseline_wrong_candidate_correct | exact_mcnemar_p_value |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| url | +0.004879 | -0.004540 | +0.014364 | -0.007534 | +0.018115 | 0.837 | 15.0 | 20.0 | 0.4996 |
| mention | +0.007802 | -0.000634 | +0.016827 | -0.003534 | +0.019630 | 0.960 | 9.0 | 18.0 | 0.1221 |
| hashtag | +0.001401 | -0.006437 | +0.009442 | -0.009168 | +0.011915 | 0.636 | 9.0 | 12.0 | 0.6636 |

McNemar columns estimate paired correctness rather than F1; they are reported alongside, not substituted for, the paired F1 intervals.

## Mention-specific identity evidence

| split | rows | mention_rows | mention_occurrences | unique_handles | singleton_handles | singleton_share_of_unique | unseen_occurrences_vs_train | unseen_occurrence_rate_vs_train | unseen_unique_handles_vs_train |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| train | 4567 | 1156 | 1541 | 1336 | 1236 | 92.5% | 0 | 0.0% | 0 |
| dev | 1523 | 399 | 552 | 519 | 505 | 97.3% | 482 | 87.3% | 475 |
| heldout | 1523 | 439 | 594 | 554 | 529 | 95.5% | 506 | 85.2% | 495 |

The audit extracts handles without labels from each split and compares them with the training handle vocabulary. High singleton and unseen-handle rates support the premise that exact account identity is weakly portable, but that mechanism does not guarantee a stable predictive gain from normalization. Canonicalization raises the development point estimate, whereas removal is nearly neutral. However, the controlled baseline changes only one decision when handles are synthetically rewritten, and only a minority of canonicalization-induced boundary movements occur on mention rows. The apparent gain is therefore weakly localized and can arise partly from global vocabulary/IDF refitting.

## Matched mechanism stress tests

| factor | matched_stress | baseline_changes | factor_model_changes | baseline_stressed_f1 | factor_stressed_f1 | robustness_advantage | robustness_95_ci |
| --- | --- | --- | --- | --- | --- | --- | --- |
| url | url_rewritten | 160 | 0 | 0.638754 | 0.736134 | +0.092502 | [+0.067433, +0.118553] |
| mention | mention_rewritten | 1 | 0 | 0.731872 | 0.739057 | -0.000617 | [-0.001913, +0.000000] |
| hashtag | hashtag_separator_rewritten | 3 | 0 | 0.730185 | 0.732657 | +0.001070 | [-0.001252, +0.004061] |

Each stress matches one factor-specific intervention. URL strings are replaced by another syntactically valid URL, mention handles are rewritten under the canonicalization diagnostic, and decomposable CamelCase hashtag boundaries are rewritten with underscores. Every corresponding intervention model changes zero hard predictions and zero scores. Invariance is interpreted separately from predictive value: the baseline has severe URL sensitivity, but it is already almost invariant to mention rewriting. That asymmetry gives URL canonicalization a much clearer causal mechanism than mention canonicalization.

## FP/FN movements and treatment localization on development

| factor | changed_predictions | fixed_fp | fixed_fn | new_fp | new_fn | treatment_prevalence | changed_share_treated | treated_change_rate | untreated_change_rate | change_rate_ratio |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| url | 35 | 11 | 9 | 10 | 5 | 50.4% | 82.9% | 3.8% | 0.8% | 4.76x |
| mention | 27 | 9 | 9 | 5 | 4 | 26.2% | 29.6% | 2.0% | 1.7% | 1.19x |
| hashtag | 21 | 7 | 5 | 3 | 6 | 6.3% | 19.0% | 4.2% | 1.2% | 3.50x |

The table includes improvements and regressions. `changed_share_treated` tests whether movements concentrate where the transformation can act, while treated and untreated change rates expose global vocabulary/IDF refitting effects. A factor is not credited merely because a few examples cross 0.5.

**Hypothesis-to-movement verdict.** URL supports H-URL as an invariance and localization mechanism: 29/35 boundary changes occur on URL rows, while improvements and regressions show no FP-only or FN-only direction. Mention does not strongly support H-mention as an identity-specific error mechanism because only 8/27 changes occur on mention rows and the controlled model is already nearly invariant to handle rewriting. Hashtag remains inconclusive: only 4/21 changes occur on decomposable-hashtag rows, and fixed FNs (5) do not exceed new FNs (6), so the expected semantic-recall mechanism is not demonstrated.

| factor_name | id | y_true | change_type | baseline_score | candidate_score | text |
| --- | --- | --- | --- | --- | --- | --- |
| url | 6200 | 0 | fixed_fp | 0.5002 | 0.4880 | Remove the http://t.co/l4wJHz4AJ6 and Linkury Browser Hijacker http://t.co/KMgDv7VSAz http://t.co/byTsfms7Md |
| url | 10394 | 1 | fixed_fn | 0.4106 | 0.5054 | Weather forecast for Thailand A Whirlwind is coming ...2 september https://t.co/rUKjYjG9oQ |
| url | 5467 | 0 | new_fp | 0.3357 | 0.5013 | Cabin Fever 2 flames https://t.co/yXnagsqvBM |
| url | 237 | 1 | new_fn | 0.5075 | 0.4874 | #OMG! I don't believe this. #RIP bro #AirPlane #Accident #JetEngine #TurboJet #Boing #G90 http://t.co/KXxnSZp6nk |
| mention | 4131 | 0 | fixed_fp | 0.5022 | 0.4690 | @KarinaGarciaxo_ me &amp; you both &amp; I'll be dam if I get any of that drought bud |
| mention | 9242 | 1 | fixed_fn | 0.4987 | 0.5087 | why wasn't this warship sunk? CNN: First on CNN: Iranian warship points weapon at U.S. helicopter official says htt… |
| mention | 2494 | 0 | new_fp | 0.4992 | 0.5055 | It's Even Worse Than It Looks: How the American Constitutional System Collided With the New PoliticÛ_ http://t.co/… |
| mention | 9484 | 1 | new_fn | 0.5114 | 0.4843 | @KurtSchlichter He's already done it by negotiating with the #1 state of terrorism in the World. What was his hurry… |
| hashtag | 10359 | 0 | fixed_fp | 0.5131 | 0.4947 | @DorisMatsui thank you for supporting the President. The #IranDeal takes nuclear weapons out of the hands of Iran a… |
| hashtag | 8289 | 1 | fixed_fn | 0.4980 | 0.5010 | AM `bbcnews The Ass British Insurers says rioting will cost insurers163;millions. But police numbers are reduced by… |
| hashtag | 3447 | 0 | new_fp | 0.4483 | 0.5024 | im tired of all these #AllLivesMatter people. they only say this to derail #blacklivesmatter they dont do anything … |
| hashtag | 10485 | 1 | new_fn | 0.5187 | 0.4491 | Does the #FingerRockFire make you wonder 'am I prepared for a wildfire'. Find out at http://t.co/eX8A5JYZm5 #azwx h… |

Examples are sampled symmetrically from every available fixed/new FP/FN direction for each factor. They diagnose how a lever moves the boundary; they do not replace aggregate or paired evidence.

## Independent hashtag vocabulary check

| component | train_decomposed_occurrences | baseline_in_vocabulary | baseline_coefficient | hashtag_model_in_vocabulary | hashtag_model_coefficient |
| --- | --- | --- | --- | --- | --- |
| news | 23 | True | +1.0403 | True | +1.4411 |
| the | 16 | False |  | False |  |
| now | 10 | False |  | False |  |
| playing | 7 | True | +0.1084 | True | -0.1010 |
| up | 7 | False |  | False |  |
| iran | 7 | True | +0.7060 | True | +0.6052 |
| world | 7 | True | -0.2212 | True | -0.0020 |
| in | 6 | False |  | False |  |
| deal | 6 | True | -0.3522 | True | -0.2426 |
| music | 5 | True | -0.3690 | True | -0.5735 |

The audit derives component counts from training hashtags only and then checks whether those components enter each fitted vocabulary and how their coefficients differ. It verifies that the intended component words are actually exposed to the fitted model. Refitting changes global document frequencies and competition for the 5,000-feature cap, so the treatment-enrichment table, rather than this vocabulary check alone, supports localization.

## Frozen held-out URL result

Only the frozen unweighted baseline and URL candidate are scored on held-out. URL-only precision/recall/F1 are 0.841603/0.674312/0.748727, versus 0.835539/0.675841/0.747253. It fixes 11 FP and 6 FN while creating 7 FP and 7 FN. The F1 difference is +0.001474, paired 95% CI [-0.007754, +0.010812].

## Decision

**ADOPT `url_only_normalization` as the unweighted downstream representation.** Retain mentions unchanged because canonicalization was exploratory, its interval crosses zero, and its changes are weakly localized despite a positive point estimate. Keep conservative hashtag decomposition as a development-only future candidate because its interval also crosses zero. This decision changes only URL normalization; class weighting remains untouched until Ticket 4.

## Limitations

The hashtag splitter handles only explicit orthographic boundaries and misses all-lowercase compounds. Mention normalization can discard meaningful source or conversational context; its positive point estimate is exploratory and not sufficiently localized to the treatment rows. Matched stresses test invariance to constructed equivalent spellings, not performance under platform drift. Development intervals quantify finite-sample uncertainty on this split.

## Artifacts

- `configs/ticket2_protocol.json`
- `results/ticket2_ablation.csv`
- `results/ticket2_factor_coverage.csv`
- `results/ticket2_mention_identity_audit.csv`
- `results/ticket2_factor_prediction_changes_dev.csv`
- `results/ticket2_factor_change_summary_dev.csv`
- `results/ticket2_stress_matrix.csv`
- `results/ticket2_hashtag_component_audit.csv`
- `results/ticket2_statistics.csv`
- `results/ticket2_prediction_changes.csv`
- `results/ticket2_change_summary.csv`
- `results/ticket2_vocabulary_audit.csv`
- `predictions/ticket_2_selected_heldout.csv`
